# AI Delivery Engine 项目介绍

## 1. 一句话说明

`AI Delivery Engine` 是一个将“非标准需求输入”自动转换为“可评审、可开发、可测试交付物”的智能交付引擎。

## 2. 核心目标

- 把需求文档自动结构化为标准交付文档
- 通过规则库与知识库降低遗漏、歧义和幻觉风险
- 让接口文档可直接导入 Postman / Apifox
- 把生成质量量化为可追踪的评分与门禁结论

## 3. 产物范围

每次执行可生成 4 类核心文档 + 2 类接口 JSON：

- `$(需求名)_Analysis_Report.md`
- `$(需求名)_FRD.md`
- `$(需求名)_Interfaces.md`
- `$(需求名)_Quality_Assessment.md`
- `$(需求名)_Interfaces_Postman.json`
- `$(需求名)_Interfaces_Apifox.json`

## 4. 角色协作模型

```mermaid
flowchart LR
  U["需求输入"] --> W["WorkflowManager"]
  W --> K["KnowledgeBaseAdministrator"]
  W --> R["RequirementAnalyzer"]
  W --> D["Designer"]
  W --> DEV["Developer"]
  W --> T["Tester"]
  W --> RV["Reviewer"]
  K --> KB["Knowledge Base / Skills"]
  R --> A["Analysis Report"]
  D --> F["FRD"]
  D --> I["Interfaces"]
  RV --> Q["Quality Assessment"]
```

## 5. 技术结构

```mermaid
flowchart TD
  CLI["app/cli.py"] --> ENG["workflow/engine.py"]
  ENG --> AG["agents/*"]
  ENG --> RND["render/markdown.py"]
  ENG --> EXP["exporters/spec_exporter.py"]
  ENG --> VAL["validators/*"]
  ENG --> KB["kb/provider.py"]
  ENG --> RULE["rules/*"]
  RND --> MD["Markdown 文档产物"]
  EXP --> JSON["Postman / OpenAPI JSON"]
```

## 6. 生成质量保障

- 文档语义边界校验：不同文档只允许出现本语义范围内容
- 模板约束：分析、FRD、接口文档按固定模板输出
- 质量量化：统一评分表输出指标、得分、结论
- 质量门禁：`PASS / WARN / BLOCK` 可用于流水线阻断

## 7. 典型使用流程

1. 扫描项目上下文（仓库、模块、数据源、表）
2. 输入需求文档并执行 `generate`
3. 自动产出文档与接口 JSON
4. 按质量评估和门禁结果进行交付或修订

## 8. 适用场景

- 多系统需求改造与影响面分析
- 非标需求文档快速标准化交付
- 需要统一格式接口文档并直接对接测试工具
- 需要可量化质量治理的交付流程
