# AI Delivery Engine 使用文档

本文档用于说明如何使用 `AI Delivery Engine` 完成以下工作：

1. 扫描多仓库上下文
2. 基于需求生成需求分析报告、开发设计文档（FRD）和接口文档
3. 生成独立质量评估文档（量化指标 + 质量门禁）
4. 生成可导入 Postman / Apifox 的接口 JSON 文件
5. 累积沉淀领域知识库与领域 skills
6. 严格执行使用方定义的公共规则库（需求分析、开发设计、接口、代码规范）
7. 接入公共知识库增强需求分析与方案设计
8. 输出第三阶段质量评估（语义命中、引用覆盖率、幻觉风险）
9. 输出第四阶段质量门禁（PASS/WARN/BLOCK）与自动修复建议

## 1. 项目路径

项目根目录：

`{{ENGINE_ROOT}}`

业务代码根目录（被扫描对象）：

`{{PROJECT_ROOT}}`

## 2. 环境要求

- Python `>=3.10`
- 已安装依赖（包含 `openai`、`langgraph`）
- 可访问你的 LLM 网关地址

兼容性提示：

- 在 Python `3.14` 下启用 `langgraph` 时，可能出现 `langchain_core` 的 Pydantic V1 兼容性告警（`UserWarning`）；当前不影响流程执行。

## 3. 安装依赖

```bash
cd {{ENGINE_ROOT}}
python3 -m pip install -e .
```

安装后可用命令：

```bash
ai-delivery-engine --help
```

## 4. 配置 LLM

```bash
export OPENAI_API_KEY="<YOUR_KEY>"
export OPENAI_BASE_URL="{{OPENAI_BASE_URL}}"
export OPENAI_MODEL="{{OPENAI_MODEL}}"
```

说明：

- `OPENAI_API_KEY`：必填
- `OPENAI_BASE_URL`：你的代理/网关地址
- `OPENAI_MODEL`：默认模型名，不传 `--model` 时会使用此值

## 5. 扫描上下文

首次使用或代码仓库有更新时，先执行扫描：

```bash
ai-delivery-engine scan-context \
  --project-root {{PROJECT_ROOT}} \
  --output outputs/context_snapshot.json
```

产物：

- `outputs/context_snapshot.json`

## 6. 生成设计与接口文档

执行前请先准备公共知识库（由使用方维护）：

- local 模式默认目录：`public_knowledge_base`
- 最小文件：`public_knowledge_snapshot.json`

可选接入模式：

- `local`：直接读取本地公共知识库目录
- `remote`：通过 HTTP API 读取公共知识库服务
- `hybrid`：优先 remote，失败后使用本地目录并支持缓存

执行前请先准备公共规则库目录（由使用方维护），默认路径：

- `knowledge_base/public_rules`

必须包含以下文件：

- `Requirement_Analysis_Report_Standard.md`
- `Technical_Design_Document_Standard.md`
- `Interface_Document_Standard.md`
- `Code_Development_Standard.md`

可选文件：

- `Quality_Gate_Policy.json`（用于配置 PASS/WARN/BLOCK 门禁阈值与评分权重）

### 6.1 严格 LLM 模式（推荐）

```bash
ai-delivery-engine generate \
  --context-file outputs/context_snapshot.json \
  --requirement-file examples/card-center-refactor.md \
  --out-dir outputs/latest \
  --kb-mode local \
  --kb-dir public_knowledge_base \
  --kb-namespace default \
  --rules-dir knowledge_base/public_rules \
  --knowledge-dir knowledge_base \
  --orchestrator langgraph \
  --node-retry-max-attempts 2 \
  --node-retry-backoff-ms 200 \
  --strict-llm
```

### 6.2 指定模型（可选）

```bash
ai-delivery-engine generate \
  --context-file outputs/context_snapshot.json \
  --requirement-file examples/card-center-refactor.md \
  --out-dir outputs/latest \
  --kb-mode local \
  --kb-dir public_knowledge_base \
  --kb-namespace default \
  --rules-dir knowledge_base/public_rules \
  --knowledge-dir knowledge_base \
  --orchestrator langgraph \
  --node-retry-max-attempts 2 \
  --node-retry-backoff-ms 200 \
  --model {{OPENAI_MODEL}} \
  --strict-llm
```

### 6.3 关闭 LLM（规则模式，调试用）

```bash
ai-delivery-engine generate \
  --context-file outputs/context_snapshot.json \
  --requirement-file examples/card-center-refactor.md \
  --out-dir outputs/latest \
  --kb-mode local \
  --kb-dir public_knowledge_base \
  --kb-namespace default \
  --rules-dir knowledge_base/public_rules \
  --knowledge-dir knowledge_base \
  --orchestrator langgraph \
  --node-retry-max-attempts 2 \
  --node-retry-backoff-ms 200 \
  --disable-llm
```

## 7. 输出文件说明

执行 `generate` 后，默认在 `--out-dir` 目录生成：

- `$(需求文档名)_Analysis_Report.md`：需求分析报告
- `$(需求文档名)_FRD.md`：开发设计文档（FRD）
- `$(需求文档名)_Interfaces.md`：接口文档（含详细测试用例 + 输入/输出数据结构）
- `$(需求文档名)_Quality_Assessment.md`：质量评估文档（按统一评估表输出14项量化结果 + 门禁结论）
- `$(需求文档名)_Execution_Trace.json`：执行轨迹（节点耗时、重试摘要、节点级明细）
- `$(需求文档名)_Interfaces_Postman.json`：可直接导入 Postman 的 Collection v2.1
- `$(需求文档名)_Interfaces_Apifox.json`：可直接导入 Apifox 的 OpenAPI 3.0.3
- `--knowledge-dir/Domain_Knowledge_Base.json`：累计领域知识库
- `--knowledge-dir/Domain_Skills_Catalog.md`：skills 索引
- `--knowledge-dir/skills/*.md`：领域与需求 skills（累计）

说明：公共规则库是执行输入，不由 `generate` 自动创建或覆盖。
说明：公共知识库是执行输入，`generate` 会读取并输出命中摘要，不会覆盖使用方内容。
说明：`generate` 完成后会向公共知识库回写草稿（`PENDING_REVIEW`）并记录审计日志。
说明：remote 模式接口契约见 `docs/PUBLIC_KB_API.md`。
说明：需求分析报告会附带第三阶段质量评估，包含 `semantic top hits`、`citation coverage ratio`、`hallucination risk` 与改进建议。
说明：需求分析报告会附带第四阶段质量门禁，包含 `decision/score/reasons`、阻断问题、告警问题与自动修复建议。

## 8. Postman 导入步骤

1. 打开 Postman
2. 点击 `Import`
3. 选择文件 `$(需求文档名)_Interfaces_Postman.json`
4. 导入后配置变量 `baseUrl`
5. 运行请求

## 9. Apifox 导入步骤

1. 打开 Apifox 项目
2. 选择 `导入` -> `OpenAPI/Swagger`
3. 上传 `$(需求文档名)_Interfaces_Apifox.json`
4. 选择新建或合并接口
5. 配置环境变量 `baseUrl`

## 10. 常用参数速查

- `--requirement-file`：需求输入文件路径（必填）
- `--context-file`：上下文快照路径（与 `--project-root` 二选一）
- `--project-root`：直接扫描项目根目录（不传 `--context-file` 时必填）
- `--out-dir`：输出目录
- `--templates-dir`：Markdown 模板目录
- `--knowledge-dir`：知识库与 skills 累积目录
- `--rules-dir`：公共规则库目录（使用方维护）
- `--kb-mode`：公共知识库模式（`local|remote|hybrid`）
- `--kb-dir`：本地公共知识库目录（local/hybrid）
- `--kb-url`：公共知识库服务地址（remote/hybrid）
- `--kb-token`：公共知识库访问令牌（不传则读取 `PUBLIC_KB_TOKEN`）
- `--kb-namespace`：公共知识命名空间
- `--kb-cache-dir`：公共知识缓存目录（hybrid）
- `--strict-kb`：公共知识库读/写/审计任一不可用时直接失败
- `--disable-llm`：关闭 LLM
- `--model`：指定模型
- `--strict-llm`：LLM 不可用时直接失败
- `--orchestrator`：流程编排器（默认 `langgraph`，可选 `classic`）
- `--node-retry-max-attempts`：LangGraph 节点重试总尝试次数（含首次执行）
- `--node-retry-backoff-ms`：LangGraph 节点重试退避时长（毫秒，线性退避）
- `--quality-gate-policy-file`：自定义质量门禁策略 JSON 路径
- `--enforce-quality-gate`：当质量门禁为 BLOCK 时返回失败码

## 11. 一条完整可执行示例

```bash
cd {{ENGINE_ROOT}}

export OPENAI_API_KEY="<YOUR_KEY>"
export OPENAI_BASE_URL="{{OPENAI_BASE_URL}}"
export OPENAI_MODEL="{{OPENAI_MODEL}}"

ai-delivery-engine scan-context \
  --project-root {{PROJECT_ROOT}} \
  --output outputs/context_snapshot.json

ai-delivery-engine generate \
  --context-file outputs/context_snapshot.json \
  --requirement-file examples/card-center-refactor.md \
  --out-dir outputs/latest \
  --kb-mode local \
  --kb-dir public_knowledge_base \
  --kb-namespace default \
  --rules-dir knowledge_base/public_rules \
  --knowledge-dir knowledge_base \
  --orchestrator langgraph \
  --node-retry-max-attempts 2 \
  --node-retry-backoff-ms 200 \
  --strict-llm
```

## 12. 草稿审批状态更新

当公共知识库已生成草稿后，可通过以下命令更新审批状态：

```bash
ai-delivery-engine kb-review \
  --draft-id <DRAFT_ID> \
  --approval-status APPROVED \
  --reviewer <REVIEWER> \
  --note "review passed" \
  --kb-mode local \
  --kb-dir public_knowledge_base \
  --kb-namespace default
```
