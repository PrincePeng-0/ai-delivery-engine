# AI Delivery Engine 详细介绍与使用手册

本文档用于提供一份“可落地、可维护、可扩展”的项目全景说明，覆盖：

- 项目介绍
- 项目依赖
- 安装与配置
- 使用方法
- 核心架构图
- 执行时序图
- 关键数据模型
- 质量门禁机制
- 常见问题与排查建议

## 1. 项目介绍

`AI Delivery Engine` 是一个面向“多仓库需求交付”的 Python Agent 工程。它的目标是把非标准需求文档转换为标准化交付产物，并在过程中引入知识复用、规则约束和质量门禁。

核心交付物：

1. `$(需求文档名)_Analysis_Report.md`（需求分析报告）
2. `$(需求文档名)_FRD.md`（开发设计文档）
3. `$(需求文档名)_Interfaces.md`（接口文档）
4. `$(需求文档名)_Quality_Assessment.md`（质量评估文档，按统一评估表输出“指标评分总表 + 指标解释表 + 结论”）
5. `$(需求文档名)_Execution_Trace.json`（执行轨迹，包含节点重试与耗时明细）
6. `$(需求文档名)_Interfaces_Postman.json`（Postman 可导入）
7. `$(需求文档名)_Interfaces_Apifox.json`（Apifox/OpenAPI 可导入）
8. `Domain_Knowledge_Base.json` 与 `skills/*.md`（知识沉淀）

## 2. 适用场景

- 多系统联动需求，需要快速完成影响分析与方案文档
- 需求文档质量不稳定，需要结构化抽取背景/目标/范围/约束/验收
- 需要同时生成接口文档与测试样例，并支持 Postman/Apifox 导入
- 需要对生成质量进行量化（语义命中、引用覆盖、幻觉风险、质量门禁）

## 3. 角色与职责

系统采用 7 角色协作模型：

1. `KnowledgeBaseAdministrator`：维护领域知识库与 skills，负责知识读写沉淀
2. `RequirementAnalyzer`：解析需求并输出拆解、优先级、影响范围
3. `Designer`：输出架构与接口方案，形成 FRD 和接口文档基础
4. `Developer`：输出编码实施计划与覆盖率目标（>=90%）
5. `Tester`：输出单元测试计划与执行建议
6. `Reviewer`：执行一致性和质量校验
7. `WorkflowManager`：编排全流程并输出最终交付物

## 4. 项目依赖

### 4.1 运行依赖

| 类别 | 依赖项 | 版本/要求 | 说明 |
| --- | --- | --- | --- |
| 运行时 | Python | `>=3.10` | 必需 |
| 包管理 | pip/setuptools | 建议最新稳定版 | 用于安装与打包 |
| 三方库 | `openai` | `>=1.40.0` | LLM 调用（可兼容 OpenAI 风格网关） |
| 三方库 | `langgraph` | `>=0.2.0` | 流程状态图编排（默认编排器） |

### 4.2 外部系统依赖

| 依赖类型 | 必需性 | 说明 |
| --- | --- | --- |
| 公共规则库 | 必需 | 生成时严格执行使用方规则 |
| 公共知识库 | 建议 | 支持 `local/remote/hybrid` 三种模式 |
| LLM 网关 | 可选 | 未配置时可降级到规则模式（非 strict-llm） |

### 4.3 规则库文件依赖

默认目录：`knowledge_base/public_rules`

必需文件：

- `Requirement_Analysis_Report_Standard.md`
- `Technical_Design_Document_Standard.md`
- `Interface_Document_Standard.md`
- `Code_Development_Standard.md`

可选文件：

- `Quality_Gate_Policy.json`（质量门禁阈值与评分策略）

## 5. 目录结构

```text
ai-delivery-engine/
  app/
    agents/                 # 各角色实现
    ingest/                 # 上下文扫描与快照
    kb/                     # 公共知识库 provider
    llm/                    # LLM 客户端与兼容封装
    render/                 # Markdown 渲染
    exporters/              # Postman/OpenAPI 导出
    rules/                  # 规则库与质量门禁策略加载
    schemas/                # 数据模型
    validators/             # 质量校验
    workflow/               # 主编排引擎
    cli.py                  # 命令行入口
  docs/
    USAGE.md
    PUBLIC_KB_API.md
    PROJECT_GUIDE.md
  examples/
    card-center-refactor.md
  knowledge_base/
    public_rules/
    skills/
  public_knowledge_base/
    public_knowledge_snapshot.json
  templates/
    Requirement Analysis Report Template.md
    Funditional Requirement Document.md
    api_doc.md.j2
```

## 6. 总体架构图

```mermaid
flowchart LR
  U["用户 / CI"] --> C["CLI(app/cli.py)"]
  C --> W["Workflow Engine (LangGraph Default)"]

  W --> A1["KnowledgeBaseAdministrator"]
  W --> A2["RequirementAnalyzer"]
  W --> A3["Designer"]
  W --> A4["Developer"]
  W --> A5["Tester"]
  W --> A6["Reviewer"]
  W --> A7["WorkflowManager"]

  A1 --> PK["Private Knowledge(knowledge_base)"]
  W --> RK["Public Rulebook(public_rules)"]
  W --> KB["Public Knowledge Provider(local/remote/hybrid)"]

  W --> R["Render Layer(markdown)"]
  W --> E["Export Layer(Postman/OpenAPI)"]
  R --> O["Markdown 交付物"]
  E --> OJ["JSON 交付物"]
```

### 6.1 角色协作架构图（7角色）

```mermaid
flowchart LR
  U["使用方 / CI 提交需求"] --> WM["WorkflowManager"]

  RB["Public Rulebook<br/>需求/设计/接口/代码规范"] --> WM
  WM --> KBA["KnowledgeBaseAdministrator"]
  WM --> RA["RequirementAnalyzer"]
  WM --> DS["Designer"]
  WM --> DEV["Developer"]
  WM --> TST["Tester"]
  WM --> RVW["Reviewer"]

  KBA <--> PKB["Public Knowledge Base"]
  KBA <--> DKB["Domain Knowledge Base & Skills"]
  KBA --> RA

  RA -->|"需求分析文档"| WM
  RA --> DS
  DS -->|"开发设计文档(FRD)"| WM
  DS -->|"接口定义"| WM
  DS --> DEV

  DEV -->|"代码与单测"| TST
  TST -->|"测试报告"| RVW
  RVW -->|"通过/不通过结论"| WM
  RVW -->|"不通过回流"| DEV

  WM --> O1["产物1：需求分析文档"]
  WM --> O2["产物2：开发设计文档"]
  WM --> O3["产物3：接口文档 + Postman/Apifox JSON"]
  WM --> O4["产物4：知识沉淀（KB & Skills）"]
```

## 7. 执行时序图

```mermaid
sequenceDiagram
  participant User as 用户
  participant CLI as CLI
  participant WF as Workflow
  participant KB as Public KB
  participant RB as Rulebook
  participant AG as Agents
  participant RD as Renderer/Exporter

  User->>CLI: generate --requirement-file ...
  CLI->>RB: 加载规则库
  CLI->>KB: 初始化 Provider
  CLI->>WF: run(requirement, context)
  WF->>KB: fetch_context()
  WF->>AG: 需求分析/设计/开发/测试/评审
  WF->>KB: submit_draft()
  WF->>WF: 质量评估(阶段3)
  WF->>WF: 质量门禁(阶段4)
  WF->>RD: 渲染文档 + 导出接口JSON
  RD-->>CLI: 产物路径
  CLI-->>User: 输出结果与质量结论
```

### 7.1 角色交互时序图（7角色）

```mermaid
sequenceDiagram
  autonumber
  participant User as 使用方
  participant WM as WorkflowManager
  participant RB as Public Rulebook
  participant KBA as KnowledgeBaseAdministrator
  participant PKB as Public Knowledge Base
  participant RA as RequirementAnalyzer
  participant DS as Designer
  participant DEV as Developer
  participant TST as Tester
  participant RVW as Reviewer
  participant OUT as 交付产物库

  User->>WM: 提交需求文档与上下文
  WM->>RB: 加载规则与模板约束
  WM->>KBA: 初始化知识上下文
  KBA->>PKB: 检索领域知识与历史技能
  KBA-->>WM: 返回知识命中与补充信息

  WM->>RA: 执行需求拆解/优先级/影响范围分析
  RA-->>WM: 输出需求分析文档

  WM->>DS: 执行架构/数据库/接口设计
  DS-->>WM: 输出开发设计文档(FRD)与接口定义

  WM->>DEV: 按FRD实现代码并编写单测
  DEV-->>WM: 代码与单测结果

  WM->>TST: 执行测试验证
  TST-->>WM: 测试报告

  WM->>RVW: 代码与需求一致性评审
  alt 评审不通过
      RVW-->>WM: 缺陷清单与修改建议
      WM->>DEV: 下发修复任务
      DEV-->>WM: 修复提交
      WM->>TST: 回归测试
      TST-->>WM: 回归结果
      WM->>RVW: 发起复审
  else 评审通过
      RVW-->>WM: 通过结论
  end

  WM->>KBA: 沉淀本次需求知识与skills
  KBA->>PKB: 写入/提交知识草稿
  WM->>OUT: 归档最终四类产物
  OUT-->>User: 分析文档/设计文档/接口文档(JSON)/知识沉淀
```

## 8. 核心模块说明

| 模块 | 关键文件 | 职责 |
| --- | --- | --- |
| CLI | `app/cli.py` | 参数解析、流程触发、产物落盘 |
| 工作流 | `app/workflow/langgraph_engine.py` | 默认 LangGraph 状态图编排（7 角色） |
| 工作流 | `app/workflow/engine.py` | Classic 串行编排（兼容回退） |
| 规则库 | `app/rules/public_rulebook.py` | 公共规则加载 |
| 门禁策略 | `app/rules/quality_gate_policy.py` | 质量门禁策略加载与默认值 |
| 知识库接入 | `app/kb/provider.py` | 本地/远程/混合知识库 |
| 渲染导出 | `app/render/markdown.py`, `app/exporters/spec_exporter.py` | Markdown 与 JSON 输出 |
| 校验 | `app/validators/quality.py` | Reviewer 基础质量检查 |

## 9. 核心数据模型（简化）

| 模型 | 说明 |
| --- | --- |
| `RequirementInput` | 需求结构化结果 |
| `ContextSnapshot` | 项目扫描快照（仓库、表、依赖） |
| `DesignDoc` | 开发设计文档数据 |
| `ApiDoc` | 接口文档数据 |
| `ValidationReport` | Reviewer 质量校验结果 |
| `WorkflowResult` | 全流程聚合输出（含质量评估与门禁） |

## 10. 安装与配置

### 10.1 安装

```bash
cd {{ENGINE_ROOT}}
python3 -m pip install -e .
```

### 10.2 LLM 配置（可选）

```bash
export OPENAI_API_KEY="<YOUR_KEY>"
export OPENAI_BASE_URL="{{OPENAI_BASE_URL}}"
export OPENAI_MODEL="{{OPENAI_MODEL}}"
```

说明：

- 若不配置 Key，可使用 `--disable-llm` 走规则模式
- 若配置 `--strict-llm`，LLM 不可用时会直接失败

## 11. 使用方法

### 11.1 扫描项目上下文

```bash
ai-delivery-engine scan-context \
  --project-root {{PROJECT_ROOT}} \
  --output outputs/context_snapshot.json
```

### 11.2 生成文档与接口 JSON

```bash
ai-delivery-engine generate \
  --context-file outputs/context_snapshot.json \
  --requirement-file examples/card-center-refactor.md \
  --out-dir outputs/latest \
  --kb-mode local \
  --kb-dir public_knowledge_base \
  --kb-namespace default \
  --rules-dir knowledge_base/public_rules \
  --knowledge-dir knowledge_base \
  --orchestrator langgraph \
  --node-retry-max-attempts 2 \
  --node-retry-backoff-ms 200
```

### 11.3 启用质量门禁阻断

```bash
ai-delivery-engine generate \
  --context-file outputs/context_snapshot.json \
  --requirement-file examples/card-center-refactor.md \
  --out-dir outputs/latest \
  --rules-dir knowledge_base/public_rules \
  --enforce-quality-gate
```

### 11.4 使用自定义质量门禁策略

```bash
ai-delivery-engine generate \
  --context-file outputs/context_snapshot.json \
  --requirement-file examples/card-center-refactor.md \
  --out-dir outputs/latest \
  --rules-dir knowledge_base/public_rules \
  --quality-gate-policy-file /absolute/path/Quality_Gate_Policy.json \
  --enforce-quality-gate
```

## 12. 参数速查（generate）

| 参数 | 说明 |
| --- | --- |
| `--requirement-file` | 需求输入文件（必填） |
| `--context-file` | 上下文快照（与 `--project-root` 二选一） |
| `--project-root` | 实时扫描项目根目录 |
| `--out-dir` | 输出目录 |
| `--kb-mode` | 公共知识模式：`local/remote/hybrid` |
| `--kb-dir` | 本地知识库目录 |
| `--kb-url` | 远程知识库地址 |
| `--kb-token` | 远程知识库访问令牌 |
| `--rules-dir` | 公共规则库目录 |
| `--quality-gate-policy-file` | 质量门禁策略 JSON |
| `--enforce-quality-gate` | BLOCK 时返回非 0 |
| `--disable-llm` | 关闭 LLM |
| `--strict-llm` | LLM 不可用时直接失败 |
| `--orchestrator` | 编排器（默认 `langgraph`，可选 `classic`） |
| `--node-retry-max-attempts` | LangGraph 节点重试总尝试次数（含首次执行） |
| `--node-retry-backoff-ms` | LangGraph 节点重试退避时长（毫秒，线性退避） |

## 13. 质量机制说明

### 13.1 第三阶段：质量评估

输出指标：

- `semantic_hit_count`
- `semantic_avg_score`
- `citation_coverage_ratio`
- `hallucination_risk_level`
- `risk_signals`
- `recommendations`

### 13.2 第四阶段：质量门禁

输出结论：

- `decision`: `PASS/WARN/BLOCK`
- `score`: 0~100
- `blocking_issues` / `warning_issues`
- `auto_fix_actions`
- `policy_source`

### 13.3 质量评估文档版式（固定）

- 表 1：`维度 | 指标名称 | 值 | 得分`
- 表 2：`指标名称 | 指标解释 | 计算方法 | 衡量标准`
- 结论：指标总数、达标数/未达标数、达标率、平均分与等级（A/B/C/D）、门禁结论与主要风险

### 13.4 LangGraph 执行追踪（Execution Trace）

执行 `generate` 后会额外产出 `$(需求文档名)_Execution_Trace.json`，用于排障与可视化分析。

建议关注以下字段：

- `orchestrator`：编排模式（默认 `langgraph`）
- `node_retry_policy.max_attempts`：节点总尝试次数（含首次执行）
- `node_retry_policy.backoff_ms`：线性退避基线毫秒值
- `runtime_stats.stage_durations_ms`：阶段耗时统计（毫秒）
- `runtime_stats.node_retry_summary`：节点聚合统计（attempts/retries/failed）
- `runtime_stats.node_trace`：节点执行明细（attempt/status/duration/error）

## 14. 产物与命名规则

以需求文件 `payment_upgrade.md` 为例：

- `payment_upgrade_Analysis_Report.md`
- `payment_upgrade_FRD.md`
- `payment_upgrade_Interfaces.md`
- `payment_upgrade_Quality_Assessment.md`
- `payment_upgrade_Execution_Trace.json`
- `payment_upgrade_Interfaces_Postman.json`
- `payment_upgrade_Interfaces_Apifox.json`

## 15. Postman / Apifox 导入

### 15.1 Postman

1. 打开 Postman
2. `Import`
3. 选择 `*_Interfaces_Postman.json`
4. 配置 `baseUrl` 环境变量

### 15.2 Apifox

1. 打开 Apifox
2. 选择 `导入 -> OpenAPI/Swagger`
3. 上传 `*_Interfaces_Apifox.json`
4. 配置 `baseUrl` 环境变量

## 16. 常见问题与排查

### 16.1 规则库缺失

现象：`公共规则库不可用`  
处理：确认 `rules-dir` 下 4 个必需规则文件齐全。

### 16.2 门禁 BLOCK 导致退出码非 0

现象：`--enforce-quality-gate` 下命令失败  
处理：查看分析报告中的“质量门禁结论”章节，按 `auto_fix_actions` 修复后重跑。

### 16.3 LLM 不可用

现象：网络或鉴权问题  
处理：

- 临时使用 `--disable-llm`
- 或修复 `OPENAI_API_KEY/OPENAI_BASE_URL/OPENAI_MODEL`

### 16.4 公共知识库读取失败

现象：`unavailable:...`  
处理：

- local 模式确认 `public_knowledge_snapshot.json` 存在
- remote 模式确认 `kb-url` 与 `kb-token`
- 需要强一致时开启 `--strict-kb`

### 16.5 接口归属系统不在影响系统集合中

现象：报告出现 `接口 ... 的归属系统 ... 不在影响系统集合中`  
处理：

- 优先确认 `--project-root` 或 `--context-file` 使用的是实际业务项目上下文（不要用空目录或仅引擎目录）
- 在需求中明确影响系统（或在分析报告中校对影响范围）后重跑
- 若只是演示样例且你接受占位接口，可忽略该告警；生产交付建议修复

### 16.6 Python 3.14 下 LangGraph 告警

现象：运行时出现 `Core Pydantic V1 functionality isn't compatible with Python 3.14 or greater`。  
处理：

- 当前为上游依赖告警，通常不影响执行结果，可先继续使用
- 若需消除告警，可切换到 Python `3.13` 运行环境，或等待上游依赖完成适配

### 16.7 LangGraph 节点重试触发频繁

现象：日志中节点 `attempts/retries` 明显升高，耗时抖动变大。  
处理：

- 优先检查公共知识库、LLM 网关或上下游依赖是否偶发超时
- 先把 `--node-retry-max-attempts` 调整为 `2~3`，避免无效重试放大耗时
- 结合 `Execution_Trace.json` 中 `node_trace.error` 定位失败节点并做针对性修复

## 17. 推荐落地流程

1. 先用真实业务代码根目录扫描上下文并固定 `context_snapshot.json`
2. 由使用方维护规则库和质量门禁策略
3. 运行 `generate` 并开启 `--enforce-quality-gate`
4. 对 `WARN/BLOCK` 按报告建议修复后重跑
5. 通过后进入开发与联调流程
