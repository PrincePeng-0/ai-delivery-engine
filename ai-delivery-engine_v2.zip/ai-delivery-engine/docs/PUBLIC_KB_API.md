# Public Knowledge Base API（MVP）

`AI Delivery Engine` 在 `--kb-mode remote|hybrid` 下会调用公共知识库服务的 `POST /query` 接口。

## 1. 请求

- Method: `POST`
- URL: `{KB_URL}/query`
- Headers:
  - `Content-Type: application/json`
  - `Accept: application/json`
  - `Authorization: Bearer <token>`（可选）

请求体示例：

```json
{
  "namespace": "default",
  "query": "原始需求文本",
  "limit": 20,
  "domain_systems": ["gateway-service", "risk-service"],
  "shared_tables": {
    "t_order": ["gateway-service", "ledger-service"]
  }
}
```

## 2. 响应

支持两种响应结构：

1. 直接返回知识对象
2. 返回 `{ "data": <知识对象> }`

知识对象示例：

```json
{
  "namespace": "default",
  "source": "remote-kb",
  "retrieved_at": "2026-04-17T12:00:00",
  "domain_systems": ["gateway-service", "risk-service"],
  "requirement_patterns": ["..."],
  "architecture_patterns": ["..."],
  "interface_patterns": ["..."],
  "coding_standards": ["..."],
  "recent_cases": [
    {
      "name": "case-1",
      "summary": "summary",
      "outcome": "outcome"
    }
  ],
  "references": ["doc-a", "doc-b"]
}
```

## 3. 字段说明

- `domain_systems`: 领域系统列表，用于影响范围辅助判断。
- `requirement_patterns`: 需求拆解与优先级分析模式。
- `architecture_patterns`: 架构与数据模型模式。
- `interface_patterns`: 接口契约与测试用例模式。
- `coding_standards`: 编码与质量门禁要点。
- `recent_cases`: 历史案例摘要。
- `references`: 外部规范/文档引用标识。

## 4. 错误处理

- HTTP 状态码非 `2xx`：引擎会记录错误详情。
- `--strict-kb` 开启时：公共知识库不可用将直接失败。
- `--strict-kb` 关闭时：按模式降级（如 hybrid 回退到本地或缓存）。

## 5. 草稿回写接口

`AI Delivery Engine` 会在文档生成后回写草稿到公共知识库，默认状态为 `PENDING_REVIEW`。

### 5.1 提交草稿

- Method: `POST`
- URL: `{KB_URL}/drafts`

请求体示例：

```json
{
  "namespace": "default",
  "requirement_name": "requirement_sample",
  "status": "PENDING_REVIEW",
  "approval_status": "PENDING_REVIEW",
  "context": {
    "generated_at": "2026-04-17T10:00:00",
    "project_root": "{{PROJECT_ROOT}}"
  },
  "payload": {
    "source_requirement_name": "requirement_sample",
    "requirement": {
      "title": "..."
    },
    "impact_summary": [],
    "design_summary": {},
    "interface_summary": {},
    "knowledge_source": {}
  }
}
```

响应示例：

```json
{
  "data": {
    "draft_id": "draft_requirement_sample_xxxxx",
    "approval_status": "PENDING_REVIEW",
    "message": "draft submitted"
  }
}
```

### 5.2 更新审批状态

- Method: `POST`
- URL: `{KB_URL}/drafts/{draft_id}/status`

请求体示例：

```json
{
  "namespace": "default",
  "draft_id": "draft_requirement_sample_xxxxx",
  "approval_status": "APPROVED",
  "reviewed_by": "tech-lead",
  "review_note": "ready to publish"
}
```

支持状态：

- `PENDING_REVIEW`
- `APPROVED`
- `REJECTED`

## 6. 审计建议

建议公共知识库服务侧记录以下审计事件：

1. `READ_CONTEXT`：检索公共知识上下文
2. `WRITE_DRAFT`：提交草稿
3. `UPDATE_DRAFT_STATUS`：审批状态变更

至少包含字段：`ts`, `provider`, `namespace`, `action`, `status`, `detail`。
