from __future__ import annotations

from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, ValidationReport


def validate_outputs(
    design_doc: DesignDoc,
    api_doc: ApiDoc,
    impacts: list[ImpactItem],
    context: ContextSnapshot,
) -> ValidationReport:
    checks: list[str] = []
    errors: list[str] = []
    warnings: list[str] = []

    # Check 1: 设计文档关键章节完整
    checks.append("设计文档关键章节完整性")
    if not design_doc.architecture_diagram.strip():
        errors.append("设计文档缺少架构图。")
    if not design_doc.sequence_diagrams:
        errors.append("设计文档缺少时序图。")
    if not design_doc.data_model_notes:
        warnings.append("设计文档未识别到数据模型说明。")

    # Check 2: 影响系统有效性
    checks.append("影响系统有效性")
    available = {repo.name for repo in context.repos}
    for impact in impacts:
        if impact.system not in available:
            errors.append(f"影响系统 `{impact.system}` 不存在于上下文快照。")

    # Check 3: 接口文档覆盖
    checks.append("接口文档覆盖")
    if not api_doc.endpoints:
        errors.append("接口文档无接口条目。")
    else:
        impacted_systems = {item.system for item in impacts}
        for endpoint in api_doc.endpoints:
            if endpoint.owner_system not in impacted_systems:
                warnings.append(
                    f"接口 `{endpoint.interface}` 的归属系统 `{endpoint.owner_system}` 不在影响系统集合中。"
                )

    # Check 4: 幂等与重试声明
    checks.append("幂等与重试策略声明")
    for endpoint in api_doc.endpoints:
        if not endpoint.idempotency.strip():
            warnings.append(f"接口 `{endpoint.interface}` 缺少幂等说明。")
        if not endpoint.retry_policy.strip():
            warnings.append(f"接口 `{endpoint.interface}` 缺少重试策略说明。")

    passed = not errors
    return ValidationReport(passed=passed, errors=errors, warnings=warnings, checks=checks)

