from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class DocumentScopeRule:
    """文档语义边界规则。

    - `forbidden_patterns`: 文档中不应出现的越界语义关键词；
    - `required_headings`: 文档必须包含的章节标题；
    - `title_pattern`: 一级标题匹配规则；
    - `heading_level`: 进行章节校验时抓取的标题层级前缀。
    """

    forbidden_patterns: tuple[re.Pattern[str], ...]
    required_headings: tuple[str, ...]
    title_pattern: re.Pattern[str]
    heading_level: str


_RULES: dict[str, DocumentScopeRule] = {
    "analysis": DocumentScopeRule(
        forbidden_patterns=(
            re.compile(r"质量门禁|门禁分|hallucination|citation_coverage|semantic_hit_count", re.IGNORECASE),
            re.compile(r"单元测试报告|测试覆盖率|代码提交|发布流水线|部署日志", re.IGNORECASE),
        ),
        required_headings=(
            "# 一、报告概述",
            "# 二、需求来源与用户分析",
            "# 三、核心需求描述",
            "# 四、需求优先级划分",
            "# 五、需求约束与假设",
            "# 六、需求确认与分歧说明",
            "# 七、风险分析与应对措施",
            "# 八、后续工作计划",
            "# 九、附件",
            "# 十、签字确认",
        ),
        title_pattern=re.compile(r"^# .+ - 需求分析报告$"),
        heading_level="# ",
    ),
    "frd": DocumentScopeRule(
        forbidden_patterns=(
            re.compile(r"质量门禁|门禁分|hallucination|citation_coverage|semantic_hit_count", re.IGNORECASE),
            re.compile(r"知识库命中摘要|语义检索高相关条目|需求来源与用户分析", re.IGNORECASE),
        ),
        required_headings=(
            "# 一、文档概述",
            "# 二、总体功能概述",
            "# 三、详细功能设计（核心模块）",
            "# 四、数据设计",
            "# 五、接口设计（简要）",
            "# 六、异常处理设计",
            "# 七、测试要点（参考）",
            "# 八、约束与限制",
            "# 九、附件",
            "# 十、签字确认",
        ),
        title_pattern=re.compile(
            r"^# .+?(?:\s*-\s*(?:开发设计文档|技术开发设计|功能设计文档|FRD)|\s*(?:开发设计文档|技术开发设计|功能设计文档|FRD))$",
            re.IGNORECASE,
        ),
        heading_level="# ",
    ),
    "interfaces": DocumentScopeRule(
        forbidden_patterns=(
            re.compile(r"质量门禁|门禁分|指标评分总表", re.IGNORECASE),
            re.compile(r"架构设计图|时序图|需求优先级划分|需求来源与用户分析", re.IGNORECASE),
        ),
        required_headings=(
            "## 1. 文档概览",
            "## 2. 接口清单",
            "## 3. 接口详情",
            "## 4. 通用错误码",
            "## 5. 安全/幂等/重试",
        ),
        title_pattern=re.compile(r"^# .+$"),
        heading_level="## ",
    ),
    "quality": DocumentScopeRule(
        forbidden_patterns=(
            re.compile(r"接口详情|请求字段|响应字段|幂等与重试", re.IGNORECASE),
            re.compile(r"架构设计图|时序图|功能点设计|需求来源与用户分析", re.IGNORECASE),
        ),
        required_headings=(
            "## 1. 指标评分总表",
            "## 2. 指标解释与计算口径",
            "## 3. 结论",
        ),
        title_pattern=re.compile(r"^# .+ - 质量评估报告$"),
        heading_level="## ",
    ),
}


def enforce_document_scope(
    doc_type: str,
    markdown: str,
    strict: bool = True,
) -> tuple[str, list[str]]:
    """按文档类型执行语义边界约束。

    返回：
    - 清理后的 Markdown 文本；
    - 处理说明列表（清理项与校验提示）。
    """
    rule = _RULES.get(doc_type)
    if rule is None:
        raise ValueError(f"未知文档类型: {doc_type}")

    cleaned, removed = _remove_forbidden_lines(markdown, rule)
    violations = _validate_structure(cleaned, rule)

    notes = [f"[remove] {item}" for item in removed]
    notes.extend(f"[violation] {item}" for item in violations)

    if strict and violations:
        raise ValueError("；".join(violations))
    return cleaned, notes


def _remove_forbidden_lines(markdown: str, rule: DocumentScopeRule) -> tuple[str, list[str]]:
    lines = markdown.splitlines()
    sanitized: list[str] = []
    removed: list[str] = []
    in_code_block = False

    for idx, line in enumerate(lines, start=1):
        stripped = line.strip()
        if stripped.startswith("```"):
            in_code_block = not in_code_block
            sanitized.append(line)
            continue
        if in_code_block:
            sanitized.append(line)
            continue

        matched = next((pattern for pattern in rule.forbidden_patterns if pattern.search(line)), None)
        if matched:
            removed.append(f"L{idx}: 命中越界关键词 `{matched.pattern}` -> {stripped[:120]}")
            continue
        sanitized.append(line)

    cleaned = "\n".join(sanitized).strip() + "\n"
    return cleaned, removed


def _validate_structure(markdown: str, rule: DocumentScopeRule) -> list[str]:
    violations: list[str] = []
    lines = markdown.splitlines()

    title_line = ""
    for line in lines:
        if line.startswith("# "):
            title_line = line.strip()
            break
    if not title_line or not rule.title_pattern.match(title_line):
        violations.append(f"文档标题不符合规则：{title_line or '缺失标题'}")

    headings = _collect_headings(markdown, prefix=rule.heading_level)
    for required in rule.required_headings:
        if required not in headings:
            violations.append(f"缺少必需章节：{required}")

    if rule.heading_level == "# ":
        allowed = set(rule.required_headings)
        for heading in headings:
            if heading == title_line:
                continue
            if heading not in allowed:
                violations.append(f"存在未定义一级章节：{heading}")
    return violations


def _collect_headings(markdown: str, prefix: str) -> list[str]:
    headings: list[str] = []
    in_code_block = False
    for line in markdown.splitlines():
        stripped = line.strip()
        if stripped.startswith("```"):
            in_code_block = not in_code_block
            continue
        if in_code_block:
            continue
        if stripped.startswith(prefix):
            headings.append(stripped)
    return headings
