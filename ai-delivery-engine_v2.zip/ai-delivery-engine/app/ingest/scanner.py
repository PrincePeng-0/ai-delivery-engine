from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

from app.schemas import ContextSnapshot, RepoProfile
from app.utils import dump_json, load_json, now_iso, read_text


MODULE_PATTERN = re.compile(r"<module>\s*([^<\s]+)\s*</module>")
TABLE_PATTERN = re.compile(r'@TableName\("([^"]+)"\)')
CLASS_IMPL_PATTERN = re.compile(r"class\s+([A-Za-z0-9_]+)\s+implements\s+([^{]+)\{")
REF_BEAN_PATTERN = re.compile(r"ReferenceBean<\s*([A-Za-z0-9_$.]+)\s*>")
DATA_SOURCE_PATTERN = re.compile(
    r"(?:datasource|database|schema)\s*[:=]\s*([a-zA-Z0-9_.-]+)",
    flags=re.IGNORECASE,
)
JDBC_DB_PATTERN = re.compile(r"jdbc:[^\s\"']+?/([a-zA-Z0-9_\-]+)")
MYSQL_CONFIG_PATTERN = re.compile(r"mysql57\.([a-zA-Z0-9_]+)")


def _unique(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        value = value.strip()
        if not value:
            continue
        if value in seen:
            continue
        seen.add(value)
        output.append(value)
    return output


def _find_config_files(repo_path: Path) -> list[Path]:
    result: list[Path] = []
    for path in repo_path.rglob("*"):
        if not path.is_file():
            continue
        name = path.name.lower()
        if name.startswith("application") and (name.endswith(".yml") or name.endswith(".yaml")):
            result.append(path)
    return sorted(result)


def _parse_port(config_text: str) -> str:
    dot_match = re.search(r"server\.port\s*[:=]\s*([0-9]{2,5})", config_text)
    if dot_match:
        return dot_match.group(1)
    block_match = re.search(
        r"server:\s*(?:\n[^\n]*){0,8}?\n\s*port:\s*([0-9]{2,5})",
        config_text,
        flags=re.MULTILINE,
    )
    if block_match:
        return block_match.group(1)
    return ""


def _parse_datasources(config_text: str) -> list[str]:
    results = []
    results.extend(DATA_SOURCE_PATTERN.findall(config_text))
    results.extend(JDBC_DB_PATTERN.findall(config_text))
    for item in MYSQL_CONFIG_PATTERN.findall(config_text):
        results.append(f"mysql57.{item}")
    return _unique(results)


def _scan_java(repo_path: Path) -> tuple[list[str], list[str], list[str]]:
    providers: list[str] = []
    references: list[str] = []
    tables: list[str] = []

    for java_file in repo_path.rglob("*.java"):
        try:
            text = read_text(java_file)
        except UnicodeDecodeError:
            continue

        for table in TABLE_PATTERN.findall(text):
            tables.append(table)

        if "@DubboService" in text or "@Service(version" in text:
            impl_match = CLASS_IMPL_PATTERN.search(text)
            if impl_match:
                raw_interfaces = impl_match.group(2)
                for interface_name in raw_interfaces.split(","):
                    providers.append(interface_name.strip().split("<")[0])
            else:
                class_match = re.search(r"class\s+([A-Za-z0-9_]+)", text)
                if class_match:
                    providers.append(class_match.group(1))

        lines = text.splitlines()
        for idx, line in enumerate(lines):
            if "@DubboReference" in line or "@Reference(" in line:
                for next_line in lines[idx + 1 : idx + 6]:
                    private_match = re.search(
                        r"private\s+([A-Za-z0-9_$.<>]+)\s+[A-Za-z0-9_]+\s*;",
                        next_line,
                    )
                    if private_match:
                        references.append(private_match.group(1).split("<")[0].strip())
                        break
        for item in REF_BEAN_PATTERN.findall(text):
            references.append(item.strip())

    return _unique(providers), _unique(references), sorted(_unique(tables))


def _scan_single_repo(repo_path: Path) -> RepoProfile:
    pom_path = repo_path / "pom.xml"
    modules: list[str] = []
    if pom_path.exists():
        pom_text = read_text(pom_path)
        modules = _unique(MODULE_PATTERN.findall(pom_text))

    config_files = _find_config_files(repo_path)
    port = ""
    datasources: list[str] = []
    for config_file in config_files:
        config_text = read_text(config_file)
        if not port:
            port = _parse_port(config_text)
        datasources.extend(_parse_datasources(config_text))

    providers, references, tables = _scan_java(repo_path)

    return RepoProfile(
        name=repo_path.name,
        path=repo_path.name,
        modules=modules,
        port=port,
        datasources=_unique(datasources),
        dubbo_providers=providers,
        dubbo_references=references,
        tables=tables,
    )


def _build_shared_tables(repos: list[RepoProfile]) -> dict[str, list[str]]:
    table_repo_map: dict[str, list[str]] = {}
    for repo in repos:
        for table in repo.tables:
            table_repo_map.setdefault(table, []).append(repo.name)
    shared = {table: sorted(_unique(names)) for table, names in table_repo_map.items() if len(set(names)) > 1}
    return dict(sorted(shared.items(), key=lambda item: item[0]))


def _looks_like_repo(path: Path) -> bool:
    if (path / "pom.xml").exists():
        return True
    if list(path.glob("*/pom.xml")):
        return True
    return next(path.rglob("*.java"), None) is not None


def scan_project_context(project_root: str | Path) -> ContextSnapshot:
    root = Path(project_root).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"项目根目录不存在: {root}")

    repos = []
    for path in sorted(root.iterdir()):
        if not path.is_dir():
            continue
        if path.name.startswith("."):
            continue
        if not _looks_like_repo(path):
            continue
        repos.append(_scan_single_repo(path))

    shared_tables = _build_shared_tables(repos)
    return ContextSnapshot(
        generated_at=now_iso(),
        project_root="{{PROJECT_ROOT}}",
        repos=repos,
        shared_tables=shared_tables,
    )


def save_context_snapshot(path: str | Path, snapshot: ContextSnapshot) -> None:
    dump_json(Path(path), snapshot.to_dict())


def load_context_snapshot(path: str | Path) -> ContextSnapshot:
    data = load_json(Path(path))
    return ContextSnapshot.from_dict(data)
