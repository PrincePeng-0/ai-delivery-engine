from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Any

from app.schemas import ContextSnapshot, ImpactItem, RequirementInput

try:
    from openai import OpenAI  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    OpenAI = None


JSON_CODE_BLOCK_PATTERN = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.IGNORECASE | re.DOTALL)


@dataclass
class LLMStatus:
    enabled: bool
    ready: bool
    model: str
    reason: str = ""


class LLMClient:
    """Thin wrapper around OpenAI Chat Completions with resilient JSON parsing."""

    def __init__(self, enabled: bool = True, model: str | None = None) -> None:
        env_model = os.getenv("OPENAI_MODEL", "").strip()
        self._model = (model or env_model or "gpt-5").strip()
        self._enabled = enabled
        self._reason = ""
        self._client = None

        if not self._enabled:
            self._reason = "LLM disabled by configuration."
            return

        if OpenAI is None:
            self._reason = "The `openai` package is not installed."
            return

        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        if not api_key:
            self._reason = "OPENAI_API_KEY is not set."
            return

        kwargs: dict[str, Any] = {"api_key": api_key}
        base_url = os.getenv("OPENAI_BASE_URL", "").strip()
        if base_url:
            kwargs["base_url"] = base_url

        try:
            self._client = OpenAI(**kwargs)
        except Exception as exc:
            self._reason = f"Failed to initialize OpenAI client: {exc}"

    @property
    def model(self) -> str:
        return self._model

    @property
    def is_ready(self) -> bool:
        return self._client is not None

    def status(self) -> LLMStatus:
        return LLMStatus(
            enabled=self._enabled,
            ready=self.is_ready,
            model=self._model,
            reason=self._reason,
        )

    def generate_json(
        self,
        system_prompt: str,
        user_prompt: str,
        retries: int = 2,
    ) -> Any:
        if not self.is_ready or self._client is None:
            raise RuntimeError(self._reason or "LLM client is not ready.")

        messages: list[dict[str, str]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        last_error: Exception | None = None
        for _ in range(max(1, retries)):
            try:
                response = self._client.chat.completions.create(
                    model=self._model,
                    messages=messages,
                )
                content = _extract_message_text(response)
                return _parse_json_from_text(content)
            except Exception as exc:
                last_error = exc
                messages.append(
                    {
                        "role": "user",
                        "content": "The previous output is not valid JSON. Return one valid JSON object only.",
                    }
                )

        sanitized_error = _sanitize_error_message(last_error)
        raise RuntimeError(f"LLM JSON generation failed: {sanitized_error}")


def context_snapshot_brief(
    context: ContextSnapshot,
    max_tables_per_repo: int = 12,
    max_shared_tables: int = 20,
) -> str:
    repos: list[dict[str, Any]] = []
    for repo in context.repos:
        repos.append(
            {
                "name": repo.name,
                "port": repo.port,
                "modules": repo.modules[:20],
                "datasources": repo.datasources[:20],
                "dubbo_providers": repo.dubbo_providers[:30],
                "dubbo_references": repo.dubbo_references[:30],
                "tables_sample": repo.tables[:max_tables_per_repo],
                "tables_count": len(repo.tables),
            }
        )

    shared_tables = []
    for table, owners in list(context.shared_tables.items())[:max_shared_tables]:
        shared_tables.append({"table": table, "repos": owners})

    payload = {
        "generated_at": context.generated_at,
        "project_root": context.project_root,
        "repo_count": len(context.repos),
        "repos": repos,
        "shared_tables_sample": shared_tables,
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


def requirement_brief(requirement: RequirementInput) -> str:
    return json.dumps(requirement.to_dict(), ensure_ascii=False, indent=2)


def impacts_brief(impacts: list[ImpactItem]) -> str:
    payload = [item.to_dict() for item in impacts]
    return json.dumps(payload, ensure_ascii=False, indent=2)


def ensure_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    if isinstance(value, str):
        return value.strip() or default
    return str(value).strip() or default


def ensure_str_list(value: Any) -> list[str]:
    if isinstance(value, list):
        output: list[str] = []
        for item in value:
            text = ensure_str(item)
            if text:
                output.append(text)
        return output

    text = ensure_str(value)
    if not text:
        return []
    return [text]


def ensure_dict_list_str(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    output: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        normalized: dict[str, str] = {}
        for key, val in item.items():
            normalized[str(key)] = ensure_str(val)
        if normalized:
            output.append(normalized)
    return output


def _extract_message_text(response: Any) -> str:
    choices = getattr(response, "choices", None)
    if not choices:
        raise ValueError("Missing choices in LLM response.")

    message = choices[0].message
    content = getattr(message, "content", None)

    if isinstance(content, str):
        return content.strip()

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
                continue
            text = getattr(item, "text", None)
            if isinstance(text, str):
                parts.append(text)
                continue
            if isinstance(item, dict):
                text2 = item.get("text")
                if isinstance(text2, str):
                    parts.append(text2)
        merged = "\n".join(part for part in parts if part.strip()).strip()
        if merged:
            return merged

    text_attr = getattr(message, "text", None)
    if isinstance(text_attr, str):
        return text_attr.strip()

    raise ValueError("Unable to read text content from LLM response.")


def _parse_json_from_text(text: str) -> Any:
    candidates: list[str] = []
    plain = text.strip()
    if plain:
        candidates.append(plain)

    for match in JSON_CODE_BLOCK_PATTERN.finditer(text):
        block = match.group(1).strip()
        if block:
            candidates.append(block)

    balanced = _extract_balanced_json(text)
    if balanced:
        candidates.append(balanced)

    last_error: Exception | None = None
    for candidate in candidates:
        try:
            return json.loads(candidate)
        except Exception as exc:  # noqa: PERF203
            last_error = exc

    raise ValueError(f"Unable to parse JSON from model output: {last_error}")


def _sanitize_error_message(error: Exception | None) -> str:
    if error is None:
        return "unknown error"
    message = str(error).replace("\n", " ").strip()
    message = re.sub(r"sk-[A-Za-z0-9*_\-]+", "sk-***", message)
    if len(message) > 320:
        return message[:317] + "..."
    return message


def _extract_balanced_json(text: str) -> str:
    start = -1
    stack: list[str] = []
    in_string = False
    escaped = False

    for idx, ch in enumerate(text):
        if start < 0:
            if ch in ("{", "["):
                start = idx
                stack = [ch]
            continue

        if in_string:
            if escaped:
                escaped = False
                continue
            if ch == "\\":
                escaped = True
                continue
            if ch == '"':
                in_string = False
            continue

        if ch == '"':
            in_string = True
            continue

        if ch in ("{", "["):
            stack.append(ch)
            continue

        if ch in ("}", "]"):
            if not stack:
                return ""
            opening = stack.pop()
            if (opening == "{" and ch != "}") or (opening == "[" and ch != "]"):
                return ""
            if not stack:
                return text[start : idx + 1]

    return ""
