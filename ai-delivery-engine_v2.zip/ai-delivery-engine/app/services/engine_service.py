from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Literal

from app.exporters import build_apifox_openapi, build_postman_collection
from app.ingest import load_context_snapshot, save_context_snapshot, scan_project_context
from app.kb import build_knowledge_provider
from app.render import (
    render_api_markdown,
    render_design_markdown,
    render_quality_assessment_markdown,
    render_requirement_analysis_markdown,
)
from app.rules import load_public_rulebook, load_quality_gate_policy
from app.utils import dump_json, read_text, write_text
from app.validators import enforce_document_scope
from app.workflow import AIDeliveryEngineWorkflow, load_langgraph_workflow_class


Logger = Callable[[str], None]
OrchestratorType = Literal["classic", "langgraph"]


@dataclass
class CommandExecutionResult:
    exit_code: int
    logs: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.exit_code == 0


@dataclass
class GenerateExecutionResult(CommandExecutionResult):
    artifacts: dict[str, str] = field(default_factory=dict)
    quality_gate_decision: str = ""
    quality_gate_score: str = ""


def _create_logger(logger: Logger | None) -> tuple[Logger, list[str]]:
    logs: list[str] = []

    def _log(message: str) -> None:
        line = str(message).rstrip()
        logs.append(line)
        if logger is not None:
            logger(line)

    return _log, logs


def _build_workflow(
    orchestrator: str,
    use_llm: bool,
    model: str | None,
    allow_fallback: bool,
    knowledge_dir: str,
    strict_kb: bool,
    rulebook: Any,
    knowledge_provider: Any,
    quality_gate_policy: dict[str, Any],
    quality_gate_policy_source: str,
    node_retry_max_attempts: int,
    node_retry_backoff_ms: int,
) -> AIDeliveryEngineWorkflow:
    orchestrator_name = str(orchestrator or "langgraph").strip().lower()
    workflow_cls: type[AIDeliveryEngineWorkflow]

    if orchestrator_name == "classic":
        workflow_cls = AIDeliveryEngineWorkflow
    elif orchestrator_name == "langgraph":
        try:
            workflow_cls = load_langgraph_workflow_class()
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError(f"LangGraph orchestrator is unavailable: {exc}") from exc
        if workflow_cls is None:
            raise RuntimeError("LangGraph orchestrator is unavailable. Please install `langgraph`.")
    else:
        raise RuntimeError(f"Unsupported orchestrator: {orchestrator}")

    return workflow_cls(
        use_llm=use_llm,
        model=model,
        allow_fallback=allow_fallback,
        knowledge_dir=knowledge_dir,
        rulebook=rulebook,
        knowledge_provider=knowledge_provider,
        strict_kb=strict_kb,
        quality_gate_policy=quality_gate_policy,
        quality_gate_policy_source=quality_gate_policy_source,
        node_retry_max_attempts=node_retry_max_attempts,
        node_retry_backoff_ms=node_retry_backoff_ms,
    )


def artifact_base_name(requirement_file: str) -> str:
    """把需求文件名转换为安全的产物前缀。"""
    stem = Path(requirement_file).stem.strip()
    if not stem:
        stem = "Requirement"
    return re.sub(r'[\\/:*?"<>|]+', "_", stem)


def execute_scan_context(
    project_root: str,
    output: str,
    logger: Logger | None = None,
) -> CommandExecutionResult:
    log, logs = _create_logger(logger)
    try:
        snapshot = scan_project_context(project_root)
        save_context_snapshot(output, snapshot)
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] 上下文扫描失败: {exc}")
        return CommandExecutionResult(exit_code=2, logs=logs)

    log(f"[OK] 上下文已生成: {Path(output).resolve()}")
    log(f"[INFO] 扫描仓库数: {len(snapshot.repos)}")
    log(f"[INFO] 共享表数量: {len(snapshot.shared_tables)}")
    return CommandExecutionResult(exit_code=0, logs=logs)


def execute_generate(
    requirement_file: str,
    out_dir: str,
    templates_dir: str,
    knowledge_dir: str,
    kb_mode: str,
    kb_dir: str,
    kb_url: str,
    kb_token: str,
    kb_namespace: str,
    kb_cache_dir: str,
    strict_kb: bool,
    rules_dir: str,
    project_root: str | None,
    context_file: str | None,
    disable_llm: bool,
    model: str | None,
    strict_llm: bool,
    quality_gate_policy_file: str,
    enforce_quality_gate: bool,
    orchestrator: OrchestratorType = "langgraph",
    node_retry_max_attempts: int = 2,
    node_retry_backoff_ms: int = 200,
    logger: Logger | None = None,
) -> GenerateExecutionResult:
    """执行生成主流程并返回结构化结果，供 CLI 与 API 共享。"""
    log, logs = _create_logger(logger)

    if context_file:
        context = load_context_snapshot(context_file)
    else:
        if not project_root:
            log("[ERROR] 必须提供 --context-file 或 --project-root")
            return GenerateExecutionResult(exit_code=2, logs=logs)
        context = scan_project_context(project_root)

    requirement_text = read_text(Path(requirement_file))
    resolved_kb_token = kb_token or os.getenv("PUBLIC_KB_TOKEN", "")
    try:
        knowledge_provider = build_knowledge_provider(
            kb_mode=kb_mode,
            kb_namespace=kb_namespace,
            kb_dir=kb_dir,
            kb_url=kb_url,
            kb_token=resolved_kb_token,
            kb_cache_dir=kb_cache_dir,
        )
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] 公共知识库初始化失败: {exc}")
        return GenerateExecutionResult(exit_code=2, logs=logs)

    try:
        rulebook = load_public_rulebook(rules_dir=rules_dir, strict=True)
    except FileNotFoundError as exc:
        log(f"[ERROR] 公共规则库不可用: {exc}")
        log("[ERROR] 请由使用方在 --rules-dir 下提供完整规则文件后重试。")
        return GenerateExecutionResult(exit_code=2, logs=logs)

    try:
        quality_gate_policy, quality_gate_policy_source = load_quality_gate_policy(
            policy_file=quality_gate_policy_file,
            rules_dir=rules_dir,
            strict=bool(str(quality_gate_policy_file).strip()),
        )
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] 质量门禁策略加载失败: {exc}")
        return GenerateExecutionResult(exit_code=2, logs=logs)

    try:
        workflow = _build_workflow(
            orchestrator=orchestrator,
            use_llm=not disable_llm,
            model=model,
            allow_fallback=not strict_llm,
            knowledge_dir=knowledge_dir,
            strict_kb=strict_kb,
            rulebook=rulebook,
            knowledge_provider=knowledge_provider,
            quality_gate_policy=quality_gate_policy,
            quality_gate_policy_source=quality_gate_policy_source,
            node_retry_max_attempts=node_retry_max_attempts,
            node_retry_backoff_ms=node_retry_backoff_ms,
        )
    except RuntimeError as exc:
        log(f"[ERROR] {exc}")
        return GenerateExecutionResult(exit_code=2, logs=logs)

    runtime_mode = workflow.runtime_mode()
    runtime_message = workflow.runtime_message()
    if runtime_mode == "llm":
        log(f"[INFO] {runtime_message}")
    elif runtime_mode == "rules-fallback" and not disable_llm:
        log(f"[WARN] {runtime_message}")
    else:
        log(f"[INFO] {runtime_message}")
    log(f"[INFO] 公共知识库模式: {kb_mode}")
    log(f"[INFO] 公共知识命名空间: {kb_namespace}")
    log(f"[INFO] 公共规则库: {rulebook.source_dir}")
    log(f"[INFO] 质量门禁策略: {quality_gate_policy_source}")
    log(f"[INFO] 编排器: {str(orchestrator).lower()}")
    log(f"[INFO] 节点重试策略: max_attempts={int(node_retry_max_attempts)}, backoff_ms={int(node_retry_backoff_ms)}")

    base_name = artifact_base_name(requirement_file)
    try:
        result = workflow.run(requirement_text, context, requirement_name=base_name)
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] 生成失败: {exc}")
        return GenerateExecutionResult(exit_code=2, logs=logs)

    target_dir = Path(out_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    tpl_dir = Path(templates_dir)
    design_tpl = tpl_dir / "Funditional Requirement Document.md"
    api_tpl = tpl_dir / "api_doc.md.j2"
    analysis_tpl = tpl_dir / "Requirement Analysis Report Template.md"
    if not design_tpl.exists() or not api_tpl.exists() or not analysis_tpl.exists():
        log(f"[ERROR] 模板不存在，请检查目录: {tpl_dir.resolve()}")
        return GenerateExecutionResult(exit_code=2, logs=logs)

    design_md = render_design_markdown(result.design_doc, design_tpl)
    api_md = render_api_markdown(result.api_doc, api_tpl)
    analysis_md = render_requirement_analysis_markdown(
        requirement=result.requirement,
        impacts=result.impacts,
        context=context,
        template_path=analysis_tpl,
        requirement_breakdown=result.requirement_breakdown,
        public_knowledge=result.public_knowledge,
    )
    quality_assessment_md = render_quality_assessment_markdown(
        requirement=result.requirement,
        quality_report=result.quality_report,
        quality_gate=result.quality_gate,
        validation=result.validation.to_dict(),
        public_knowledge=result.public_knowledge,
    )

    try:
        analysis_md, analysis_scope_notes = enforce_document_scope("analysis", analysis_md, strict=True)
        design_md, frd_scope_notes = enforce_document_scope("frd", design_md, strict=True)
        api_md, interface_scope_notes = enforce_document_scope("interfaces", api_md, strict=True)
        quality_assessment_md, quality_scope_notes = enforce_document_scope("quality", quality_assessment_md, strict=True)
    except ValueError as exc:
        log(f"[ERROR] 文档语义边界校验失败: {exc}")
        return GenerateExecutionResult(exit_code=2, logs=logs)

    analysis_path = target_dir / f"{base_name}_Analysis_Report.md"
    frd_path = target_dir / f"{base_name}_FRD.md"
    interfaces_path = target_dir / f"{base_name}_Interfaces.md"
    quality_assessment_path = target_dir / f"{base_name}_Quality_Assessment.md"
    postman_path = target_dir / f"{base_name}_Interfaces_Postman.json"
    apifox_path = target_dir / f"{base_name}_Interfaces_Apifox.json"
    execution_trace_path = target_dir / f"{base_name}_Execution_Trace.json"

    write_text(analysis_path, analysis_md)
    write_text(frd_path, design_md)
    write_text(interfaces_path, api_md)
    write_text(quality_assessment_path, quality_assessment_md)
    dump_json(postman_path, build_postman_collection(result.api_doc))
    dump_json(apifox_path, build_apifox_openapi(result.api_doc))
    runtime_stats = result.quality_report.get("runtime_stats", {}) if isinstance(result.quality_report, dict) else {}
    execution_trace = {
        "orchestrator": str(orchestrator).lower(),
        "node_retry_policy": {
            "max_attempts": int(node_retry_max_attempts),
            "backoff_ms": int(node_retry_backoff_ms),
        },
        "runtime_stats": runtime_stats if isinstance(runtime_stats, dict) else {},
    }
    dump_json(execution_trace_path, execution_trace)

    log(f"[OK] 需求分析报告: {analysis_path.resolve()}")
    log(f"[OK] 开发设计文档(FRD): {frd_path.resolve()}")
    log(f"[OK] 接口文档: {interfaces_path.resolve()}")
    log(f"[OK] 质量评估文档: {quality_assessment_path.resolve()}")
    log(f"[OK] Postman JSON: {postman_path.resolve()}")
    log(f"[OK] Apifox JSON(OpenAPI): {apifox_path.resolve()}")
    log(f"[OK] 执行追踪(JSON): {execution_trace_path.resolve()}")
    if analysis_scope_notes or frd_scope_notes or interface_scope_notes or quality_scope_notes:
        log("[OK] 文档语义边界校验:")
        log(f"  - Analysis_Report notes: {len(analysis_scope_notes)}")
        log(f"  - FRD notes: {len(frd_scope_notes)}")
        log(f"  - Interfaces notes: {len(interface_scope_notes)}")
        log(f"  - Quality_Assessment notes: {len(quality_scope_notes)}")
    if result.public_knowledge:
        log("[OK] 公共知识库命中摘要:")
        log(f"  - source: {result.public_knowledge.get('source', '')}")
        log(f"  - namespace: {result.public_knowledge.get('namespace', '')}")
        log(f"  - domain_systems: {len(result.public_knowledge.get('domain_systems', []))}")
        log(f"  - requirement_patterns: {len(result.public_knowledge.get('requirement_patterns', []))}")
        log(f"  - architecture_patterns: {len(result.public_knowledge.get('architecture_patterns', []))}")
        log(f"  - interface_patterns: {len(result.public_knowledge.get('interface_patterns', []))}")
        log(f"  - coding_standards: {len(result.public_knowledge.get('coding_standards', []))}")
        log(f"  - recent_cases: {len(result.public_knowledge.get('recent_cases', []))}")
    if result.quality_report:
        log("[OK] 质量评估:")
        log(f"  - semantic_hit_count: {result.quality_report.get('semantic_hit_count', '0')}")
        log(f"  - semantic_avg_score: {result.quality_report.get('semantic_avg_score', '0.0000')}")
        log(f"  - citation_coverage_ratio: {result.quality_report.get('citation_coverage_ratio', '0.0000')}")
        log(
            "  - hallucination_risk: "
            f"{result.quality_report.get('hallucination_risk_level', 'UNKNOWN')}"
            f" (score={result.quality_report.get('hallucination_risk_score', '0')})"
        )
        runtime_stats = result.quality_report.get("runtime_stats", {})
        retry_summary = runtime_stats.get("node_retry_summary", {}) if isinstance(runtime_stats, dict) else {}
        if isinstance(retry_summary, dict) and retry_summary:
            log("[INFO] LangGraph 节点执行摘要:")
            for node_name, node_info in retry_summary.items():
                if not isinstance(node_info, dict):
                    continue
                log(
                    "  - "
                    f"{node_name}: attempts={node_info.get('attempts', 0)}, "
                    f"retries={node_info.get('retries', 0)}, "
                    f"failed={node_info.get('failed', 0)}"
                )
    if result.quality_gate:
        log("[OK] 质量门禁:")
        log(f"  - decision: {result.quality_gate.get('decision', 'UNKNOWN')}")
        log(f"  - score: {result.quality_gate.get('score', '0')}")
        log(f"  - policy_source: {result.quality_gate.get('policy_source', '')}")
        if result.quality_gate.get("blocking_issues"):
            log("  - blocking_issues:")
            for item in result.quality_gate.get("blocking_issues", []):
                log(f"    - {item}")
    if result.public_kb_draft:
        log("[OK] 公共知识库草稿回写:")
        log(f"  - provider: {result.public_kb_draft.get('provider', '')}")
        log(f"  - draft_id: {result.public_kb_draft.get('draft_id', '')}")
        log(f"  - status: {result.public_kb_draft.get('status', '')}")
        log(f"  - approval_status: {result.public_kb_draft.get('approval_status', '')}")
        if result.public_kb_draft.get("path"):
            log(f"  - path: {result.public_kb_draft.get('path', '')}")
        if result.public_kb_draft.get("audit_path"):
            log(f"  - audit_path: {result.public_kb_draft.get('audit_path', '')}")
    if result.public_kb_audit:
        log(f"[INFO] 公共知识库审计事件（最近 {len(result.public_kb_audit)} 条）")
    log("[OK] 领域知识库与skills(累计):")
    for key, value in result.knowledge_assets.items():
        log(f"  - {key}: {value}")
    if result.validation.errors:
        log("[WARN] 存在校验错误：")
        for item in result.validation.errors:
            log(f"  - {item}")
    if result.validation.warnings:
        log("[WARN] 存在校验提醒：")
        for item in result.validation.warnings:
            log(f"  - {item}")

    exit_code = 0 if result.validation.passed else 1
    gate_decision = str(result.quality_gate.get("decision", "")).upper() if result.quality_gate else ""
    if enforce_quality_gate and gate_decision == "BLOCK":
        log("[ERROR] 质量门禁为 BLOCK，--enforce-quality-gate 已启用，返回失败。")
        exit_code = 1
    elif gate_decision == "BLOCK":
        log("[WARN] 当前质量门禁为 BLOCK（未启用 enforce 模式，流程继续）。")

    artifacts = {
        "analysis_report": str(analysis_path.resolve()),
        "frd": str(frd_path.resolve()),
        "interfaces_markdown": str(interfaces_path.resolve()),
        "quality_assessment": str(quality_assessment_path.resolve()),
        "interfaces_postman_json": str(postman_path.resolve()),
        "interfaces_apifox_json": str(apifox_path.resolve()),
        "execution_trace_json": str(execution_trace_path.resolve()),
    }
    return GenerateExecutionResult(
        exit_code=exit_code,
        logs=logs,
        artifacts=artifacts,
        quality_gate_decision=gate_decision,
        quality_gate_score=str(result.quality_gate.get("score", "")) if result.quality_gate else "",
    )


def execute_kb_review(
    draft_id: str,
    approval_status: str,
    reviewer: str,
    note: str,
    kb_mode: str,
    kb_dir: str,
    kb_url: str,
    kb_token: str,
    kb_namespace: str,
    kb_cache_dir: str,
    logger: Logger | None = None,
) -> CommandExecutionResult:
    log, logs = _create_logger(logger)
    resolved_kb_token = kb_token or os.getenv("PUBLIC_KB_TOKEN", "")
    try:
        knowledge_provider = build_knowledge_provider(
            kb_mode=kb_mode,
            kb_namespace=kb_namespace,
            kb_dir=kb_dir,
            kb_url=kb_url,
            kb_token=resolved_kb_token,
            kb_cache_dir=kb_cache_dir,
        )
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] 公共知识库初始化失败: {exc}")
        return CommandExecutionResult(exit_code=2, logs=logs)

    try:
        receipt = knowledge_provider.update_draft_status(
            draft_id=draft_id,
            status=approval_status,
            reviewer=reviewer,
            note=note,
        )
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] 草稿审批更新失败: {exc}")
        return CommandExecutionResult(exit_code=2, logs=logs)

    log("[OK] 公共知识库草稿审批已更新:")
    log(f"  - provider: {receipt.get('provider', '')}")
    log(f"  - draft_id: {receipt.get('draft_id', '')}")
    log(f"  - approval_status: {receipt.get('approval_status', '')}")
    log(f"  - reviewed_by: {receipt.get('reviewed_by', '')}")
    log(f"  - reviewed_at: {receipt.get('reviewed_at', '')}")
    if receipt.get("message"):
        log(f"  - message: {receipt.get('message', '')}")
    if receipt.get("path"):
        log(f"  - path: {receipt.get('path', '')}")
    return CommandExecutionResult(exit_code=0, logs=logs)
