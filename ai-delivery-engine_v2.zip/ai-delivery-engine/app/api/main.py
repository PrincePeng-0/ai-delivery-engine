from __future__ import annotations

import os
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock
from typing import Any, Literal

from fastapi import Depends, FastAPI, HTTPException, Query, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

from app.services import execute_generate, execute_kb_review, execute_scan_context
from app.utils import dump_json, load_json


KbMode = Literal["local", "remote", "hybrid"]
ApprovalStatus = Literal["PENDING_REVIEW", "APPROVED", "REJECTED"]
TaskStatus = Literal["PENDING", "RUNNING", "CANCELLING", "CANCELLED", "SUCCEEDED", "FAILED"]
OrchestratorMode = Literal["classic", "langgraph"]


class ScanContextRequest(BaseModel):
    project_root: str = Field(..., description="待扫描的项目根目录。")
    output: str = Field(default="outputs/context_snapshot.json", description="上下文快照输出路径。")


class GenerateRequest(BaseModel):
    requirement_file: str = Field(..., description="需求文档文件路径。")
    project_root: str | None = Field(default=None, description="项目根目录。若未传 context_file 则必填。")
    context_file: str | None = Field(default=None, description="上下文快照 JSON 路径。")
    out_dir: str = Field(default="outputs/latest", description="产物输出目录。")
    templates_dir: str = Field(default="templates", description="模板目录。")
    knowledge_dir: str = Field(default="knowledge_base", description="领域知识库目录。")
    kb_mode: KbMode = Field(default="local", description="公共知识库接入模式。")
    kb_dir: str = Field(default="public_knowledge_base", description="本地公共知识库目录。")
    kb_url: str = Field(default="", description="公共知识库服务地址。")
    kb_token: str = Field(default="", description="公共知识库访问令牌。")
    kb_namespace: str = Field(default="default", description="公共知识命名空间。")
    kb_cache_dir: str = Field(default="outputs/kb_cache", description="公共知识缓存目录。")
    strict_kb: bool = Field(default=False, description="知识库不可用是否直接失败。")
    rules_dir: str = Field(default="knowledge_base/public_rules", description="公共规则库目录。")
    disable_llm: bool = Field(default=False, description="关闭 LLM，使用规则模式。")
    model: str | None = Field(default=None, description="LLM 模型名。")
    strict_llm: bool = Field(default=False, description="LLM 不可用时是否直接失败。")
    orchestrator: OrchestratorMode = Field(default="langgraph", description="流程编排器（默认 langgraph）。")
    node_retry_max_attempts: int = Field(default=2, ge=1, description="LangGraph 节点失败重试总尝试次数（含首次执行）。")
    node_retry_backoff_ms: int = Field(default=200, ge=0, description="LangGraph 节点重试退避时长（毫秒，线性退避）。")
    quality_gate_policy_file: str = Field(default="", description="质量门禁策略 JSON 文件路径。")
    enforce_quality_gate: bool = Field(default=False, description="门禁 BLOCK 时是否返回失败码。")


class KbReviewRequest(BaseModel):
    draft_id: str = Field(..., description="草稿 ID。")
    approval_status: ApprovalStatus = Field(..., description="审批状态。")
    reviewer: str = Field(default="", description="审批人。")
    note: str = Field(default="", description="审批备注。")
    kb_mode: KbMode = Field(default="local", description="公共知识库接入模式。")
    kb_dir: str = Field(default="public_knowledge_base", description="本地公共知识库目录。")
    kb_url: str = Field(default="", description="公共知识库服务地址。")
    kb_token: str = Field(default="", description="公共知识库访问令牌。")
    kb_namespace: str = Field(default="default", description="公共知识命名空间。")
    kb_cache_dir: str = Field(default="outputs/kb_cache", description="公共知识缓存目录。")


class CommandResponse(BaseModel):
    success: bool
    exit_code: int
    logs: str = ""


class ScanContextResponse(CommandResponse):
    output: str = ""


class GenerateResponse(CommandResponse):
    artifacts: dict[str, str] = Field(default_factory=dict)


class KbReviewResponse(CommandResponse):
    draft_id: str = ""
    approval_status: str = ""


class AsyncTaskSubmitResponse(BaseModel):
    task_id: str
    status: TaskStatus


class AsyncTaskStatusResponse(BaseModel):
    task_id: str
    status: TaskStatus
    created_at: str
    started_at: str = ""
    completed_at: str = ""
    cancel_requested: bool = False
    success: bool | None = None
    exit_code: int | None = None
    logs: str = ""
    artifacts: dict[str, str] = Field(default_factory=dict)
    error: str = ""
    message: str = ""


class AsyncTaskListResponse(BaseModel):
    total: int
    items: list[AsyncTaskStatusResponse] = Field(default_factory=list)


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _task_store_path() -> Path:
    """任务持久化文件路径。

    可通过环境变量 `API_TASK_STORE_FILE` 覆盖，默认：
    `outputs/api_tasks/tasks.json`。
    """
    path = os.getenv("API_TASK_STORE_FILE", "outputs/api_tasks/tasks.json").strip() or "outputs/api_tasks/tasks.json"
    return Path(path).expanduser().resolve()


def _configured_tokens() -> set[str]:
    raw = os.getenv("API_BEARER_TOKENS", "").strip()
    single = os.getenv("API_BEARER_TOKEN", "").strip()
    if not raw and single:
        raw = single
    return {token.strip() for token in raw.split(",") if token.strip()}


_bearer_scheme = HTTPBearer(auto_error=False)


def require_api_token(credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme)) -> None:
    """可选 Bearer 鉴权。

    - 未配置 `API_BEARER_TOKEN(S)`：不鉴权；
    - 已配置：所有非健康检查接口都要求 Bearer Token。
    """
    tokens = _configured_tokens()
    if not tokens:
        return
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token.")
    if credentials.credentials not in tokens:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid bearer token.")


app = FastAPI(
    title="AI Delivery Engine API",
    description="将既有 CLI 能力服务化，并支持鉴权与异步任务执行。",
    version="0.3.0",
)

_task_executor = ThreadPoolExecutor(max_workers=max(1, int(os.getenv("API_TASK_WORKERS", "2"))))
_task_lock = Lock()
_tasks: dict[str, dict[str, Any]] = {}
_task_futures: dict[str, Future[Any]] = {}


def _persist_tasks_locked() -> None:
    """持久化任务状态到本地 JSON 文件。"""
    ordered = sorted(_tasks.values(), key=lambda item: str(item.get("created_at", "")), reverse=True)
    dump_json(_task_store_path(), {"tasks": ordered})


def _normalize_task(raw: dict[str, Any]) -> dict[str, Any]:
    task_id = str(raw.get("task_id", "")).strip()
    if not task_id:
        task_id = f"task_{uuid.uuid4().hex[:12]}"
    status_text = str(raw.get("status", "FAILED")).upper()
    allowed = {"PENDING", "RUNNING", "CANCELLING", "CANCELLED", "SUCCEEDED", "FAILED"}
    if status_text not in allowed:
        status_text = "FAILED"
    return {
        "task_id": task_id,
        "status": status_text,
        "created_at": str(raw.get("created_at", "")) or _now_iso(),
        "started_at": str(raw.get("started_at", "")),
        "completed_at": str(raw.get("completed_at", "")),
        "cancel_requested": bool(raw.get("cancel_requested", False)),
        "success": raw.get("success", None),
        "exit_code": raw.get("exit_code", None),
        "logs": str(raw.get("logs", "")),
        "artifacts": raw.get("artifacts", {}) if isinstance(raw.get("artifacts", {}), dict) else {},
        "error": str(raw.get("error", "")),
        "message": str(raw.get("message", "")),
    }


def _load_tasks_from_disk() -> None:
    """加载持久化任务。

    若服务重启时存在 `PENDING/RUNNING/CANCELLING` 任务，无法恢复执行，
    会统一标记为 `FAILED` 并附带说明，避免状态悬挂。
    """
    path = _task_store_path()
    if not path.exists():
        return
    try:
        payload = load_json(path)
    except Exception:  # noqa: BLE001
        return

    items = payload.get("tasks", []) if isinstance(payload, dict) else []
    if not isinstance(items, list):
        return

    with _task_lock:
        for item in items:
            if not isinstance(item, dict):
                continue
            task = _normalize_task(item)
            if task["status"] in {"PENDING", "RUNNING", "CANCELLING"}:
                task["status"] = "FAILED"
                task["completed_at"] = _now_iso()
                task["success"] = False
                task["exit_code"] = 2
                task["error"] = "Service restarted before the async task finished."
                task["message"] = "任务在服务重启前未完成，已标记为失败。"
            _tasks[task["task_id"]] = task
        _persist_tasks_locked()


def _task_response_payload(task: dict[str, Any]) -> dict[str, Any]:
    return {
        "task_id": str(task.get("task_id", "")),
        "status": str(task.get("status", "FAILED")),
        "created_at": str(task.get("created_at", "")),
        "started_at": str(task.get("started_at", "")),
        "completed_at": str(task.get("completed_at", "")),
        "cancel_requested": bool(task.get("cancel_requested", False)),
        "success": task.get("success", None),
        "exit_code": task.get("exit_code", None),
        "logs": str(task.get("logs", "")),
        "artifacts": task.get("artifacts", {}) if isinstance(task.get("artifacts", {}), dict) else {},
        "error": str(task.get("error", "")),
        "message": str(task.get("message", "")),
    }


def _new_task(task_id: str) -> dict[str, Any]:
    return {
        "task_id": task_id,
        "status": "PENDING",
        "created_at": _now_iso(),
        "started_at": "",
        "completed_at": "",
        "cancel_requested": False,
        "success": None,
        "exit_code": None,
        "logs": "",
        "artifacts": {},
        "error": "",
        "message": "",
    }


def _submit_generate_task(request_payload: dict[str, Any]) -> str:
    task_id = f"task_{uuid.uuid4().hex[:12]}"
    with _task_lock:
        _tasks[task_id] = _new_task(task_id)
        _persist_tasks_locked()
    future = _task_executor.submit(_run_generate_task, task_id, request_payload)
    with _task_lock:
        _task_futures[task_id] = future
    return task_id


def _run_generate_task(task_id: str, request_payload: dict[str, Any]) -> None:
    with _task_lock:
        task = _tasks.get(task_id)
        if task is None:
            return
        if task.get("cancel_requested"):
            task["status"] = "CANCELLED"
            task["completed_at"] = _now_iso()
            task["success"] = False
            task["exit_code"] = 1
            task["message"] = "任务在执行前被取消。"
            _persist_tasks_locked()
            _task_futures.pop(task_id, None)
            return
        task["status"] = "RUNNING"
        task["started_at"] = _now_iso()
        _persist_tasks_locked()

    try:
        result = execute_generate(**request_payload)
        with _task_lock:
            task = _tasks.get(task_id)
            if task is None:
                return
            if task.get("cancel_requested"):
                task["status"] = "CANCELLED"
                task["message"] = "任务已收到取消请求，当前执行结果已丢弃。"
                task["success"] = False
                task["exit_code"] = 1
                task["logs"] = "\n".join(result.logs)
                task["artifacts"] = {}
            else:
                task["status"] = "SUCCEEDED" if result.exit_code == 0 else "FAILED"
                task["success"] = result.ok
                task["exit_code"] = result.exit_code
                task["logs"] = "\n".join(result.logs)
                task["artifacts"] = result.artifacts
            task["completed_at"] = _now_iso()
            _persist_tasks_locked()
    except Exception as exc:  # noqa: BLE001
        with _task_lock:
            task = _tasks.get(task_id)
            if task is None:
                return
            task["status"] = "FAILED"
            task["completed_at"] = _now_iso()
            task["success"] = False
            task["exit_code"] = 2
            task["error"] = str(exc)
            _persist_tasks_locked()
    finally:
        with _task_lock:
            _task_futures.pop(task_id, None)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/scan-context", response_model=ScanContextResponse, dependencies=[Depends(require_api_token)])
def scan_context(request: ScanContextRequest) -> ScanContextResponse:
    result = execute_scan_context(
        project_root=request.project_root,
        output=request.output,
    )
    return ScanContextResponse(
        success=result.ok,
        exit_code=result.exit_code,
        logs="\n".join(result.logs),
        output=str(request.output),
    )


@app.post("/generate", response_model=GenerateResponse, dependencies=[Depends(require_api_token)])
def generate(request: GenerateRequest) -> GenerateResponse:
    if not request.context_file and not request.project_root:
        raise HTTPException(status_code=422, detail="必须至少提供 context_file 或 project_root。")

    result = execute_generate(**request.model_dump())
    return GenerateResponse(
        success=result.ok,
        exit_code=result.exit_code,
        logs="\n".join(result.logs),
        artifacts=result.artifacts,
    )


@app.post("/generate-async", response_model=AsyncTaskSubmitResponse, dependencies=[Depends(require_api_token)])
def generate_async(request: GenerateRequest) -> AsyncTaskSubmitResponse:
    if not request.context_file and not request.project_root:
        raise HTTPException(status_code=422, detail="必须至少提供 context_file 或 project_root。")
    task_id = _submit_generate_task(request.model_dump())
    return AsyncTaskSubmitResponse(task_id=task_id, status="PENDING")


@app.get("/tasks", response_model=AsyncTaskListResponse, dependencies=[Depends(require_api_token)])
def list_tasks(
    status_filter: TaskStatus | None = Query(default=None, alias="status"),
    limit: int = Query(default=50, ge=1, le=500),
) -> AsyncTaskListResponse:
    with _task_lock:
        rows = sorted(_tasks.values(), key=lambda item: str(item.get("created_at", "")), reverse=True)
        if status_filter:
            rows = [item for item in rows if str(item.get("status", "")).upper() == status_filter]
        rows = rows[:limit]
        payload = [_task_response_payload(item) for item in rows]
    return AsyncTaskListResponse(total=len(payload), items=[AsyncTaskStatusResponse(**item) for item in payload])


@app.get("/tasks/{task_id}", response_model=AsyncTaskStatusResponse, dependencies=[Depends(require_api_token)])
def get_task_status(task_id: str) -> AsyncTaskStatusResponse:
    with _task_lock:
        task = _tasks.get(task_id)
        if task is None:
            raise HTTPException(status_code=404, detail=f"任务不存在: {task_id}")
        payload = _task_response_payload(task)
    return AsyncTaskStatusResponse(**payload)


@app.post("/tasks/{task_id}/cancel", response_model=AsyncTaskStatusResponse, dependencies=[Depends(require_api_token)])
def cancel_task(task_id: str) -> AsyncTaskStatusResponse:
    with _task_lock:
        task = _tasks.get(task_id)
        if task is None:
            raise HTTPException(status_code=404, detail=f"任务不存在: {task_id}")

        current_status = str(task.get("status", "")).upper()
        if current_status in {"SUCCEEDED", "FAILED", "CANCELLED"}:
            if not task.get("message"):
                task["message"] = f"任务已结束，无法取消（status={current_status}）。"
            payload = _task_response_payload(task)
            return AsyncTaskStatusResponse(**payload)

        # 优先尝试取消还未启动的任务（Future.cancel() 成功则立即终态）。
        future = _task_futures.get(task_id)
        if current_status == "PENDING" and future is not None and future.cancel():
            task["cancel_requested"] = True
            task["status"] = "CANCELLED"
            task["completed_at"] = _now_iso()
            task["success"] = False
            task["exit_code"] = 1
            task["message"] = "任务在执行前已取消。"
            _task_futures.pop(task_id, None)
            _persist_tasks_locked()
            payload = _task_response_payload(task)
            return AsyncTaskStatusResponse(**payload)

        # 对已运行或竞争态任务做协作式取消：标记请求，最终在执行结束后转为 CANCELLED。
        task["cancel_requested"] = True
        task["status"] = "CANCELLING"
        task["message"] = "已提交取消请求，等待当前执行步骤结束。"
        _persist_tasks_locked()
        payload = _task_response_payload(task)
        return AsyncTaskStatusResponse(**payload)


@app.post("/kb-review", response_model=KbReviewResponse, dependencies=[Depends(require_api_token)])
def kb_review(request: KbReviewRequest) -> KbReviewResponse:
    result = execute_kb_review(
        draft_id=request.draft_id,
        approval_status=request.approval_status,
        reviewer=request.reviewer,
        note=request.note,
        kb_mode=request.kb_mode,
        kb_dir=request.kb_dir,
        kb_url=request.kb_url,
        kb_token=request.kb_token,
        kb_namespace=request.kb_namespace,
        kb_cache_dir=request.kb_cache_dir,
    )
    return KbReviewResponse(
        success=result.ok,
        exit_code=result.exit_code,
        logs="\n".join(result.logs),
        draft_id=request.draft_id,
        approval_status=request.approval_status,
    )


def run() -> None:
    """本地启动入口：`ai-delivery-engine-api`。"""
    import uvicorn

    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", "8000"))
    uvicorn.run("app.api.main:app", host=host, port=port, reload=False)


_load_tasks_from_disk()
