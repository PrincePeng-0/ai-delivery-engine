from __future__ import annotations

import json
import re
from typing import Any

from app.schemas import ApiDoc, ApiEndpoint


HTTP_METHOD_PATH_PATTERN = re.compile(r"\b(GET|POST|PUT|PATCH|DELETE)\s+(/[^ \t\r\n]+)", re.IGNORECASE)
HTTP_METHOD_PATTERN = re.compile(r"\b(GET|POST|PUT|PATCH|DELETE)\b", re.IGNORECASE)


def build_postman_collection(api_doc: ApiDoc) -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    for idx, endpoint in enumerate(api_doc.endpoints, start=1):
        method, path = infer_method_and_path(endpoint, idx)
        raw_url = "{{baseUrl}}" + path

        request: dict[str, Any] = {
            "method": method,
            "header": [],
            "url": raw_url,
            "description": _build_endpoint_description(endpoint),
        }
        if method != "GET":
            request["header"] = [{"key": "Content-Type", "value": "application/json"}]
            request["body"] = {
                "mode": "raw",
                "raw": json.dumps(_build_request_example(endpoint), ensure_ascii=False, indent=2),
            }

        items.append(
            {
                "name": f"{idx}. {endpoint.name}",
                "request": request,
                "response": [],
            }
        )

    return {
        "info": {
            "name": api_doc.title,
            "description": api_doc.overview,
            "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
        },
        "item": items,
        "variable": [
            {"key": "baseUrl", "value": "http://localhost:8080"},
        ],
    }


def build_apifox_openapi(api_doc: ApiDoc) -> dict[str, Any]:
    paths: dict[str, Any] = {}
    for idx, endpoint in enumerate(api_doc.endpoints, start=1):
        method, path = infer_method_and_path(endpoint, idx)
        method_key = method.lower()
        path_key = _deduplicate_path(paths, path, method_key)

        operation: dict[str, Any] = {
            "summary": endpoint.name,
            "description": _build_endpoint_description(endpoint),
            "operationId": _build_operation_id(endpoint, idx),
            "tags": [endpoint.owner_system or "default"],
            "responses": {
                "200": {
                    "description": "Success",
                    "content": {
                        "application/json": {
                            "schema": _build_object_schema(endpoint.response_fields, include_required=False),
                            "example": _build_response_example(endpoint),
                        }
                    },
                }
            },
        }

        if method == "GET":
            operation["parameters"] = _build_query_parameters(endpoint)
        else:
            request_schema = _build_object_schema(endpoint.request_fields, include_required=True)
            operation["requestBody"] = {
                "required": bool(request_schema.get("required")),
                "content": {
                    "application/json": {
                        "schema": request_schema,
                        "example": _build_request_example(endpoint),
                    }
                },
            }

        paths.setdefault(path_key, {})
        paths[path_key][method_key] = operation

    return {
        "openapi": "3.0.3",
        "info": {
            "title": api_doc.title,
            "version": "1.0.0",
            "description": api_doc.overview,
        },
        "servers": [{"url": "{{baseUrl}}", "description": "Environment Base URL"}],
        "tags": _build_tags(api_doc),
        "paths": paths,
    }


def infer_method_and_path(endpoint: ApiEndpoint, index: int) -> tuple[str, str]:
    combined = f"{endpoint.protocol} {endpoint.interface} {endpoint.name}"
    explicit = HTTP_METHOD_PATH_PATTERN.search(combined)
    if explicit:
        method = explicit.group(1).upper()
        path = explicit.group(2).strip()
        return method, path

    method_only = HTTP_METHOD_PATTERN.search(combined)
    if method_only:
        method = method_only.group(1).upper()
    else:
        method = _infer_method(endpoint)

    interface = (endpoint.interface or "").strip()
    if interface.startswith("/"):
        path = interface
    elif " /" in interface:
        tail = interface.split(" /", 1)[1].strip()
        path = "/" + tail
    elif "/" in interface and not interface.startswith("http"):
        path = "/" + interface.strip().lstrip("/")
    else:
        system = _safe_segment(endpoint.owner_system or "system")
        name = _safe_segment(endpoint.interface or endpoint.name or f"endpoint-{index}")
        prefix = "api" if "http" in (endpoint.protocol or "").lower() else "rpc"
        path = f"/{prefix}/{system}/{name}"

    return method, _normalize_path(path)


def _build_tags(api_doc: ApiDoc) -> list[dict[str, str]]:
    owners = sorted({endpoint.owner_system for endpoint in api_doc.endpoints if endpoint.owner_system})
    return [{"name": item} for item in owners]


def _build_query_parameters(endpoint: ApiEndpoint) -> list[dict[str, Any]]:
    params: list[dict[str, Any]] = []
    for field in endpoint.request_fields:
        name = (field.get("name") or "").strip()
        if not name:
            continue
        type_desc = (field.get("type") or "string").strip()
        schema = _map_field_type(type_desc)
        params.append(
            {
                "name": name,
                "in": "query",
                "required": str(field.get("required", "")).upper() == "Y",
                "description": (field.get("desc") or "").strip(),
                "schema": schema,
                "example": _example_value(type_desc),
            }
        )
    return params


def _build_object_schema(fields: list[dict[str, str]], include_required: bool) -> dict[str, Any]:
    properties: dict[str, Any] = {}
    required: list[str] = []
    for field in fields:
        name = (field.get("name") or "").strip()
        if not name:
            continue
        type_desc = (field.get("type") or "string").strip()
        item = _map_field_type(type_desc)
        desc = (field.get("desc") or "").strip()
        if desc:
            item["description"] = desc
        properties[name] = item

        if include_required and str(field.get("required", "")).upper() == "Y":
            required.append(name)

    schema: dict[str, Any] = {"type": "object", "properties": properties}
    if include_required and required:
        schema["required"] = required
    return schema


def _build_request_example(endpoint: ApiEndpoint) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for field in endpoint.request_fields:
        name = (field.get("name") or "").strip()
        if not name:
            continue
        result[name] = _example_value((field.get("type") or "string").strip())
    return result


def _build_response_example(endpoint: ApiEndpoint) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for field in endpoint.response_fields:
        name = (field.get("name") or "").strip()
        if not name:
            continue
        result[name] = _example_value((field.get("type") or "string").strip())
    return result


def _build_endpoint_description(endpoint: ApiEndpoint) -> str:
    parts: list[str] = []
    if endpoint.scenario.strip():
        parts.append(f"场景: {endpoint.scenario.strip()}")
    if endpoint.notes.strip():
        parts.append(f"备注: {endpoint.notes.strip()}")
    if endpoint.idempotency.strip():
        parts.append(f"幂等: {endpoint.idempotency.strip()}")
    if endpoint.retry_policy.strip():
        parts.append(f"重试: {endpoint.retry_policy.strip()}")
    if endpoint.error_codes:
        codes = ", ".join(item.get("code", "") for item in endpoint.error_codes if item.get("code"))
        if codes:
            parts.append(f"错误码: {codes}")
    return "\n".join(parts)


def _build_operation_id(endpoint: ApiEndpoint, index: int) -> str:
    owner = _safe_segment(endpoint.owner_system or "system")
    name = _safe_segment(endpoint.interface or endpoint.name or f"endpoint-{index}")
    return f"{owner}_{name}_{index}"


def _infer_method(endpoint: ApiEndpoint) -> str:
    lower = f"{endpoint.name} {endpoint.interface} {endpoint.scenario}".lower()
    protocol = (endpoint.protocol or "").lower()

    if "http" in protocol:
        if any(token in lower for token in ["query", "get", "list", "查询"]):
            return "GET"
    if any(token in lower for token in ["delete", "remove", "cancel", "删除", "注销"]):
        return "DELETE"
    if any(token in lower for token in ["update", "modify", "edit", "变更", "更新"]):
        return "PUT"
    if any(token in lower for token in ["create", "add", "new", "新增", "创建", "开卡"]):
        return "POST"
    return "POST"


def _map_field_type(raw_type: str) -> dict[str, Any]:
    value = raw_type.lower()
    if "bool" in value:
        return {"type": "boolean"}
    if "long" in value:
        return {"type": "integer", "format": "int64"}
    if "int" in value:
        return {"type": "integer", "format": "int32"}
    if any(token in value for token in ["double", "float", "decimal", "number", "amount"]):
        return {"type": "number", "format": "double"}
    if any(token in value for token in ["json", "object", "map", "dict"]):
        return {"type": "object"}
    if any(token in value for token in ["list", "array", "[]"]):
        return {"type": "array", "items": {"type": "string"}}
    return {"type": "string"}


def _example_value(raw_type: str) -> Any:
    schema = _map_field_type(raw_type)
    item_type = schema.get("type")
    if item_type == "boolean":
        return True
    if item_type == "integer":
        return 1
    if item_type == "number":
        return 1.0
    if item_type == "object":
        return {}
    if item_type == "array":
        return []
    return ""


def _safe_segment(value: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "-", (value or "").strip()).strip("-").lower()
    return text or "item"


def _normalize_path(path: str) -> str:
    cleaned = "/" + "/".join(segment for segment in path.strip().split("/") if segment)
    return cleaned or "/"


def _deduplicate_path(paths: dict[str, Any], path: str, method: str) -> str:
    if path not in paths or method not in paths[path]:
        return path
    idx = 2
    while True:
        candidate = f"{path}-{idx}"
        if candidate not in paths or method not in paths[candidate]:
            return candidate
        idx += 1
