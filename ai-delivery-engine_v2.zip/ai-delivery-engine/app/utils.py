from __future__ import annotations

import html
import json
from datetime import datetime
from pathlib import Path
from typing import Any


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def dump_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def to_markdown_list(items: list[str], empty: str = "- 无") -> str:
    normalized: list[str] = []
    if items:
        normalized = [str(item) for item in items]
    else:
        fallback = str(empty or "").strip()
        if fallback.startswith("-"):
            fallback = fallback[1:].strip()
        normalized = [fallback or "无"]
    return to_markdown_table(["内容"], [[item] for item in normalized])


def to_markdown_table(headers: list[str], rows: list[list[str]]) -> str:
    if not headers:
        return ""
    col_count = len(headers)

    def _normalize_cells(cells: list[str]) -> list[str]:
        normalized = ["" if item is None else str(item) for item in cells]
        if len(normalized) < col_count:
            normalized.extend("" for _ in range(col_count - len(normalized)))
        elif len(normalized) > col_count:
            normalized = normalized[:col_count]
        return normalized

    def _escape_cell(value: str) -> str:
        escaped = html.escape(value, quote=False)
        escaped = escaped.replace("&lt;br&gt;", "<br/>")
        escaped = escaped.replace("&lt;br/&gt;", "<br/>")
        escaped = escaped.replace("&lt;br /&gt;", "<br/>")
        escaped = escaped.replace("\n", "<br/>")
        return escaped

    header_cells = _normalize_cells(headers)
    normalized_rows = [_normalize_cells(row) for row in rows] if rows else [["" for _ in range(col_count)]]

    lines: list[str] = ["<table>"]
    lines.append("  <thead>")
    lines.append("    <tr>")
    for item in header_cells:
        lines.append(f"      <th>{_escape_cell(item)}</th>")
    lines.append("    </tr>")
    lines.append("  </thead>")
    lines.append("  <tbody>")
    for row in normalized_rows:
        lines.append("    <tr>")
        for item in row:
            lines.append(f"      <td>{_escape_cell(item)}</td>")
        lines.append("    </tr>")
    lines.append("  </tbody>")
    lines.append("</table>")
    return "\n".join(lines)
