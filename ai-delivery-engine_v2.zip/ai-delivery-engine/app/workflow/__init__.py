from .engine import AIDeliveryEngineWorkflow, WorkflowResult

def load_langgraph_workflow_class():
    """懒加载 LangGraph 编排器，避免经典模式下触发可选依赖初始化。"""
    from .langgraph_engine import LangGraphAIDeliveryEngineWorkflow
    return LangGraphAIDeliveryEngineWorkflow

__all__ = [
    "AIDeliveryEngineWorkflow",
    "load_langgraph_workflow_class",
    "WorkflowResult",
]
