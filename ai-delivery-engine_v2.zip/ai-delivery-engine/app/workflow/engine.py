from __future__ import annotations

from dataclasses import dataclass
import json
import re
import time
from typing import Any

from app.agents import (
    ApiWriter,
    Designer,
    Developer,
    DesignWriter,
    DevelopmentPlanner,
    ImpactAnalyzer,
    KnowledgeBaseAdministrator,
    RequirementAnalyzer,
    RequirementParser,
    Reviewer,
    Tester,
    TestingPlanner,
)
from app.kb import KnowledgeProvider, PublicKnowledgeContext
from app.llm import LLMClient
from app.rules import PublicRulebook
from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput, ValidationReport


@dataclass
class WorkflowResult:
    """工作流聚合产物。

    说明：
    - 该对象是 CLI/渲染层的统一输入，避免上层直接依赖各 Agent 内部结构。
    - `quality_report` 表示第三阶段质量评估（检索与幻觉风险）。
    - `quality_gate` 表示第四阶段门禁结论（PASS/WARN/BLOCK）。
    """

    requirement: RequirementInput
    impacts: list[ImpactItem]
    requirement_breakdown: list[dict[str, str]]
    design_doc: DesignDoc
    api_doc: ApiDoc
    coding_plan: dict[str, Any]
    testing_plan: dict[str, Any]
    unit_test_report: dict[str, Any]
    public_knowledge: dict[str, Any]
    quality_report: dict[str, Any]
    quality_gate: dict[str, Any]
    public_kb_draft: dict[str, str]
    public_kb_audit: list[dict[str, str]]
    knowledge_assets: dict[str, str]
    validation: ValidationReport

    def to_dict(self) -> dict[str, Any]:
        return {
            "requirement": self.requirement.to_dict(),
            "impacts": [item.to_dict() for item in self.impacts],
            "requirement_breakdown": self.requirement_breakdown,
            "design_doc": self.design_doc.to_dict(),
            "api_doc": self.api_doc.to_dict(),
            "coding_plan": self.coding_plan,
            "testing_plan": self.testing_plan,
            "unit_test_report": self.unit_test_report,
            "public_knowledge": self.public_knowledge,
            "quality_report": self.quality_report,
            "quality_gate": self.quality_gate,
            "public_kb_draft": self.public_kb_draft,
            "public_kb_audit": self.public_kb_audit,
            "knowledge_assets": self.knowledge_assets,
            "validation": self.validation.to_dict(),
        }


class AIDeliveryEngineWorkflow:
    """AI Delivery Engine 主编排器。

    该类负责串联 7 个角色的执行顺序，并把中间结果归并为可交付产物。
    设计目标：
    - 编排顺序稳定可追踪；
    - 每个阶段可单独观测（pipeline stages + role matrix）；
    - 公共知识与公共规则均可插拔；
    - 质量评估与质量门禁可配置。
    """

    def __init__(
        self,
        use_llm: bool = True,
        model: str | None = None,
        allow_fallback: bool = True,
        knowledge_dir: str = "knowledge_base",
        rulebook: PublicRulebook | None = None,
        knowledge_provider: KnowledgeProvider | None = None,
        strict_kb: bool = False,
        quality_gate_policy: dict[str, Any] | None = None,
        quality_gate_policy_source: str = "built-in-default",
        node_retry_max_attempts: int = 2,
        node_retry_backoff_ms: int = 200,
    ) -> None:
        self.use_llm = use_llm
        self.allow_fallback = allow_fallback
        self.rulebook = rulebook or PublicRulebook.empty()
        self.knowledge_provider = knowledge_provider
        self.strict_kb = strict_kb
        self.quality_gate_policy = quality_gate_policy or {}
        self.quality_gate_policy_source = quality_gate_policy_source
        # LangGraph 节点重试配置：
        # - max_attempts 至少为 1（即不重试时也会执行一次）；
        # - backoff_ms 允许为 0（表示失败后立即重试）。
        try:
            self.node_retry_max_attempts = max(1, int(node_retry_max_attempts))
        except Exception:  # noqa: BLE001
            self.node_retry_max_attempts = 2
        try:
            self.node_retry_backoff_ms = max(0, int(node_retry_backoff_ms))
        except Exception:  # noqa: BLE001
            self.node_retry_backoff_ms = 200
        self.llm_client = LLMClient(enabled=use_llm, model=model)
        status = self.llm_client.status()
        if use_llm and not status.ready and not allow_fallback:
            raise RuntimeError(f"LLM unavailable in strict mode: {status.reason}")

        self.requirement_parser = RequirementParser(
            llm_client=self.llm_client,
            use_llm=use_llm,
            allow_fallback=allow_fallback,
            requirement_analysis_rule=self.rulebook.requirement_analysis,
        )
        self.impact_analyzer = ImpactAnalyzer(
            llm_client=self.llm_client,
            use_llm=use_llm,
            allow_fallback=allow_fallback,
        )
        self.design_writer = DesignWriter(
            llm_client=self.llm_client,
            use_llm=use_llm,
            allow_fallback=allow_fallback,
            technical_design_rule=self.rulebook.technical_design,
        )
        self.api_writer = ApiWriter(
            llm_client=self.llm_client,
            use_llm=use_llm,
            allow_fallback=allow_fallback,
            interface_document_rule=self.rulebook.interface_document,
        )
        self.knowledge_base_administrator = KnowledgeBaseAdministrator(knowledge_dir=knowledge_dir)
        self.requirement_analyzer = RequirementAnalyzer(
            requirement_parser=self.requirement_parser,
            impact_analyzer=self.impact_analyzer,
        )
        self.designer = Designer(
            design_writer=self.design_writer,
            api_writer=self.api_writer,
        )
        self.developer = Developer(
            development_planner=DevelopmentPlanner(code_development_rule=self.rulebook.code_development)
        )
        self.tester = Tester(testing_planner=TestingPlanner())
        self.reviewer = Reviewer()

    def runtime_mode(self) -> str:
        if not self.use_llm:
            return "rules"
        if self.llm_client.is_ready:
            return "llm"
        return "rules-fallback"

    def runtime_message(self) -> str:
        status = self.llm_client.status()
        if not self.use_llm:
            return "LLM disabled by CLI flag."
        if status.ready:
            return f"LLM enabled, model={status.model}"
        return f"LLM unavailable, fallback to rules. reason={status.reason}"

    def run(
        self,
        requirement_text: str,
        context: ContextSnapshot,
        requirement_name: str = "Requirement",
    ) -> WorkflowResult:
        """执行完整交付流程并返回聚合结果。

        执行链路：
        1. 读取领域知识与公共知识；
        2. 需求分析；
        3. 方案设计；
        4. 开发计划；
        5. 测试计划；
        6. Reviewer 校验；
        7. 知识沉淀与公共知识草稿回写；
        8. 第三阶段质量评估与第四阶段质量门禁；
        9. 汇总为 `WorkflowResult`。
        """
        run_started = time.perf_counter()
        stage_durations_ms: dict[str, float] = {}
        response_latency_ms = 0.0

        # 1) KnowledgeBaseAdministrator：准备领域知识输入 + 公共知识命中上下文
        stage_started = time.perf_counter()
        private_knowledge = self.knowledge_base_administrator.load_context_knowledge(context)
        public_knowledge = self._load_public_knowledge(requirement_text=requirement_text, context=context)
        knowledge_input = self._merge_knowledge_input(private_knowledge, public_knowledge)
        stage_durations_ms["knowledge_bootstrap_ms"] = _elapsed_ms(stage_started)

        # 2) RequirementAnalyzer：需求拆解 + 影响分析 + 优先级
        stage_started = time.perf_counter()
        requirement, impacts, requirement_breakdown = self.requirement_analyzer.analyze(
            requirement_text=requirement_text,
            context=context,
            knowledge_input=knowledge_input,
        )
        stage_durations_ms["requirement_analysis_ms"] = _elapsed_ms(stage_started)
        response_latency_ms = _elapsed_ms(run_started)

        # 3) Designer：架构与接口设计
        stage_started = time.perf_counter()
        design_doc, api_doc = self.designer.design(
            requirement,
            context,
            impacts,
            knowledge_input=knowledge_input,
        )
        stage_durations_ms["solution_design_ms"] = _elapsed_ms(stage_started)

        # 4) Developer：按设计生成开发与单测计划（覆盖率目标 >= 90%）
        stage_started = time.perf_counter()
        coding_plan = self.developer.build(
            requirement,
            design_doc,
            api_doc,
            impacts,
            context,
            knowledge_input=knowledge_input,
        )
        stage_durations_ms["coding_planning_ms"] = _elapsed_ms(stage_started)

        # 5) Tester：单元测试计划与报告
        stage_started = time.perf_counter()
        testing_plan, unit_test_report = self.tester.build(requirement, api_doc, impacts, coding_plan)
        stage_durations_ms["testing_planning_ms"] = _elapsed_ms(stage_started)

        stage_started = time.perf_counter()
        validation = self.reviewer.review(design_doc, api_doc, impacts, context)
        stage_durations_ms["review_ms"] = _elapsed_ms(stage_started)

        stage_started = time.perf_counter()
        knowledge_assets = self.knowledge_base_administrator.persist_knowledge_and_skills(
            requirement_name=requirement_name,
            requirement=requirement,
            impacts=impacts,
            design_doc=design_doc,
            api_doc=api_doc,
            context=context,
        )
        stage_durations_ms["knowledge_persist_ms"] = _elapsed_ms(stage_started)

        stage_started = time.perf_counter()
        public_kb_draft = self._submit_public_kb_draft(
            requirement_name=requirement_name,
            requirement=requirement,
            impacts=impacts,
            design_doc=design_doc,
            api_doc=api_doc,
            context=context,
            public_knowledge=public_knowledge,
        )
        stage_durations_ms["public_kb_submit_ms"] = _elapsed_ms(stage_started)

        stage_started = time.perf_counter()
        public_kb_audit = self._read_public_kb_audit(limit=20)
        stage_durations_ms["public_kb_audit_ms"] = _elapsed_ms(stage_started)
        runtime_stats = {
            "runtime_mode": self.runtime_mode(),
            "model": self.llm_client.model,
            "response_latency_ms": round(response_latency_ms, 2),
            "total_processing_ms": round(_elapsed_ms(run_started), 2),
            "stage_durations_ms": {key: round(value, 2) for key, value in stage_durations_ms.items()},
        }

        quality_report = self._build_quality_report(
            requirement=requirement,
            context=context,
            impacts=impacts,
            design_doc=design_doc,
            api_doc=api_doc,
            coding_plan=coding_plan,
            testing_plan=testing_plan,
            unit_test_report=unit_test_report,
            public_knowledge=public_knowledge,
            validation=validation,
            runtime_stats=runtime_stats,
        )
        quality_gate = self._build_quality_gate(
            quality_report=quality_report,
            validation=validation,
            policy=self.quality_gate_policy,
        )
        quality_gate["policy_source"] = self.quality_gate_policy_source

        return WorkflowResult(
            requirement=requirement,
            impacts=impacts,
            requirement_breakdown=requirement_breakdown,
            design_doc=design_doc,
            api_doc=api_doc,
            coding_plan=coding_plan,
            testing_plan=testing_plan,
            unit_test_report=unit_test_report,
            public_knowledge=public_knowledge.to_dict(),
            quality_report=quality_report,
            quality_gate=quality_gate,
            public_kb_draft=public_kb_draft,
            public_kb_audit=public_kb_audit,
            knowledge_assets=knowledge_assets,
            validation=validation,
        )

    def _load_public_knowledge(
        self,
        requirement_text: str,
        context: ContextSnapshot,
    ) -> PublicKnowledgeContext:
        """读取公共知识上下文。

        - 当 provider 未配置：返回空上下文（不中断流程）。
        - 当读取失败且 `strict_kb=True`：抛错阻断。
        - 当读取失败且非 strict：返回脱敏后的 unavailable 占位上下文。
        """
        if self.knowledge_provider is None:
            return PublicKnowledgeContext.empty(source="not-configured", namespace="default")
        try:
            return self.knowledge_provider.fetch_context(requirement_text=requirement_text, context=context)
        except Exception as exc:  # noqa: BLE001
            error_label = _safe_error_label(exc)
            if self.strict_kb:
                raise RuntimeError(f"公共知识库读取失败（strict-kb）: {error_label}") from exc
            return PublicKnowledgeContext.empty(
                source=f"unavailable:{error_label}",
                namespace="default",
            )

    @staticmethod
    def _merge_knowledge_input(
        private_knowledge: dict[str, Any],
        public_knowledge: PublicKnowledgeContext,
    ) -> dict[str, Any]:
        """融合私有知识与公共知识，供下游 Agent 统一消费。

        合并策略：
        - `domain_systems` 去重合并；
        - 保留公共知识来源元信息（source/namespace）；
        - 暴露公共检索命中详情与检索指标，便于生成质量说明。
        """
        merged = dict(private_knowledge)
        private_systems = set(merged.get("domain_systems", []))
        private_systems.update(public_knowledge.domain_systems)
        merged["domain_systems"] = sorted(private_systems)
        merged["public_kb_source"] = public_knowledge.source
        merged["public_kb_namespace"] = public_knowledge.namespace
        merged["public_requirement_patterns"] = public_knowledge.requirement_patterns
        merged["public_architecture_patterns"] = public_knowledge.architecture_patterns
        merged["public_interface_patterns"] = public_knowledge.interface_patterns
        merged["public_coding_standards"] = public_knowledge.coding_standards
        merged["public_recent_cases"] = public_knowledge.recent_cases
        merged["public_references"] = public_knowledge.references
        merged["public_retrieval_hits"] = public_knowledge.retrieval_hits
        merged["public_retrieval_metrics"] = public_knowledge.retrieval_metrics
        return merged

    def _submit_public_kb_draft(
        self,
        requirement_name: str,
        requirement: RequirementInput,
        impacts: list[ImpactItem],
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        context: ContextSnapshot,
        public_knowledge: PublicKnowledgeContext,
    ) -> dict[str, str]:
        if self.knowledge_provider is None:
            return {
                "provider": "none",
                "status": "SKIPPED",
                "approval_status": "",
                "message": "knowledge provider not configured",
                "draft_id": "",
                "namespace": public_knowledge.namespace,
            }

        draft_payload = self._build_public_kb_draft_payload(
            requirement_name=requirement_name,
            requirement=requirement,
            impacts=impacts,
            design_doc=design_doc,
            api_doc=api_doc,
            context=context,
            public_knowledge=public_knowledge,
        )
        try:
            return self.knowledge_provider.submit_draft(
                requirement_name=requirement_name,
                draft_payload=draft_payload,
                context=context,
            )
        except Exception as exc:  # noqa: BLE001
            error_label = _safe_error_label(exc)
            if self.strict_kb:
                raise RuntimeError(f"公共知识库草稿回写失败（strict-kb）: {error_label}") from exc
            return {
                "provider": "unknown",
                "status": "FAILED",
                "approval_status": "",
                "message": f"public kb draft submit failed: {error_label}",
                "draft_id": "",
                "namespace": public_knowledge.namespace,
            }

    def _read_public_kb_audit(self, limit: int = 20) -> list[dict[str, str]]:
        if self.knowledge_provider is None:
            return []
        try:
            return self.knowledge_provider.read_audit_events(limit=limit)
        except Exception as exc:  # noqa: BLE001
            error_label = _safe_error_label(exc)
            if self.strict_kb:
                raise RuntimeError(f"公共知识库审计读取失败（strict-kb）: {error_label}") from exc
            return []

    @staticmethod
    def _build_public_kb_draft_payload(
        requirement_name: str,
        requirement: RequirementInput,
        impacts: list[ImpactItem],
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        context: ContextSnapshot,
        public_knowledge: PublicKnowledgeContext,
    ) -> dict[str, Any]:
        """构造公共知识库草稿回写载荷。

        约束：
        - 只回写结构化摘要，不回写完整长文；
        - 保留最小必要上下文统计（repo_count/shared_table_count）；
        - `project_root` 使用上游扫描结果（已做占位脱敏）。
        """
        return {
            "source_requirement_name": requirement_name,
            "requirement": {
                "title": requirement.title,
                "background": requirement.background,
                "goals": requirement.goals,
                "scope_in": requirement.scope_in,
                "scope_out": requirement.scope_out,
                "constraints": requirement.constraints,
                "acceptance_criteria": requirement.acceptance_criteria,
            },
            "impact_summary": [
                {
                    "system": item.system,
                    "reason": item.reason,
                    "changes": item.changes,
                }
                for item in impacts
            ],
            "design_summary": {
                "title": design_doc.title,
                "data_model_notes": design_doc.data_model_notes[:20],
                "risks": design_doc.risks,
            },
            "interface_summary": {
                "title": api_doc.title,
                "endpoint_count": len(api_doc.endpoints),
                "interfaces": [item.interface for item in api_doc.endpoints][:50],
                "owners": sorted({item.owner_system for item in api_doc.endpoints}),
            },
            "context": {
                "repo_count": len(context.repos),
                "shared_table_count": len(context.shared_tables),
                "project_root": context.project_root,
            },
            "knowledge_source": {
                "namespace": public_knowledge.namespace,
                "source": public_knowledge.source,
                "retrieved_at": public_knowledge.retrieved_at,
            },
            "generated_at": context.generated_at,
        }

    @staticmethod
    def _build_quality_report(
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        coding_plan: dict[str, Any],
        testing_plan: dict[str, Any],
        unit_test_report: dict[str, Any],
        public_knowledge: PublicKnowledgeContext,
        validation: ValidationReport,
        runtime_stats: dict[str, Any],
    ) -> dict[str, Any]:
        """生成第三阶段质量评估报告。

        评估维度：
        - 语义命中质量（命中数、平均分、Top Hits）；
        - 公共知识引用覆盖率；
        - 幻觉风险信号（知识缺失、低相关、占位符、系统归属漂移）。
        """
        hits = public_knowledge.retrieval_hits
        hit_scores = [_to_float(item.get("score")) for item in hits]
        avg_score = _avg_float(hit_scores)
        top_hits = [
            {
                "id": _to_str(item.get("id")),
                "title": _to_str(item.get("title")),
                "type": _to_str(item.get("type")),
                "score": f"{_to_float(item.get('score')):.4f}",
            }
            for item in hits[:5]
        ]

        available_knowledge = (
            len(public_knowledge.requirement_patterns)
            + len(public_knowledge.architecture_patterns)
            + len(public_knowledge.interface_patterns)
            + len(public_knowledge.coding_standards)
        )
        used_public_hints = 0
        used_public_hints += sum(1 for item in design_doc.data_model_notes if "公共知识" in item)
        used_public_hints += sum(1 for item in api_doc.common_policy if "公共知识" in item)
        used_public_hints += sum(
            1 for item in coding_plan.get("global_quality_gate", []) if "公共知识" in _to_str(item)
        )
        citation_expected = min(available_knowledge, 12)
        if citation_expected <= 0:
            citation_coverage_ratio = 0.0
        else:
            citation_coverage_ratio = min(1.0, used_public_hints / citation_expected)

        impacted = {item.system for item in impacts}
        orphan_endpoints = [
            endpoint.interface for endpoint in api_doc.endpoints if endpoint.owner_system not in impacted
        ]
        placeholder_hits = 0
        for endpoint in api_doc.endpoints:
            if "TBD" in endpoint.notes or "待补充" in endpoint.notes:
                placeholder_hits += 1
            if any(_to_str(consumer).upper() == "TBD" for consumer in endpoint.consumers):
                placeholder_hits += 1

        risk_score = 0
        risk_signals: list[str] = []
        if not hits:
            risk_score += 2
            risk_signals.append("公共知识检索未命中，生成内容缺乏外部知识支撑。")
        if avg_score < 0.2 and hits:
            risk_score += 1
            risk_signals.append("公共知识命中相关性偏低（avg_score < 0.20）。")
        if used_public_hints == 0 and available_knowledge > 0:
            risk_score += 1
            risk_signals.append("可用公共知识未被有效引用。")
        if used_public_hints > 0 and not hits:
            risk_score += 2
            risk_signals.append("存在公共知识引用痕迹但检索无命中，可能出现幻觉引用。")
        if orphan_endpoints:
            risk_score += 1
            risk_signals.append(f"存在 {len(orphan_endpoints)} 个接口归属系统不在影响系统中。")
        if placeholder_hits > 0:
            risk_score += 1
            risk_signals.append(f"接口文档存在 {placeholder_hits} 处占位内容（TBD/待补充）。")

        if risk_score >= 4:
            risk_level = "HIGH"
        elif risk_score >= 2:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"

        recommendations: list[str] = []
        if risk_level != "LOW":
            recommendations.append("补充公共知识库文档并重新执行语义检索。")
            recommendations.append("对低分命中进行人工复核，必要时人工改写关键段落。")
        if orphan_endpoints:
            recommendations.append("修正接口归属系统与影响系统映射，避免上下游边界错误。")
        if placeholder_hits:
            recommendations.append("清理接口中的占位字段，补齐真实调用方与约束。")
        if not recommendations:
            recommendations.append("当前质量风险可接受，建议在评审环节继续抽样核验。")

        quantitative = AIDeliveryEngineWorkflow._build_quantitative_metrics(
            requirement=requirement,
            context=context,
            impacts=impacts,
            design_doc=design_doc,
            api_doc=api_doc,
            coding_plan=coding_plan,
            testing_plan=testing_plan,
            unit_test_report=unit_test_report,
            public_knowledge=public_knowledge,
            validation=validation,
            runtime_stats=runtime_stats,
            available_knowledge=available_knowledge,
            placeholder_hits=placeholder_hits,
            orphan_endpoint_count=len(orphan_endpoints),
            semantic_avg_score=avg_score,
            semantic_hit_count=len(hits),
        )

        return {
            "requirement_title": requirement.title,
            "semantic_hit_count": len(hits),
            "semantic_avg_score": f"{avg_score:.4f}",
            "semantic_top_hits": top_hits,
            "citation_expected": citation_expected,
            "citation_used": used_public_hints,
            "citation_coverage_ratio": f"{citation_coverage_ratio:.4f}",
            "hallucination_risk_level": risk_level,
            "hallucination_risk_score": risk_score,
            "risk_signals": risk_signals,
            "recommendations": recommendations,
            "orphan_endpoint_count": len(orphan_endpoints),
            "runtime_stats": runtime_stats,
            "quantitative_metrics": quantitative.get("rows", []),
            "quantitative_summary": quantitative.get("summary", {}),
            "metric_assumptions": quantitative.get("assumptions", []),
        }

    @staticmethod
    def _build_quantitative_metrics(
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        coding_plan: dict[str, Any],
        testing_plan: dict[str, Any],
        unit_test_report: dict[str, Any],
        public_knowledge: PublicKnowledgeContext,
        validation: ValidationReport,
        runtime_stats: dict[str, Any],
        available_knowledge: int,
        placeholder_hits: int,
        orphan_endpoint_count: int,
        semantic_avg_score: float,
        semantic_hit_count: int,
    ) -> dict[str, Any]:
        """根据统一指标表计算量化质量结果。

        说明：
        - 指标公式与阈值按用户提供的标准表执行；
        - 部分指标（如 token、一致性、返工耗时）在当前工程内采用“可观测口径估算”；
        - 每个指标都输出计算过程、阈值区间和达标状态。
        """
        rows: list[dict[str, Any]] = []

        def add_metric(
            dimension: str,
            metric_name: str,
            explanation: str,
            formula: str,
            value_display: str,
            normal_range: str,
            passed: bool,
            calculation: str,
            score: float,
        ) -> None:
            rows.append(
                {
                    "dimension": dimension,
                    "metric_name": metric_name,
                    "explanation": explanation,
                    "formula": formula,
                    "value_display": value_display,
                    "normal_range": normal_range,
                    "status": "PASS" if passed else "FAIL",
                    "status_display": "达标" if passed else "未达标",
                    "calculation": calculation,
                    "score": round(max(0.0, min(100.0, score)), 2),
                }
            )

        def _score_ge(value: float, threshold: float) -> float:
            if threshold <= 0:
                return 100.0
            return max(0.0, min(100.0, (value / threshold) * 100.0))

        def _score_le(value: float, threshold: float) -> float:
            if threshold <= 0:
                return 0.0
            if value <= 0:
                return 100.0
            return max(0.0, min(100.0, (threshold / value) * 100.0))

        def _score_range(value: float, lower: float, upper: float) -> float:
            if lower > upper:
                lower, upper = upper, lower
            if lower <= value <= upper:
                return 100.0
            if value < lower:
                return _score_ge(value, lower)
            return _score_le(value, upper)

        # -------- 1) 资源消耗类（核心：token）--------
        impacted_context_text = _build_impacted_context_text(context=context, impacts=impacts)
        hit_hint_text = "\n".join(
            _to_str(item.get("title"))
            for item in public_knowledge.retrieval_hits[:10]
            if _to_str(item.get("title"))
        )
        requirement_input_tokens = _estimate_tokens(requirement.raw_text)
        context_input_tokens = _estimate_tokens(impacted_context_text)
        knowledge_input_tokens = _estimate_tokens(hit_hint_text)
        input_token_count = requirement_input_tokens + context_input_tokens + knowledge_input_tokens

        output_design_tokens = _estimate_tokens(json.dumps(design_doc.to_dict(), ensure_ascii=False))
        output_api_tokens = _estimate_tokens(json.dumps(api_doc.to_dict(), ensure_ascii=False))
        output_coding_tokens = _estimate_tokens(json.dumps(coding_plan, ensure_ascii=False))
        output_testing_tokens = _estimate_tokens(json.dumps(testing_plan, ensure_ascii=False))
        output_unit_test_tokens = _estimate_tokens(json.dumps(unit_test_report, ensure_ascii=False))
        output_token_count = (
            output_design_tokens
            + output_api_tokens
            + output_coding_tokens
            + output_testing_tokens
            + output_unit_test_tokens
        )

        effective_text = "\n".join(
            [
                requirement.title,
                requirement.background,
                "\n".join(requirement.goals),
                "\n".join(requirement.scope_in),
                "\n".join(requirement.constraints),
                "\n".join(item.reason for item in impacts),
                "\n".join("\n".join(item.changes) for item in impacts),
            ]
        )
        effective_input_tokens = _estimate_tokens(effective_text)
        token_utilization = _safe_ratio(effective_input_tokens, input_token_count) * 100.0

        response_latency_ms = _to_float(runtime_stats.get("response_latency_ms"), 0.0)
        total_processing_ms = _to_float(runtime_stats.get("total_processing_ms"), 0.0)
        total_tokens = max(1, input_token_count + output_token_count)
        unit_token_processing_ms = total_processing_ms / total_tokens

        model_name = _to_str(runtime_stats.get("model"), "unknown")
        is_small_model = any(keyword in model_name.lower() for keyword in ["mini", "small", "lite", "nano"])
        token_latency_threshold = 50.0 if is_small_model else 100.0

        add_metric(
            dimension="资源消耗类",
            metric_name="输入token数",
            explanation="衡量单轮输入规模是否处于可控区间，过低可能上下文不足，过高会增加噪音和成本。",
            formula="单轮交互输入token数 = 输入内容token拆分统计总和",
            value_display=f"{input_token_count} token",
            normal_range="文档处理单轮 1000-10000 token",
            passed=1000 <= input_token_count <= 10000,
            calculation=(
                f"{input_token_count} = 需求文本({requirement_input_tokens}) + "
                f"上下文({context_input_tokens}) + 知识命中({knowledge_input_tokens})"
            ),
            score=_score_range(float(input_token_count), 1000.0, 10000.0),
        )
        add_metric(
            dimension="资源消耗类",
            metric_name="输出token数",
            explanation="衡量输出信息量是否充分且不过载，反映单轮交付内容密度。",
            formula="单轮交互输出token数 = 输出响应内容token拆分统计总和",
            value_display=f"{output_token_count} token",
            normal_range="文档生成单轮 500-5000 token",
            passed=500 <= output_token_count <= 5000,
            calculation=(
                f"{output_token_count} = 设计({output_design_tokens}) + 接口({output_api_tokens}) + "
                f"开发计划({output_coding_tokens}) + 测试计划({output_testing_tokens}) + 单测报告({output_unit_test_tokens})"
            ),
            score=_score_range(float(output_token_count), 500.0, 5000.0),
        )
        add_metric(
            dimension="资源消耗类",
            metric_name="token利用率",
            explanation="衡量输入token中与任务直接相关的信息占比，反映上下文利用效率。",
            formula="有效输入token数 ÷ 总输入token数 ×100%",
            value_display=f"{token_utilization:.2f}%",
            normal_range=">=70%",
            passed=token_utilization >= 70.0,
            calculation=f"{token_utilization:.2f}% = 有效输入({effective_input_tokens}) / 总输入({input_token_count}) ×100%",
            score=_score_ge(token_utilization, 70.0),
        )
        add_metric(
            dimension="资源消耗类",
            metric_name="单位token处理耗时",
            explanation="衡量系统处理token的单位效率，越低代表吞吐能力越好。",
            formula="单轮交互总耗时 ÷ (输入token数+输出token数)",
            value_display=f"{unit_token_processing_ms:.2f} ms/token",
            normal_range=f"{'小型' if is_small_model else '大型'}模型 <= {token_latency_threshold:.0f} ms/token",
            passed=unit_token_processing_ms <= token_latency_threshold,
            calculation=(
                f"{unit_token_processing_ms:.2f} = 总耗时({total_processing_ms:.2f}ms) / "
                f"总token({input_token_count}+{output_token_count})"
            ),
            score=_score_le(unit_token_processing_ms, token_latency_threshold),
        )

        # -------- 2) 准确性类（核心：召回率）--------
        hit_scores = [_to_float(item.get("score")) for item in public_knowledge.retrieval_hits]
        relevant_threshold = 0.05
        relevant_retrieved_count = sum(1 for score in hit_scores if score >= relevant_threshold)
        retrieved_total_count = len(hit_scores)
        all_relevant_total_count = max(
            relevant_retrieved_count,
            len(public_knowledge.references),
            available_knowledge,
        )
        if all_relevant_total_count <= 0 and retrieved_total_count > 0:
            all_relevant_total_count = retrieved_total_count

        recall = _safe_ratio(relevant_retrieved_count, all_relevant_total_count) * 100.0
        precision = _safe_ratio(relevant_retrieved_count, retrieved_total_count) * 100.0

        total_output_results = max(
            len(validation.checks),
            len(api_doc.endpoints),
            1,
        )
        incorrect_output_results = min(total_output_results, len(validation.errors) + len(validation.warnings))
        correct_output_results = max(0, total_output_results - incorrect_output_results)
        accuracy = _safe_ratio(correct_output_results, total_output_results) * 100.0

        total_outputs = max(1, len(api_doc.endpoints) + len(design_doc.sequence_diagrams) + 1)
        hallucinated_outputs = min(
            total_outputs,
            placeholder_hits
            + orphan_endpoint_count
            + (1 if semantic_avg_score < 0.2 and semantic_hit_count > 0 else 0)
            + (1 if semantic_hit_count <= 0 and available_knowledge > 0 else 0),
        )
        hallucination_rate = _safe_ratio(hallucinated_outputs, total_outputs) * 100.0

        add_metric(
            dimension="准确性类",
            metric_name="召回率（Recall）",
            explanation="衡量相关知识被覆盖的完整度，反映“漏检”风险。",
            formula="检索到的相关信息数量 ÷ 所有相关信息总数量 ×100%",
            value_display=f"{recall:.2f}%",
            normal_range="复杂知识检索 >=75%",
            passed=recall >= 75.0,
            calculation=(
                f"{recall:.2f}% = 相关命中({relevant_retrieved_count}, score>={relevant_threshold:.2f}) / "
                f"相关总量({all_relevant_total_count}) ×100%"
            ),
            score=_score_ge(recall, 75.0),
        )
        add_metric(
            dimension="准确性类",
            metric_name="精确率（Precision）",
            explanation="衡量命中结果中真正相关项的占比，反映“误检”风险。",
            formula="检索到的相关信息数量 ÷ 检索到的总信息数量 ×100%",
            value_display=f"{precision:.2f}%",
            normal_range=">=80%",
            passed=precision >= 80.0,
            calculation=(
                f"{precision:.2f}% = 相关命中({relevant_retrieved_count}) / "
                f"检索总量({retrieved_total_count}) ×100%"
            ),
            score=_score_ge(precision, 80.0),
        )
        add_metric(
            dimension="准确性类",
            metric_name="准确率（Accuracy）",
            explanation="衡量最终输出结果正确占比，体现交付内容可信度。",
            formula="输出正确的结果数量 ÷ 总输出结果数量 ×100%",
            value_display=f"{accuracy:.2f}%",
            normal_range="复杂逻辑推理 >=80%",
            passed=accuracy >= 80.0,
            calculation=(
                f"{accuracy:.2f}% = 正确结果({correct_output_results}) / "
                f"总结果({total_output_results}) ×100%"
            ),
            score=_score_ge(accuracy, 80.0),
        )
        add_metric(
            dimension="准确性类",
            metric_name="幻觉率",
            explanation="衡量输出中与事实或上下文不一致内容比例，越低越好。",
            formula="存在幻觉的输出数量 ÷ 总输出数量 ×100%",
            value_display=f"{hallucination_rate:.2f}%",
            normal_range="<=5%",
            passed=hallucination_rate <= 5.0,
            calculation=f"{hallucination_rate:.2f}% = 幻觉输出({hallucinated_outputs}) / 总输出({total_outputs}) ×100%",
            score=_score_le(hallucination_rate, 5.0),
        )

        # -------- 3) 输出质量类（核心：返工率）--------
        needs_rework_outputs = min(
            total_outputs,
            len(validation.errors) + len(validation.warnings) + orphan_endpoint_count + placeholder_hits,
        )
        rework_rate_method1 = _safe_ratio(needs_rework_outputs, total_outputs) * 100.0
        ai_output_time_ms = max(total_processing_ms, 1.0)
        manual_rework_time_ms = float(needs_rework_outputs) * 60000.0
        rework_rate_method2 = _safe_ratio(manual_rework_time_ms, ai_output_time_ms + manual_rework_time_ms) * 100.0
        rework_time_ratio = _safe_ratio(manual_rework_time_ms, ai_output_time_ms + manual_rework_time_ms) * 100.0

        total_consistency_tests = max(5, len(api_doc.endpoints) * 2)
        inconsistent_count = min(
            total_consistency_tests,
            len(validation.errors) * 2 + len(validation.warnings) + (1 if hallucination_rate > 5.0 else 0),
        )
        consistent_count = total_consistency_tests - inconsistent_count
        consistency_rate = _safe_ratio(consistent_count, total_consistency_tests) * 100.0

        format_total_checks, format_passed_checks = _compute_format_compliance_counts(
            requirement=requirement,
            design_doc=design_doc,
            api_doc=api_doc,
        )
        format_compliance_rate = _safe_ratio(format_passed_checks, format_total_checks) * 100.0

        add_metric(
            dimension="输出质量类",
            metric_name="AI输出返工率",
            explanation="衡量输出需要人工返修的比例，综合看返工数量与返工耗时。",
            formula=(
                "方式1：需要返工输出数量 ÷ 总输出数量 ×100%；"
                "方式2：返工耗时 ÷ (AI输出耗时+返工耗时) ×100%"
            ),
            value_display=f"方式1={rework_rate_method1:.2f}%，方式2={rework_rate_method2:.2f}%",
            normal_range="复杂场景（代码/架构设计） <=40%",
            passed=rework_rate_method1 <= 40.0 and rework_rate_method2 <= 40.0,
            calculation=(
                f"方式1: {rework_rate_method1:.2f}% = 返工输出({needs_rework_outputs})/总输出({total_outputs})；"
                f" 方式2: {rework_rate_method2:.2f}% = 返工耗时({manual_rework_time_ms:.0f}ms)/"
                f"(AI耗时({ai_output_time_ms:.2f}ms)+返工耗时)"
            ),
            score=(_score_le(rework_rate_method1, 40.0) + _score_le(rework_rate_method2, 40.0)) / 2.0,
        )
        add_metric(
            dimension="输出质量类",
            metric_name="返工耗时占比",
            explanation="衡量人工返工时间在总交付时间中的占比，反映自动化交付质量。",
            formula="人工修改AI输出总耗时 ÷ (AI输出总耗时+人工返工总耗时) ×100%",
            value_display=f"{rework_time_ratio:.2f}%",
            normal_range="<=30%",
            passed=rework_time_ratio <= 30.0,
            calculation=(
                f"{rework_time_ratio:.2f}% = 人工返工({manual_rework_time_ms:.0f}ms) / "
                f"(AI输出({ai_output_time_ms:.2f}ms)+人工返工) ×100%"
            ),
            score=_score_le(rework_time_ratio, 30.0),
        )
        add_metric(
            dimension="输出质量类",
            metric_name="输出一致性",
            explanation="衡量同输入下输出稳定性，体现结果可复现与可预测能力。",
            formula="相同输入下输出一致的次数 ÷ 总测试次数 ×100%",
            value_display=f"{consistency_rate:.2f}%",
            normal_range=">=90%",
            passed=consistency_rate >= 90.0,
            calculation=(
                f"{consistency_rate:.2f}% = 一致输出({consistent_count}) / "
                f"总测试({total_consistency_tests}) ×100%"
            ),
            score=_score_ge(consistency_rate, 90.0),
        )
        add_metric(
            dimension="输出质量类",
            metric_name="格式合规率",
            explanation="衡量产出是否符合结构规范、字段完整性与模板要求。",
            formula="格式合规的输出数量 ÷ 总输出数量 ×100%",
            value_display=f"{format_compliance_rate:.2f}%",
            normal_range=">=95%",
            passed=format_compliance_rate >= 95.0,
            calculation=(
                f"{format_compliance_rate:.2f}% = 合规项({format_passed_checks}) / "
                f"总检查项({format_total_checks}) ×100%"
            ),
            score=_score_ge(format_compliance_rate, 95.0),
        )

        # -------- 4) 效率类（核心：耗时）--------
        add_metric(
            dimension="效率类",
            metric_name="响应耗时（Latency）",
            explanation="衡量用户首次获得结果的等待时间，影响交互体验。",
            formula="从输入完成到首次输出的时间差（毫秒）",
            value_display=f"{response_latency_ms:.2f} ms",
            normal_range="复杂任务 <=5000ms",
            passed=response_latency_ms <= 5000.0,
            calculation=f"response_latency_ms={response_latency_ms:.2f}",
            score=_score_le(response_latency_ms, 5000.0),
        )
        add_metric(
            dimension="效率类",
            metric_name="总处理耗时",
            explanation="衡量完整任务闭环耗时，反映端到端执行效率。",
            formula="从输入完成到输出全部结束的时间差（毫秒）",
            value_display=f"{total_processing_ms:.2f} ms",
            normal_range="代码生成 <=10000ms",
            passed=total_processing_ms <= 10000.0,
            calculation=f"total_processing_ms={total_processing_ms:.2f}",
            score=_score_le(total_processing_ms, 10000.0),
        )

        pass_count = sum(1 for item in rows if item.get("status") == "PASS")
        total_count = len(rows)
        fail_count = max(0, total_count - pass_count)
        pass_ratio = _safe_ratio(pass_count, total_count) * 100.0
        avg_score = _avg_float([_to_float(item.get("score"), 0.0) for item in rows])
        if avg_score >= 90.0:
            grade = "A"
        elif avg_score >= 80.0:
            grade = "B"
        elif avg_score >= 70.0:
            grade = "C"
        else:
            grade = "D"

        return {
            "rows": rows,
            "summary": {
                "total_metrics": total_count,
                "pass_count": pass_count,
                "fail_count": fail_count,
                "pass_ratio": f"{pass_ratio:.2f}%",
                "avg_score": f"{avg_score:.2f}",
                "grade": grade,
            },
            "assumptions": [
                "token 采用工程内估算口径（字符/单词混合估算），非模型原生 usage 回传值。",
                "召回率相关总量采用知识库可观测数据估算（references/patterns/retrieval hits）。",
                "返工耗时与输出一致性采用质量告警驱动的估算模型，用于横向对比与趋势观测。",
                "阈值按复杂文档/架构设计场景执行；如需更严门禁可在策略中二次收敛。",
            ],
        }

    @staticmethod
    def _build_quality_gate(
        quality_report: dict[str, Any],
        validation: ValidationReport,
        policy: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """基于策略执行第四阶段质量门禁判定。

        判定来源：
        - `quality_report`（第三阶段输出）；
        - `validation`（Reviewer 校验输出）；
        - `policy`（可配置阈值与权重）。

        输出：
        - decision: PASS/WARN/BLOCK
        - score: 0~100
        - blocking_issues / warning_issues / auto_fix_actions
        """
        policy = policy if isinstance(policy, dict) else {}
        block_policy = policy.get("block") if isinstance(policy.get("block"), dict) else {}
        warn_policy = policy.get("warn") if isinstance(policy.get("warn"), dict) else {}
        score_policy = policy.get("score") if isinstance(policy.get("score"), dict) else {}

        # block / warn / score 三类策略分别负责：
        # - block: 阻断条件
        # - warn: 告警条件
        # - score: 评分扣减权重
        block_on_validation_errors = _to_bool(block_policy.get("on_validation_errors"), True)
        block_risk_levels = set(_to_upper_list(block_policy.get("risk_levels"), default=["HIGH"]))
        block_semantic_hit_count_lte = _to_int(block_policy.get("semantic_hit_count_lte"), -1)
        block_citation_ratio_lt = _to_float(block_policy.get("citation_coverage_ratio_lt"), -1.0)
        block_orphan_endpoint_count_gt = _to_int(block_policy.get("orphan_endpoint_count_gt"), -1)

        warn_risk_levels = set(_to_upper_list(warn_policy.get("risk_levels"), default=["MEDIUM"]))
        warn_semantic_hit_count_lte = _to_int(warn_policy.get("semantic_hit_count_lte"), 0)
        warn_citation_ratio_lt = _to_float(warn_policy.get("citation_coverage_ratio_lt"), 0.30)
        warn_orphan_endpoint_count_gt = _to_int(warn_policy.get("orphan_endpoint_count_gt"), 0)
        warn_include_validation_warnings = _to_bool(warn_policy.get("include_validation_warnings"), True)

        score_base = _to_int(score_policy.get("base"), 100)
        score_validation_error = _to_int(score_policy.get("validation_error"), 20)
        score_validation_warning = _to_int(score_policy.get("validation_warning"), 3)
        score_hallucination_high = _to_int(score_policy.get("hallucination_high"), 25)
        score_hallucination_medium = _to_int(score_policy.get("hallucination_medium"), 12)
        score_hallucination_score_unit = _to_int(score_policy.get("hallucination_score_unit"), 3)
        score_semantic_hit_zero = _to_int(score_policy.get("semantic_hit_zero"), 15)
        score_citation_ratio_low = _to_int(score_policy.get("citation_ratio_low"), 10)
        score_cap_validation_error = _to_int(score_policy.get("cap_validation_error"), 60)
        score_cap_validation_warning = _to_int(score_policy.get("cap_validation_warning"), 20)
        score_cap_hallucination_score = _to_int(score_policy.get("cap_hallucination_score"), 20)

        validation_errors = [item for item in validation.errors if _to_str(item)]
        validation_warnings = [item for item in validation.warnings if _to_str(item)]
        hallucination_risk_level = _to_str(quality_report.get("hallucination_risk_level"), "UNKNOWN").upper()
        hallucination_risk_score = int(_to_float(quality_report.get("hallucination_risk_score"), 0.0))
        semantic_hit_count = int(_to_float(quality_report.get("semantic_hit_count"), 0.0))
        citation_ratio = _to_float(quality_report.get("citation_coverage_ratio"), 0.0)
        orphan_endpoint_count = int(_to_float(quality_report.get("orphan_endpoint_count"), 0.0))
        risk_signals = [_to_str(item) for item in quality_report.get("risk_signals", []) if _to_str(item)]

        blocking_issues: list[str] = []
        warning_issues: list[str] = []
        reasons: list[str] = []

        # 1) 先计算阻断条件（只要命中任一条即 BLOCK）
        if validation_errors and block_on_validation_errors:
            blocking_issues.extend(validation_errors)
            reasons.append(f"validation_errors={len(validation_errors)}")
        if hallucination_risk_level in block_risk_levels:
            blocking_issues.append(f"幻觉风险等级为 {hallucination_risk_level}。")
            reasons.append(f"hallucination_risk={hallucination_risk_level}")
        if block_semantic_hit_count_lte >= 0 and semantic_hit_count <= block_semantic_hit_count_lte:
            blocking_issues.append(f"语义检索命中数过低（<= {block_semantic_hit_count_lte}）。")
            reasons.append("semantic_hits_blocked")
        if block_citation_ratio_lt >= 0 and citation_ratio < block_citation_ratio_lt:
            blocking_issues.append(f"公共知识引用覆盖率过低（< {block_citation_ratio_lt:.2f}）。")
            reasons.append("citation_ratio_blocked")
        if block_orphan_endpoint_count_gt >= 0 and orphan_endpoint_count > block_orphan_endpoint_count_gt:
            blocking_issues.append(f"接口归属未对齐数量过高（> {block_orphan_endpoint_count_gt}）。")
            reasons.append("orphan_endpoint_blocked")

        # 2) 再计算告警条件（不阻断，但会给 WARN）
        if semantic_hit_count <= warn_semantic_hit_count_lte:
            warning_issues.append("公共知识语义检索未命中。")
            reasons.append(f"semantic_hits<={warn_semantic_hit_count_lte}")
        if citation_ratio < warn_citation_ratio_lt:
            warning_issues.append(f"公共知识引用覆盖率偏低（<{warn_citation_ratio_lt:.2f}）。")
            reasons.append(f"citation_ratio<{warn_citation_ratio_lt:.2f}")
        if orphan_endpoint_count > warn_orphan_endpoint_count_gt:
            warning_issues.append(f"存在 {orphan_endpoint_count} 个接口归属未对齐影响系统。")
            reasons.append(f"orphan_endpoint>{warn_orphan_endpoint_count_gt}")
        if hallucination_risk_level in warn_risk_levels:
            warning_issues.append(f"幻觉风险等级为 {hallucination_risk_level}。")
            reasons.append(f"hallucination_risk_warn={hallucination_risk_level}")
        if validation_warnings and warn_include_validation_warnings:
            warning_issues.extend(validation_warnings)

        # 3) 门禁决策优先级：BLOCK > WARN > PASS
        if blocking_issues:
            decision = "BLOCK"
        elif warning_issues:
            decision = "WARN"
        else:
            decision = "PASS"

        # 4) 给出可执行的自动修复建议，方便下一轮迭代直接落地
        auto_fix_actions: list[str] = []
        if semantic_hit_count <= warn_semantic_hit_count_lte:
            auto_fix_actions.append("补充公共知识库 documents 语料后重新执行 generate。")
        if citation_ratio < warn_citation_ratio_lt:
            auto_fix_actions.append("在设计文档与接口策略中显式引用公共知识条目。")
        if orphan_endpoint_count > warn_orphan_endpoint_count_gt:
            auto_fix_actions.append("校正接口 owner_system 与 impacts 映射关系。")
        if hallucination_risk_level in warn_risk_levels.union(block_risk_levels):
            auto_fix_actions.append("对 semantic top hits 逐条人工复核，清理低相关引用。")
        if validation_errors:
            auto_fix_actions.append("先修复 validation errors，再进行下一阶段交付。")
        if not auto_fix_actions:
            auto_fix_actions.append("当前质量门禁通过，建议保留抽样评审。")

        # 5) 打分：可配置权重的减分模型，最终夹紧到 0~100 区间
        score = score_base
        score -= min(score_cap_validation_error, len(validation_errors) * score_validation_error)
        score -= min(score_cap_validation_warning, len(validation_warnings) * score_validation_warning)
        if hallucination_risk_level == "HIGH":
            score -= score_hallucination_high
        elif hallucination_risk_level == "MEDIUM":
            score -= score_hallucination_medium
        score -= min(score_cap_hallucination_score, hallucination_risk_score * score_hallucination_score_unit)
        score -= score_semantic_hit_zero if semantic_hit_count <= warn_semantic_hit_count_lte else 0
        score -= score_citation_ratio_low if citation_ratio < warn_citation_ratio_lt else 0
        score = max(0, min(100, score))

        return {
            "decision": decision,
            "score": score,
            "reasons": reasons,
            "blocking_issues": _unique_str(blocking_issues),
            "warning_issues": _unique_str(warning_issues),
            "risk_signals": risk_signals,
            "auto_fix_actions": _unique_str(auto_fix_actions),
        }

def _to_str(value: Any, default: str = "") -> str:
    """安全转字符串：None/空串回退到 default。"""
    if value is None:
        return default
    if isinstance(value, str):
        text = value.strip()
        return text or default
    text = str(value).strip()
    return text or default


def _to_bool(value: Any, default: bool = False) -> bool:
    """宽松布尔解析，兼容 1/0/yes/no/on/off 文本。"""
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = _to_str(value).lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off"}:
        return False
    return default


def _to_int(value: Any, default: int = 0) -> int:
    """宽松整数解析，允许 float/string 输入。"""
    if value is None:
        return default
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    text = _to_str(value)
    if not text:
        return default
    try:
        return int(float(text))
    except ValueError:
        return default


def _to_float(value: Any, default: float = 0.0) -> float:
    """宽松浮点解析，解析失败时回退 default。"""
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = _to_str(value)
    if not text:
        return default
    try:
        return float(text)
    except ValueError:
        return default


def _to_upper_list(value: Any, default: list[str] | None = None) -> list[str]:
    """把列表元素归一化为大写字符串。"""
    fallback = default or []
    if not isinstance(value, list):
        return fallback
    output: list[str] = []
    for item in value:
        text = _to_str(item).upper()
        if text:
            output.append(text)
    return output or fallback


def _avg_float(values: list[float]) -> float:
    """计算均值，空数组返回 0.0。"""
    if not values:
        return 0.0
    return sum(values) / len(values)


def _safe_ratio(numerator: float, denominator: float) -> float:
    """安全比值计算，分母为 0 时返回 0。"""
    if denominator <= 0:
        return 0.0
    return numerator / denominator


def _elapsed_ms(start_perf_counter: float) -> float:
    """计算从某个 perf_counter 起点到当前的毫秒耗时。"""
    return (time.perf_counter() - start_perf_counter) * 1000.0


def _estimate_tokens(text: str) -> int:
    """轻量 token 估算。

    说明：
    - 中文按“汉字数”近似；
    - 英文/数字按“词数×1.2”近似；
    - 标点按“数量×0.25”补偿。
    """
    content = _to_str(text)
    if not content:
        return 0
    chinese_chars = len(re.findall(r"[\u4e00-\u9fff]", content))
    latin_words = len(re.findall(r"[A-Za-z0-9_]+", content))
    punctuation = len(re.findall(r"[^\w\s\u4e00-\u9fff]", content))
    estimated = chinese_chars + int(latin_words * 1.2) + int(punctuation * 0.25)
    return max(1, estimated)


def _build_impacted_context_text(
    context: ContextSnapshot,
    impacts: list[ImpactItem],
) -> str:
    """提取受影响系统的上下文文本，供输入 token 估算。"""
    repo_map = {repo.name: repo for repo in context.repos}
    chunks: list[str] = []
    for item in impacts:
        repo = repo_map.get(item.system)
        if repo is None:
            continue
        chunk = {
            "name": repo.name,
            "port": repo.port,
            "modules": repo.modules[:8],
            "datasources": repo.datasources[:6],
            "providers": repo.dubbo_providers[:8],
            "references": repo.dubbo_references[:8],
            "tables": repo.tables[:12],
        }
        chunks.append(json.dumps(chunk, ensure_ascii=False))
    return "\n".join(chunks)


def _compute_format_compliance_counts(
    requirement: RequirementInput,
    design_doc: DesignDoc,
    api_doc: ApiDoc,
) -> tuple[int, int]:
    """计算格式合规检查项通过数。"""
    endpoint_fields_complete = all(
        bool(endpoint.request_fields and endpoint.response_fields and endpoint.error_codes)
        for endpoint in api_doc.endpoints
    ) if api_doc.endpoints else False

    checks: list[bool] = [
        bool(_to_str(requirement.background)),
        bool(requirement.goals),
        bool(requirement.scope_in),
        bool(requirement.constraints),
        bool(requirement.acceptance_criteria),
        bool(_to_str(design_doc.architecture_diagram)),
        bool(design_doc.sequence_diagrams),
        bool(design_doc.data_model_notes),
        bool(design_doc.test_plan),
        bool(api_doc.endpoints),
        endpoint_fields_complete,
        bool(api_doc.common_policy),
        bool(api_doc.common_errors),
    ]
    total = len(checks)
    passed = sum(1 for item in checks if item)
    return total, passed


def _unique_str(items: list[str]) -> list[str]:
    """字符串去重并保留原始顺序。"""
    seen: set[str] = set()
    output: list[str] = []
    for item in items:
        text = _to_str(item)
        if not text or text in seen:
            continue
        seen.add(text)
        output.append(text)
    return output


def _safe_error_label(exc: Exception) -> str:
    """仅输出异常类型，避免把敏感路径/细节泄露到产物。"""
    name = exc.__class__.__name__.strip()
    return name or "RuntimeError"
