from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Protocol
from urllib import error, request

from app.schemas import ContextSnapshot
from app.utils import dump_json, load_json, now_iso


DRAFT_STATUS_PENDING = "PENDING_REVIEW"
DRAFT_STATUS_APPROVED = "APPROVED"
DRAFT_STATUS_REJECTED = "REJECTED"
ALLOWED_DRAFT_STATUS = {DRAFT_STATUS_PENDING, DRAFT_STATUS_APPROVED, DRAFT_STATUS_REJECTED}
PUBLIC_KB_DIR_PLACEHOLDER = "{{PUBLIC_KB_DIR}}"
KB_CACHE_DIR_PLACEHOLDER = "{{KB_CACHE_DIR}}"


@dataclass
class PublicKnowledgeContext:
    namespace: str
    source: str
    retrieved_at: str
    domain_systems: list[str] = field(default_factory=list)
    requirement_patterns: list[str] = field(default_factory=list)
    architecture_patterns: list[str] = field(default_factory=list)
    interface_patterns: list[str] = field(default_factory=list)
    coding_standards: list[str] = field(default_factory=list)
    recent_cases: list[dict[str, str]] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    retrieval_hits: list[dict[str, str]] = field(default_factory=list)
    retrieval_metrics: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def empty(source: str, namespace: str) -> "PublicKnowledgeContext":
        return PublicKnowledgeContext(
            namespace=namespace,
            source=source,
            retrieved_at=now_iso(),
        )

    @property
    def enabled(self) -> bool:
        return any(
            [
                self.domain_systems,
                self.requirement_patterns,
                self.architecture_patterns,
                self.interface_patterns,
                self.coding_standards,
                self.recent_cases,
                self.references,
                self.retrieval_hits,
            ]
        )


@dataclass
class PublicKnowledgeDraftReceipt:
    provider: str
    namespace: str
    draft_id: str
    status: str
    approval_status: str
    message: str = ""
    path: str = ""
    reviewed_by: str = ""
    reviewed_at: str = ""
    audit_path: str = ""

    def to_dict(self) -> dict[str, str]:
        return {
            "provider": self.provider,
            "namespace": self.namespace,
            "draft_id": self.draft_id,
            "status": self.status,
            "approval_status": self.approval_status,
            "message": self.message,
            "path": self.path,
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at,
            "audit_path": self.audit_path,
        }


class KnowledgeProvider(Protocol):
    def fetch_context(
        self,
        requirement_text: str,
        context: ContextSnapshot,
        limit: int = 20,
    ) -> PublicKnowledgeContext:
        raise NotImplementedError

    def submit_draft(
        self,
        requirement_name: str,
        draft_payload: dict[str, Any],
        context: ContextSnapshot | None = None,
    ) -> dict[str, str]:
        raise NotImplementedError

    def update_draft_status(
        self,
        draft_id: str,
        status: str,
        reviewer: str = "",
        note: str = "",
    ) -> dict[str, str]:
        raise NotImplementedError

    def read_audit_events(self, limit: int = 20) -> list[dict[str, str]]:
        raise NotImplementedError


class LocalKnowledgeProvider:
    def __init__(self, kb_dir: str | Path, namespace: str = "default") -> None:
        self.kb_dir = Path(kb_dir).expanduser().resolve()
        self.namespace = namespace
        self.drafts_dir = self.kb_dir / "drafts"
        self.audit_file = self.kb_dir / "audit" / "audit_log.jsonl"

    def fetch_context(
        self,
        requirement_text: str,
        context: ContextSnapshot,
        limit: int = 20,
    ) -> PublicKnowledgeContext:
        try:
            if not self.kb_dir.exists():
                raise FileNotFoundError(f"本地公共知识库目录不存在: {self.kb_dir}")

            payload = self._load_payload()
            retrieval_hits, retrieval_metrics = _semantic_retrieve_and_rerank(
                payload=payload,
                requirement_text=requirement_text,
                context=context,
                limit=limit,
            )
            knowledge = _context_from_payload(
                payload=payload,
                namespace=self.namespace,
                source=f"local:{PUBLIC_KB_DIR_PLACEHOLDER}",
                retrieval_hits=retrieval_hits,
                retrieval_metrics=retrieval_metrics,
            )
            if retrieval_hits:
                derived = _derive_patterns_from_hits(retrieval_hits)
                knowledge.requirement_patterns = _merge_text_lists(
                    knowledge.requirement_patterns,
                    derived.get("requirement_patterns", []),
                )
                knowledge.architecture_patterns = _merge_text_lists(
                    knowledge.architecture_patterns,
                    derived.get("architecture_patterns", []),
                )
                knowledge.interface_patterns = _merge_text_lists(
                    knowledge.interface_patterns,
                    derived.get("interface_patterns", []),
                )
                knowledge.coding_standards = _merge_text_lists(
                    knowledge.coding_standards,
                    derived.get("coding_standards", []),
                )
                hit_refs = [f"semantic_hit:{item.get('id') or item.get('title', '')}" for item in retrieval_hits]
                knowledge.references = _merge_text_lists(knowledge.references, hit_refs)
            self._audit(
                action="READ_CONTEXT",
                status="SUCCESS",
                detail={
                    "source": knowledge.source,
                    "namespace": knowledge.namespace,
                    "hit_count": str(len(knowledge.retrieval_hits)),
                    "avg_score": knowledge.retrieval_metrics.get("avg_score", "0.0000"),
                },
            )
            return knowledge
        except Exception as exc:  # noqa: BLE001
            self._audit(
                action="READ_CONTEXT",
                status="FAILED",
                detail={"error": str(exc)},
            )
            raise

    def submit_draft(
        self,
        requirement_name: str,
        draft_payload: dict[str, Any],
        context: ContextSnapshot | None = None,  # noqa: ARG002 - reserved for parity
    ) -> dict[str, str]:
        if not self.kb_dir.exists():
            raise FileNotFoundError(f"本地公共知识库目录不存在: {self.kb_dir}")
        draft_id = _build_draft_id(self.namespace, requirement_name)
        now = now_iso()
        draft_doc = {
            "draft_id": draft_id,
            "namespace": self.namespace,
            "status": DRAFT_STATUS_PENDING,
            "approval_status": DRAFT_STATUS_PENDING,
            "created_at": now,
            "updated_at": now,
            "reviewed_at": "",
            "reviewed_by": "",
            "requirement_name": requirement_name,
            "source": "ai-delivery-engine",
            "payload": draft_payload,
        }
        draft_path = self.drafts_dir / f"{draft_id}.json"
        dump_json(draft_path, draft_doc)
        self._audit(
            action="WRITE_DRAFT",
            status="SUCCESS",
            detail={
                "draft_id": draft_id,
                "path": f"{PUBLIC_KB_DIR_PLACEHOLDER}/drafts/{draft_path.name}",
                "approval_status": DRAFT_STATUS_PENDING,
            },
        )
        return PublicKnowledgeDraftReceipt(
            provider="local",
            namespace=self.namespace,
            draft_id=draft_id,
            status="SUCCESS",
            approval_status=DRAFT_STATUS_PENDING,
            message="draft submitted to local public knowledge base",
            path=f"{PUBLIC_KB_DIR_PLACEHOLDER}/drafts/{draft_path.name}",
            audit_path=f"{PUBLIC_KB_DIR_PLACEHOLDER}/audit/{self.audit_file.name}",
        ).to_dict()

    def update_draft_status(
        self,
        draft_id: str,
        status: str,
        reviewer: str = "",
        note: str = "",
    ) -> dict[str, str]:
        normalized_status = status.strip().upper()
        if normalized_status not in ALLOWED_DRAFT_STATUS:
            raise ValueError(
                f"非法草稿状态: {status}. 允许值: {', '.join(sorted(ALLOWED_DRAFT_STATUS))}"
            )
        draft_path = self.drafts_dir / f"{draft_id}.json"
        if not draft_path.exists():
            raise FileNotFoundError(f"草稿不存在: {draft_path}")
        payload = load_json(draft_path)
        if not isinstance(payload, dict):
            raise RuntimeError(f"草稿文件格式错误: {draft_path}")

        now = now_iso()
        payload["status"] = "REVIEWED" if normalized_status != DRAFT_STATUS_PENDING else "DRAFT"
        payload["approval_status"] = normalized_status
        payload["updated_at"] = now
        payload["reviewed_at"] = now if normalized_status != DRAFT_STATUS_PENDING else ""
        payload["reviewed_by"] = reviewer.strip()
        payload["review_note"] = note.strip()
        dump_json(draft_path, payload)
        self._audit(
            action="UPDATE_DRAFT_STATUS",
            status="SUCCESS",
            detail={
                "draft_id": draft_id,
                "approval_status": normalized_status,
                "reviewed_by": reviewer.strip(),
            },
        )
        return PublicKnowledgeDraftReceipt(
            provider="local",
            namespace=self.namespace,
            draft_id=draft_id,
            status="SUCCESS",
            approval_status=normalized_status,
            message="draft status updated",
            path=f"{PUBLIC_KB_DIR_PLACEHOLDER}/drafts/{draft_path.name}",
            reviewed_by=reviewer.strip(),
            reviewed_at=payload.get("reviewed_at", ""),
            audit_path=f"{PUBLIC_KB_DIR_PLACEHOLDER}/audit/{self.audit_file.name}",
        ).to_dict()

    def read_audit_events(self, limit: int = 20) -> list[dict[str, str]]:
        return _read_jsonl_tail(self.audit_file, limit=limit)

    def _load_payload(self) -> dict[str, Any]:
        snapshot_names = [
            "public_knowledge_snapshot.json",
            "knowledge_snapshot.json",
            "knowledge.json",
        ]
        for name in snapshot_names:
            path = self.kb_dir / name
            if not path.exists():
                continue
            payload = load_json(path)
            if isinstance(payload, dict):
                return payload
        raise FileNotFoundError(
            "本地公共知识库缺少可读取的快照文件，"
            "请提供 public_knowledge_snapshot.json 或 knowledge_snapshot.json 或 knowledge.json"
        )

    def _audit(self, action: str, status: str, detail: dict[str, Any] | None = None) -> None:
        cleaned: dict[str, Any] = {}
        for key, value in (detail or {}).items():
            text = _to_str(value)
            text = text.replace(str(self.kb_dir), PUBLIC_KB_DIR_PLACEHOLDER)
            cleaned[key] = text
        event = {
            "ts": now_iso(),
            "provider": "local",
            "namespace": self.namespace,
            "action": action,
            "status": status,
            "detail": json.dumps(cleaned, ensure_ascii=False),
        }
        _append_jsonl(self.audit_file, event)


class HTTPKnowledgeProvider:
    def __init__(
        self,
        kb_url: str,
        namespace: str = "default",
        token: str = "",
        timeout_seconds: int = 20,
    ) -> None:
        self.kb_url = kb_url.rstrip("/")
        self.namespace = namespace
        self.token = token
        self.timeout_seconds = timeout_seconds
        self._audit_events: list[dict[str, str]] = []

    def fetch_context(
        self,
        requirement_text: str,
        context: ContextSnapshot,
        limit: int = 20,
    ) -> PublicKnowledgeContext:
        if not self.kb_url:
            raise ValueError("kb_url is required for HTTP provider.")
        body = {
            "namespace": self.namespace,
            "query": requirement_text,
            "limit": limit,
            "domain_systems": [repo.name for repo in context.repos],
            "shared_tables": context.shared_tables,
        }
        try:
            payload = self._request_json(path="/query", method="POST", body=body)
            if isinstance(payload, dict) and isinstance(payload.get("data"), dict):
                payload = payload["data"]
            if not isinstance(payload, dict):
                raise RuntimeError("公共知识库返回格式非法，期望JSON对象。")
            knowledge = _context_from_payload(
                payload=payload,
                namespace=self.namespace,
                source=f"remote:{self.kb_url}",
            )
            self._audit("READ_CONTEXT", "SUCCESS", {"source": knowledge.source})
            return knowledge
        except Exception as exc:  # noqa: BLE001
            self._audit("READ_CONTEXT", "FAILED", {"error": str(exc)})
            raise

    def submit_draft(
        self,
        requirement_name: str,
        draft_payload: dict[str, Any],
        context: ContextSnapshot | None = None,
    ) -> dict[str, str]:
        body = {
            "namespace": self.namespace,
            "requirement_name": requirement_name,
            "status": DRAFT_STATUS_PENDING,
            "approval_status": DRAFT_STATUS_PENDING,
            "context": context.to_dict() if context else {},
            "payload": draft_payload,
        }
        try:
            payload = self._request_json(path="/drafts", method="POST", body=body)
            if isinstance(payload, dict) and isinstance(payload.get("data"), dict):
                payload = payload["data"]
            if not isinstance(payload, dict):
                payload = {}
            draft_id = _to_str(payload.get("draft_id"), _build_draft_id(self.namespace, requirement_name))
            approval_status = _to_str(payload.get("approval_status"), DRAFT_STATUS_PENDING)
            receipt = PublicKnowledgeDraftReceipt(
                provider="remote",
                namespace=self.namespace,
                draft_id=draft_id,
                status="SUCCESS",
                approval_status=approval_status,
                message=_to_str(payload.get("message"), "draft submitted to remote public knowledge base"),
            ).to_dict()
            self._audit("WRITE_DRAFT", "SUCCESS", {"draft_id": draft_id, "approval_status": approval_status})
            return receipt
        except Exception as exc:  # noqa: BLE001
            self._audit("WRITE_DRAFT", "FAILED", {"error": str(exc)})
            raise

    def update_draft_status(
        self,
        draft_id: str,
        status: str,
        reviewer: str = "",
        note: str = "",
    ) -> dict[str, str]:
        normalized_status = status.strip().upper()
        if normalized_status not in ALLOWED_DRAFT_STATUS:
            raise ValueError(
                f"非法草稿状态: {status}. 允许值: {', '.join(sorted(ALLOWED_DRAFT_STATUS))}"
            )
        body = {
            "namespace": self.namespace,
            "draft_id": draft_id,
            "approval_status": normalized_status,
            "reviewed_by": reviewer.strip(),
            "review_note": note.strip(),
        }
        try:
            payload = self._request_json(path=f"/drafts/{draft_id}/status", method="POST", body=body)
            if isinstance(payload, dict) and isinstance(payload.get("data"), dict):
                payload = payload["data"]
            if not isinstance(payload, dict):
                payload = {}
            receipt = PublicKnowledgeDraftReceipt(
                provider="remote",
                namespace=self.namespace,
                draft_id=draft_id,
                status="SUCCESS",
                approval_status=_to_str(payload.get("approval_status"), normalized_status),
                message=_to_str(payload.get("message"), "draft status updated"),
                reviewed_by=_to_str(payload.get("reviewed_by"), reviewer.strip()),
                reviewed_at=_to_str(payload.get("reviewed_at"), now_iso()),
            ).to_dict()
            self._audit(
                "UPDATE_DRAFT_STATUS",
                "SUCCESS",
                {"draft_id": draft_id, "approval_status": receipt["approval_status"]},
            )
            return receipt
        except Exception as exc:  # noqa: BLE001
            self._audit("UPDATE_DRAFT_STATUS", "FAILED", {"error": str(exc), "draft_id": draft_id})
            raise

    def read_audit_events(self, limit: int = 20) -> list[dict[str, str]]:
        if limit <= 0:
            return []
        return self._audit_events[-limit:]

    def _request_json(self, path: str, method: str, body: dict[str, Any]) -> Any:
        endpoint = f"{self.kb_url}{path}"
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.token.strip():
            headers["Authorization"] = f"Bearer {self.token.strip()}"
        req = request.Request(endpoint, data=payload, headers=headers, method=method)
        try:
            with request.urlopen(req, timeout=self.timeout_seconds) as resp:
                raw = resp.read().decode("utf-8")
        except error.HTTPError as exc:
            message = _read_http_error(exc)
            raise RuntimeError(f"公共知识库HTTP错误: status={exc.code}, detail={message}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"公共知识库连接失败: {exc.reason}") from exc
        try:
            return json.loads(raw)
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError("公共知识库返回了非JSON内容。") from exc

    def _audit(self, action: str, status: str, detail: dict[str, Any] | None = None) -> None:
        event = {
            "ts": now_iso(),
            "provider": "remote",
            "namespace": self.namespace,
            "action": action,
            "status": status,
            "detail": json.dumps(detail or {}, ensure_ascii=False),
        }
        self._audit_events.append(event)


class HybridKnowledgeProvider:
    def __init__(
        self,
        namespace: str,
        cache_dir: str | Path,
        remote_provider: HTTPKnowledgeProvider | None = None,
        local_provider: LocalKnowledgeProvider | None = None,
    ) -> None:
        self.namespace = namespace
        self.cache_dir = Path(cache_dir).expanduser().resolve()
        self.remote_provider = remote_provider
        self.local_provider = local_provider
        self.audit_file = self.cache_dir / "audit" / "audit_log.jsonl"

    def fetch_context(
        self,
        requirement_text: str,
        context: ContextSnapshot,
        limit: int = 20,
    ) -> PublicKnowledgeContext:
        cache_path = self._cache_path(requirement_text, context)
        remote_error = ""

        if self.remote_provider is not None:
            try:
                remote_context = self.remote_provider.fetch_context(requirement_text, context, limit=limit)
                dump_json(cache_path, remote_context.to_dict())
                self._audit("READ_CONTEXT", "SUCCESS", {"source": remote_context.source, "strategy": "remote"})
                return remote_context
            except Exception as exc:  # noqa: BLE001
                remote_error = str(exc)
                self._audit("READ_CONTEXT_REMOTE", "FAILED", {"error": remote_error})

        cached = self._read_cache(cache_path)
        if cached is not None:
            self._audit("READ_CONTEXT", "SUCCESS", {"source": cached.source, "strategy": "cache"})
            return cached

        if self.local_provider is not None:
            local_context = self.local_provider.fetch_context(requirement_text, context, limit=limit)
            if remote_error:
                local_context.references.append(f"remote_fallback_reason: {remote_error}")
            self._audit("READ_CONTEXT", "SUCCESS", {"source": local_context.source, "strategy": "local"})
            return local_context

        if remote_error:
            raise RuntimeError(f"hybrid provider fallback failed: {remote_error}")
        raise RuntimeError("hybrid provider has no available remote/local sources.")

    def submit_draft(
        self,
        requirement_name: str,
        draft_payload: dict[str, Any],
        context: ContextSnapshot | None = None,
    ) -> dict[str, str]:
        remote_error = ""
        if self.remote_provider is not None:
            try:
                receipt = self.remote_provider.submit_draft(
                    requirement_name=requirement_name,
                    draft_payload=draft_payload,
                    context=context,
                )
                receipt["provider"] = "hybrid(remote)"
                self._audit("WRITE_DRAFT", "SUCCESS", {"strategy": "remote", "draft_id": receipt.get("draft_id", "")})
                return receipt
            except Exception as exc:  # noqa: BLE001
                remote_error = str(exc)
                self._audit("WRITE_DRAFT_REMOTE", "FAILED", {"error": remote_error})

        if self.local_provider is not None:
            receipt = self.local_provider.submit_draft(
                requirement_name=requirement_name,
                draft_payload=draft_payload,
                context=context,
            )
            receipt["provider"] = "hybrid(local)"
            if remote_error:
                receipt["message"] = f"{receipt.get('message', '')}; remote_fallback_reason: {remote_error}".strip("; ")
            self._audit("WRITE_DRAFT", "SUCCESS", {"strategy": "local", "draft_id": receipt.get("draft_id", "")})
            return receipt

        raise RuntimeError(f"hybrid draft submit failed: {remote_error or 'no provider available'}")

    def update_draft_status(
        self,
        draft_id: str,
        status: str,
        reviewer: str = "",
        note: str = "",
    ) -> dict[str, str]:
        remote_error = ""
        if self.remote_provider is not None:
            try:
                receipt = self.remote_provider.update_draft_status(
                    draft_id=draft_id,
                    status=status,
                    reviewer=reviewer,
                    note=note,
                )
                receipt["provider"] = "hybrid(remote)"
                self._audit(
                    "UPDATE_DRAFT_STATUS",
                    "SUCCESS",
                    {"strategy": "remote", "draft_id": draft_id, "approval_status": receipt.get("approval_status", "")},
                )
                return receipt
            except Exception as exc:  # noqa: BLE001
                remote_error = str(exc)
                self._audit("UPDATE_DRAFT_STATUS_REMOTE", "FAILED", {"error": remote_error, "draft_id": draft_id})

        if self.local_provider is not None:
            receipt = self.local_provider.update_draft_status(
                draft_id=draft_id,
                status=status,
                reviewer=reviewer,
                note=note,
            )
            receipt["provider"] = "hybrid(local)"
            if remote_error:
                receipt["message"] = f"{receipt.get('message', '')}; remote_fallback_reason: {remote_error}".strip("; ")
            self._audit(
                "UPDATE_DRAFT_STATUS",
                "SUCCESS",
                {"strategy": "local", "draft_id": draft_id, "approval_status": receipt.get("approval_status", "")},
            )
            return receipt

        raise RuntimeError(f"hybrid update draft status failed: {remote_error or 'no provider available'}")

    def read_audit_events(self, limit: int = 20) -> list[dict[str, str]]:
        return _read_jsonl_tail(self.audit_file, limit=limit)

    def _cache_path(self, requirement_text: str, context: ContextSnapshot) -> Path:
        material = {
            "namespace": self.namespace,
            "query": requirement_text[:2000],
            "repos": sorted(repo.name for repo in context.repos),
        }
        digest = hashlib.sha256(
            json.dumps(material, ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()[:16]
        return self.cache_dir / f"{self.namespace}_{digest}.json"

    def _read_cache(self, path: Path) -> PublicKnowledgeContext | None:
        if not path.exists():
            return None
        try:
            payload = load_json(path)
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(payload, dict):
            return None
        return _context_from_payload(
            payload=payload,
            namespace=self.namespace,
            source=f"cache:{KB_CACHE_DIR_PLACEHOLDER}/{path.name}",
        )

    def _audit(self, action: str, status: str, detail: dict[str, Any] | None = None) -> None:
        event = {
            "ts": now_iso(),
            "provider": "hybrid",
            "namespace": self.namespace,
            "action": action,
            "status": status,
            "detail": json.dumps(detail or {}, ensure_ascii=False),
        }
        _append_jsonl(self.audit_file, event)


def build_knowledge_provider(
    kb_mode: str,
    kb_namespace: str = "default",
    kb_dir: str = "public_knowledge_base",
    kb_url: str = "",
    kb_token: str = "",
    kb_cache_dir: str = "outputs/kb_cache",
) -> KnowledgeProvider:
    mode = (kb_mode or "local").strip().lower()
    namespace = (kb_namespace or "default").strip()

    if mode == "local":
        return LocalKnowledgeProvider(kb_dir=kb_dir, namespace=namespace)

    if mode == "remote":
        if not kb_url.strip():
            raise ValueError("kb_mode=remote requires --kb-url.")
        return HTTPKnowledgeProvider(
            kb_url=kb_url,
            namespace=namespace,
            token=kb_token,
        )

    if mode == "hybrid":
        remote = None
        if kb_url.strip():
            remote = HTTPKnowledgeProvider(
                kb_url=kb_url,
                namespace=namespace,
                token=kb_token,
            )
        local = LocalKnowledgeProvider(kb_dir=kb_dir, namespace=namespace)
        return HybridKnowledgeProvider(
            namespace=namespace,
            cache_dir=kb_cache_dir,
            remote_provider=remote,
            local_provider=local,
        )

    raise ValueError(f"Unsupported kb_mode: {kb_mode}. Expected one of local/remote/hybrid.")


def _context_from_payload(
    payload: dict[str, Any],
    namespace: str,
    source: str,
    retrieval_hits: list[dict[str, str]] | None = None,
    retrieval_metrics: dict[str, str] | None = None,
) -> PublicKnowledgeContext:
    namespace_value = _to_str(payload.get("namespace"), namespace)
    source_value = _to_str(payload.get("source"), source)
    retrieved_at = _to_str(payload.get("retrieved_at"), now_iso())
    payload_hits = _to_hit_list(payload.get("retrieval_hits"))
    payload_metrics = _to_dict_str(payload.get("retrieval_metrics"))
    final_hits = retrieval_hits if retrieval_hits is not None else payload_hits
    final_metrics = retrieval_metrics if retrieval_metrics is not None else payload_metrics
    return PublicKnowledgeContext(
        namespace=namespace_value,
        source=source_value,
        retrieved_at=retrieved_at,
        domain_systems=_to_str_list(payload.get("domain_systems")),
        requirement_patterns=_to_str_list(payload.get("requirement_patterns")),
        architecture_patterns=_to_str_list(payload.get("architecture_patterns")),
        interface_patterns=_to_str_list(payload.get("interface_patterns")),
        coding_standards=_to_str_list(payload.get("coding_standards")),
        recent_cases=_to_case_list(payload.get("recent_cases")),
        references=_to_str_list(payload.get("references")),
        retrieval_hits=final_hits,
        retrieval_metrics=final_metrics,
    )


def _to_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    if isinstance(value, str):
        return value.strip() or default
    return str(value).strip() or default


def _to_str_list(value: Any) -> list[str]:
    if isinstance(value, list):
        out: list[str] = []
        for item in value:
            text = _to_str(item)
            if text:
                out.append(text)
        return out
    text = _to_str(value)
    return [text] if text else []


def _to_case_list(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    out: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        normalized = {str(k): _to_str(v) for k, v in item.items() if _to_str(v)}
        if normalized:
            out.append(normalized)
    return out


def _to_hit_list(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    output: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        normalized: dict[str, str] = {}
        for key, val in item.items():
            text = _to_str(val)
            if text:
                normalized[str(key)] = text
        if normalized:
            output.append(normalized)
    return output


def _to_dict_str(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    output: dict[str, str] = {}
    for key, val in value.items():
        text = _to_str(val)
        if text:
            output[str(key)] = text
    return output


def _read_http_error(exc: error.HTTPError) -> str:
    try:
        body = exc.read().decode("utf-8").strip()
    except Exception:  # noqa: BLE001
        body = ""
    if not body:
        return exc.reason
    if len(body) > 600:
        return body[:600] + "..."
    return body


def _semantic_retrieve_and_rerank(
    payload: dict[str, Any],
    requirement_text: str,
    context: ContextSnapshot,
    limit: int = 20,
) -> tuple[list[dict[str, str]], dict[str, str]]:
    """两阶段检索（召回 + 重排）。

    阶段一（召回）：
    - 基于 token overlap / jaccard / 领域词命中计算粗排分；
    - 选取 TopN 候选（limit * 3）。

    阶段二（重排）：
    - 叠加短语命中与文档类型对齐奖励；
    - 输出标准化命中列表与检索指标（hit_count/avg_score）。
    """
    documents = payload.get("documents")
    if not isinstance(documents, list) or not documents:
        return [], {"hit_count": "0", "avg_score": "0.0000", "rerank_applied": "false"}

    query_tokens = _tokenize(requirement_text)
    domain_tokens: set[str] = set()
    for repo in context.repos:
        domain_tokens.update(_tokenize(repo.name))
    if not query_tokens:
        query_tokens = set(_tokenize(" ".join(context.shared_tables.keys())))

    first_stage: list[dict[str, Any]] = []
    for idx, item in enumerate(documents):
        if not isinstance(item, dict):
            continue
        doc_id = _to_str(item.get("id"), f"doc-{idx + 1}")
        doc_type = _to_str(item.get("type"), "pattern")
        title = _to_str(item.get("title"), doc_id)
        text = _doc_text(item)
        if not text:
            continue
        doc_tokens = _tokenize(text)
        if not doc_tokens:
            continue

        overlap = _overlap_ratio(query_tokens, doc_tokens)
        jaccard = _jaccard(query_tokens, doc_tokens)
        domain_bonus = _overlap_ratio(domain_tokens, doc_tokens) if domain_tokens else 0.0
        keyword_bonus = _keyword_bonus(query_tokens, doc_type, text)
        stage1_score = 0.55 * overlap + 0.30 * jaccard + 0.10 * domain_bonus + 0.05 * keyword_bonus
        if stage1_score <= 0:
            continue
        first_stage.append(
            {
                "id": doc_id,
                "title": title,
                "type": doc_type,
                "text": text,
                "tags": _to_str_list(item.get("tags")),
                "stage1_score": stage1_score,
                "match_terms": sorted(query_tokens.intersection(doc_tokens))[:8],
            }
        )

    if not first_stage:
        return [], {"hit_count": "0", "avg_score": "0.0000", "rerank_applied": "false"}

    first_stage.sort(key=lambda x: float(x.get("stage1_score", 0.0)), reverse=True)
    candidates = first_stage[: max(limit * 3, 10)]

    reranked: list[dict[str, str]] = []
    for item in candidates:
        text = _to_str(item.get("text"))
        stage1 = float(item.get("stage1_score", 0.0))
        phrase_bonus = _phrase_bonus(requirement_text, text)
        type_bonus = _type_alignment_bonus(query_tokens, _to_str(item.get("type")))
        rerank_score = min(1.0, stage1 + 0.12 * phrase_bonus + 0.08 * type_bonus)
        reranked.append(
            {
                "id": _to_str(item.get("id")),
                "title": _to_str(item.get("title")),
                "type": _to_str(item.get("type")),
                "score": f"{rerank_score:.4f}",
                "stage1_score": f"{stage1:.4f}",
                "tags": ", ".join(_to_str_list(item.get("tags"))),
                "match_terms": ", ".join(_to_str_list(item.get("match_terms"))),
                "excerpt": _excerpt(text, query_tokens, 120),
            }
        )

    reranked.sort(key=lambda x: float(_to_str(x.get("score"), "0")), reverse=True)
    top_hits = reranked[:limit]
    avg_score = _avg([float(_to_str(item.get("score"), "0")) for item in top_hits])
    metrics = {
        "hit_count": str(len(top_hits)),
        "avg_score": f"{avg_score:.4f}",
        "rerank_applied": "true",
    }
    return top_hits, metrics


def _derive_patterns_from_hits(hits: list[dict[str, str]]) -> dict[str, list[str]]:
    """根据命中条目派生到四类模式库（需求/架构/接口/编码）。"""
    result = {
        "requirement_patterns": [],
        "architecture_patterns": [],
        "interface_patterns": [],
        "coding_standards": [],
    }
    for item in hits:
        doc_type = _to_str(item.get("type")).lower()
        text = _to_str(item.get("title")) or _to_str(item.get("excerpt"))
        if not text:
            continue
        if doc_type in {"requirement", "analysis", "acceptance"}:
            result["requirement_patterns"].append(text)
        elif doc_type in {"architecture", "design", "data_model"}:
            result["architecture_patterns"].append(text)
        elif doc_type in {"interface", "api", "contract"}:
            result["interface_patterns"].append(text)
        elif doc_type in {"code", "coding", "quality"}:
            result["coding_standards"].append(text)
    for key, values in result.items():
        result[key] = _unique(values)
    return result


def _merge_text_lists(primary: list[str], extra: list[str]) -> list[str]:
    """合并两组文本并去重，保持原始顺序。"""
    return _unique([*_to_str_list(primary), *_to_str_list(extra)])


def _tokenize(text: str) -> set[str]:
    """中英文混合分词。

    - 英文数字：按 `[a-z0-9_]+` 切词；
    - 中文：保留整词并生成 bigram，提升短句匹配能力。
    """
    clean = _to_str(text).lower()
    if not clean:
        return set()
    latin = re.findall(r"[a-z0-9_]+", clean)
    cjk = re.findall(r"[\u4e00-\u9fff]{2,}", clean)
    cjk_bigrams: list[str] = []
    for item in cjk:
        if len(item) == 2:
            cjk_bigrams.append(item)
            continue
        for idx in range(len(item) - 1):
            cjk_bigrams.append(item[idx : idx + 2])
    return set([*latin, *cjk, *cjk_bigrams])


def _doc_text(item: dict[str, Any]) -> str:
    """从多字段拼接文档可检索文本。"""
    parts = [
        _to_str(item.get("title")),
        _to_str(item.get("summary")),
        _to_str(item.get("text")),
        _to_str(item.get("content")),
        _to_str(item.get("body")),
        " ".join(_to_str_list(item.get("tags"))),
    ]
    return " ".join(part for part in parts if part).strip()


def _overlap_ratio(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a.intersection(b)) / max(1, len(a))


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a.intersection(b)) / max(1, len(a.union(b)))


def _keyword_bonus(query_tokens: set[str], doc_type: str, doc_text: str) -> float:
    """基于主题词给文档类型打奖励分。"""
    bonus = 0.0
    text = doc_text.lower()
    type_text = doc_type.lower()
    if any(token in query_tokens for token in {"需求", "目标", "验收", "scope", "goal"}):
        if any(key in type_text for key in ["requirement", "analysis", "acceptance"]):
            bonus += 0.5
    if any(token in query_tokens for token in {"架构", "时序", "表", "模型", "architecture", "design"}):
        if any(key in type_text for key in ["architecture", "design", "data_model"]):
            bonus += 0.5
    if any(token in query_tokens for token in {"接口", "api", "error", "幂等", "重试"}):
        if any(key in type_text for key in ["interface", "api", "contract"]):
            bonus += 0.5
    if "测试" in query_tokens or "coverage" in query_tokens:
        if any(key in text for key in ["test", "测试", "coverage", "质量"]):
            bonus += 0.3
    return min(1.0, bonus)


def _phrase_bonus(query_text: str, doc_text: str) -> float:
    """短语命中奖励：统计 query token 在文档中的出现比例。"""
    query_tokens = [token for token in _tokenize(query_text) if len(token) >= 2]
    if not query_tokens:
        return 0.0
    lower_doc = doc_text.lower()
    hit = 0
    for token in query_tokens[:20]:
        if token in lower_doc:
            hit += 1
    return hit / max(1, min(len(query_tokens), 20))


def _type_alignment_bonus(query_tokens: set[str], doc_type: str) -> float:
    """类型对齐奖励：需求词倾向 requirement，接口词倾向 api/interface。"""
    value = doc_type.lower()
    if not value:
        return 0.0
    bonus = 0.0
    if any(token in query_tokens for token in {"需求", "验收", "goal", "scope"}) and "requirement" in value:
        bonus += 0.5
    if any(token in query_tokens for token in {"架构", "时序", "design", "model"}) and "design" in value:
        bonus += 0.5
    if any(token in query_tokens for token in {"接口", "api", "error"}) and ("api" in value or "interface" in value):
        bonus += 0.5
    if any(token in query_tokens for token in {"代码", "quality", "test"}) and (
        "code" in value or "quality" in value
    ):
        bonus += 0.5
    return min(1.0, bonus)


def _excerpt(text: str, query_tokens: set[str], limit: int = 120) -> str:
    """生成命中摘要片段，优先截取 query 关键词附近上下文。"""
    if not text:
        return ""
    clean = re.sub(r"\s+", " ", text).strip()
    lower = clean.lower()
    match_pos = -1
    for token in sorted(query_tokens, key=len, reverse=True):
        if len(token) < 2:
            continue
        pos = lower.find(token)
        if pos >= 0:
            match_pos = pos
            break
    if match_pos < 0:
        return clean[:limit]
    start = max(0, match_pos - 30)
    return clean[start : start + limit]


def _avg(values: list[float]) -> float:
    if not values:
        return 0.0
    return sum(values) / len(values)


def _unique(items: list[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for item in items:
        text = _to_str(item)
        if not text or text in seen:
            continue
        seen.add(text)
        output.append(text)
    return output


def _build_draft_id(namespace: str, requirement_name: str) -> str:
    normalized = _safe_name(requirement_name)[:40]
    raw = f"{namespace}:{requirement_name}:{now_iso()}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:10]
    return f"draft_{normalized}_{digest}"


def _safe_name(text: str) -> str:
    value = re.sub(r"[^\w\-]+", "_", text.strip(), flags=re.UNICODE)
    value = value.strip("_")
    return value or "requirement"


def _append_jsonl(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def _read_jsonl_tail(path: Path, limit: int = 20) -> list[dict[str, str]]:
    if limit <= 0:
        return []
    if not path.exists():
        return []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except Exception:  # noqa: BLE001
        return []
    output: list[dict[str, str]] = []
    for raw in lines[-limit:]:
        try:
            obj = json.loads(raw)
        except Exception:  # noqa: BLE001
            continue
        if not isinstance(obj, dict):
            continue
        normalized = {str(k): _to_str(v) for k, v in obj.items()}
        output.append(normalized)
    return output
