from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from app.utils import read_text


REQUIREMENT_ANALYSIS_FILE = "Requirement_Analysis_Report_Standard.md"
TECHNICAL_DESIGN_FILE = "Technical_Design_Document_Standard.md"
INTERFACE_DOC_FILE = "Interface_Document_Standard.md"
CODE_DEVELOPMENT_FILE = "Code_Development_Standard.md"


@dataclass
class PublicRulebook:
    source_dir: str
    requirement_analysis: str
    technical_design: str
    interface_document: str
    code_development: str

    @staticmethod
    def empty(source_dir: str = "") -> "PublicRulebook":
        return PublicRulebook(
            source_dir=source_dir,
            requirement_analysis="",
            technical_design="",
            interface_document="",
            code_development="",
        )

    @property
    def enabled(self) -> bool:
        return any(
            [
                self.requirement_analysis.strip(),
                self.technical_design.strip(),
                self.interface_document.strip(),
                self.code_development.strip(),
            ]
        )


def load_public_rulebook(rules_dir: str | Path, strict: bool = True) -> PublicRulebook:
    root = Path(rules_dir).expanduser().resolve()
    expected_files = {
        "requirement_analysis": REQUIREMENT_ANALYSIS_FILE,
        "technical_design": TECHNICAL_DESIGN_FILE,
        "interface_document": INTERFACE_DOC_FILE,
        "code_development": CODE_DEVELOPMENT_FILE,
    }

    if not root.exists():
        if strict:
            raise FileNotFoundError(f"规则库目录不存在: {root}")
        return PublicRulebook.empty(source_dir=str(root))

    missing = [name for name in expected_files.values() if not (root / name).exists()]
    if missing and strict:
        missing_text = ", ".join(missing)
        raise FileNotFoundError(f"规则库缺少文件: {missing_text}")

    payload: dict[str, str] = {}
    for key, filename in expected_files.items():
        path = root / filename
        payload[key] = read_text(path).strip() if path.exists() else ""

    return PublicRulebook(
        source_dir=str(root),
        requirement_analysis=payload.get("requirement_analysis", ""),
        technical_design=payload.get("technical_design", ""),
        interface_document=payload.get("interface_document", ""),
        code_development=payload.get("code_development", ""),
    )
