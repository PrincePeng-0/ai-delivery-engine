from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from app.utils import load_json


QUALITY_GATE_POLICY_FILE = "Quality_Gate_Policy.json"

# 内置默认策略：
# - 当使用方未提供策略文件时，系统仍可按稳定的默认门禁运行；
# - 当使用方只覆盖部分字段时，未覆盖字段继续继承默认值。
DEFAULT_QUALITY_GATE_POLICY: dict[str, Any] = {
    "block": {
        "on_validation_errors": True,
        "risk_levels": ["HIGH"],
        "semantic_hit_count_lte": -1,
        "citation_coverage_ratio_lt": -1.0,
        "orphan_endpoint_count_gt": -1,
    },
    "warn": {
        "risk_levels": ["MEDIUM"],
        "semantic_hit_count_lte": 0,
        "citation_coverage_ratio_lt": 0.30,
        "orphan_endpoint_count_gt": 0,
        "include_validation_warnings": True,
    },
    "score": {
        "base": 100,
        "validation_error": 20,
        "validation_warning": 3,
        "hallucination_high": 25,
        "hallucination_medium": 12,
        "hallucination_score_unit": 3,
        "semantic_hit_zero": 15,
        "citation_ratio_low": 10,
        "cap_validation_error": 60,
        "cap_validation_warning": 20,
        "cap_hallucination_score": 20,
    },
}


def load_quality_gate_policy(
    policy_file: str | Path = "",
    rules_dir: str | Path = "",
    strict: bool = False,
) -> tuple[dict[str, Any], str]:
    """加载质量门禁策略并返回 (policy, source_label)。

    优先级：
    1. `policy_file`（显式传入）；
    2. `rules_dir/Quality_Gate_Policy.json`；
    3. 内置默认策略。

    strict 语义：
    - strict=True: 传入的策略文件必须存在且格式正确；
    - strict=False: 文件不可用时回退到内置默认策略。
    """
    default_policy = copy.deepcopy(DEFAULT_QUALITY_GATE_POLICY)
    path, source_label = _resolve_policy_source(policy_file=policy_file, rules_dir=rules_dir)
    if path is None:
        return default_policy, source_label
    if not path.exists():
        if strict:
            raise FileNotFoundError(f"质量门禁策略文件不存在: {path}")
        return default_policy, "built-in-default"
    try:
        payload = load_json(path)
    except Exception as exc:  # noqa: BLE001
        if strict:
            raise RuntimeError(f"质量门禁策略文件读取失败: {path}") from exc
        return default_policy, "built-in-default"
    if not isinstance(payload, dict):
        if strict:
            raise ValueError(f"质量门禁策略文件格式错误，期望 JSON Object: {path}")
        return default_policy, source_label
    merged = _deep_merge(default_policy, payload)
    return merged, source_label


def _resolve_policy_source(policy_file: str | Path, rules_dir: str | Path) -> tuple[Path | None, str]:
    """解析策略来源并生成对用户友好的来源标识。"""
    policy_text = str(policy_file).strip()
    if policy_text:
        path = Path(policy_text).expanduser().resolve()
        return path, f"custom:{path.name}"
    root_text = str(rules_dir).strip()
    if root_text:
        path = Path(root_text).expanduser().resolve() / QUALITY_GATE_POLICY_FILE
        if path.exists():
            return path, f"rules-default:{QUALITY_GATE_POLICY_FILE}"
    return None, "built-in-default"


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """深度合并字典。

    规则：`override` 同名键覆盖 `base`，子字典递归合并。
    """
    merged: dict[str, Any] = copy.deepcopy(base)
    for key, value in override.items():
        key_text = str(key)
        if key_text in merged and isinstance(merged[key_text], dict) and isinstance(value, dict):
            merged[key_text] = _deep_merge(merged[key_text], value)
            continue
        merged[key_text] = copy.deepcopy(value)
    return merged
