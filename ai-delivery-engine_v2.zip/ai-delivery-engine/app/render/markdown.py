from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from app.schemas import ApiDoc, ApiEndpoint, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput
from app.utils import read_text, to_markdown_list, to_markdown_table


PLACEHOLDER_PATTERN = re.compile(r"{{\s*([a-zA-Z0-9_]+)\s*}}")


def _render_template(template_path: Path, mapping: dict[str, str]) -> str:
    template = read_text(template_path)

    def _replace(match: re.Match[str]) -> str:
        key = match.group(1)
        return mapping.get(key, "")

    return PLACEHOLDER_PATTERN.sub(_replace, template)


def render_design_markdown(doc: DesignDoc, template_path: Path) -> str:
    impact_rows: list[list[str]] = []
    for impact in doc.impacts:
        impact_rows.append(
            [
                impact.system,
                impact.reason,
                "<br>".join(impact.changes) if impact.changes else "-",
            ]
        )
    if not impact_rows:
        impact_rows = [["-", "-", "-"]]
    impact_table = to_markdown_table(["系统", "影响原因", "关键改动建议"], impact_rows)

    sequence_sections: list[str] = []
    for seq in doc.sequence_diagrams:
        sequence_sections.append(f"#### {seq.title}\n```mermaid\n{seq.mermaid}\n```")
    sequence_md = "\n\n".join(sequence_sections) if sequence_sections else "- 无"

    base_name = _strip_design_title_suffix(str(doc.title or "未命名需求"))
    document_purpose = (
        f"基于《{base_name or '当前需求'}》需求分析结果，输出可开发、可测试、可评审的功能设计方案，"
        "明确功能边界、交互逻辑、数据规则与异常处理要求。"
    )
    applicable_scope_md = to_markdown_list(
        [
            f"包含范围：{', '.join(doc.scope_in) if doc.scope_in else '待补充'}",
            f"不包含范围：{', '.join(doc.scope_out) if doc.scope_out else '未明确'}",
            "使用对象：开发工程师、测试工程师、产品经理、项目经理。",
        ]
    )
    project_links_md = to_markdown_list(
        [
            f"需求分析报告：`{base_name}_Analysis_Report.md`",
            f"接口文档：`{base_name}_Interfaces.md`",
        ]
    )
    version_table_md = to_markdown_table(
        ["版本号", "编制人", "编制日期", "审核人", "审核日期", "批准人", "批准日期", "变更说明"],
        [["v1.0", "AI Agent", "自动生成", "待指定", "待指定", "待指定", "待指定", "初始版本"]],
    )

    software_positioning = (
        doc.background.strip()
        if str(doc.background).strip()
        else "围绕需求目标建设可演进的业务能力，确保功能可用、稳定、可扩展。"
    )
    core_modules_table_md = to_markdown_table(
        ["模块名称", "核心作用", "关键改动建议"],
        impact_rows,
    )
    design_principles_md = to_markdown_list(_build_design_principles(doc))

    detailed_function_design_md = _build_detailed_function_design(doc, sequence_md)
    database_overview_table_md = to_markdown_table(
        ["归属系统", "数据表/实体", "核心字段", "主键/索引建议", "读写场景", "补充说明"],
        _build_database_overview_rows(doc),
    )
    data_entities_table_md = to_markdown_table(
        ["实体名称", "字段名称", "数据类型", "字段长度", "是否必填", "默认值", "字段说明"],
        _build_data_entity_rows(doc),
    )
    data_relations_md = to_markdown_list(_build_data_relations(doc))
    er_diagram = _build_er_diagram(doc)
    data_storage_rules_md = to_markdown_list(_build_data_storage_rules(doc))
    interface_overview_table_md = to_markdown_table(
        ["接口名称", "请求方式", "请求参数（简要）", "返回参数（简要）", "接口说明"],
        _build_interface_rows(doc),
    )
    exception_table_md = to_markdown_table(
        ["异常类型", "异常描述", "处理方式", "日志记录要求"],
        _build_exception_rows(doc),
    )
    test_points_md = to_markdown_list(doc.test_plan or ["待补充测试要点：功能/异常/边界/兼容性/安全性测试。"])
    constraints_limits_md = to_markdown_list(_build_constraints_limits(doc))
    attachments_md = to_markdown_list(
        [
            "附件1：功能模块结构图（可由架构图导出）。",
            "附件2：批量操作模板（如有）。",
            "附件3：界面原型图（如有）。",
            f"附件4：详细接口文档（`{base_name}_Interfaces.md`）。",
            "附件5：数据字典与字段说明（本章数据设计可作为初始版本）。",
        ]
    )
    signoff_table_md = to_markdown_table(
        ["编制人（产品/设计）签字", "日期", "审核人（技术负责人）签字", "日期"],
        [["待签字", "待填写", "待签字", "待填写"]],
    ) + "\n\n" + to_markdown_table(
        ["批准人（项目经理）签字", "日期", "测试负责人签字", "日期"],
        [["待签字", "待填写", "待签字", "待填写"]],
    )

    mapping = {
        # 新 FRD 模板占位符
        "frd_title": doc.title or "未命名需求 - 开发设计文档",
        "document_purpose": document_purpose,
        "applicable_scope_md": applicable_scope_md,
        "project_links_md": project_links_md,
        "version_table_md": version_table_md,
        "software_positioning": software_positioning,
        "core_modules_table_md": core_modules_table_md,
        "architecture_diagram": doc.architecture_diagram,
        "design_principles_md": design_principles_md,
        "detailed_function_design_md": detailed_function_design_md,
        "database_overview_table_md": database_overview_table_md,
        "data_entities_table_md": data_entities_table_md,
        "data_relations_md": data_relations_md,
        "er_diagram": er_diagram,
        "data_storage_rules_md": data_storage_rules_md,
        "interface_overview_table_md": interface_overview_table_md,
        "exception_table_md": exception_table_md,
        "test_points_md": test_points_md,
        "constraints_limits_md": constraints_limits_md,
        "attachments_md": attachments_md,
        "signoff_table_md": signoff_table_md,
        # 兼容旧模板占位符
        "title": doc.title,
        "background": doc.background,
        "goals_md": to_markdown_list(doc.goals),
        "scope_in_md": to_markdown_list(doc.scope_in),
        "scope_out_md": to_markdown_list(doc.scope_out),
        "constraints_md": to_markdown_list(doc.constraints),
        "assumptions_md": to_markdown_list(doc.assumptions),
        "impact_table_md": impact_table,
        "sequence_md": sequence_md,
        "data_model_md": to_markdown_list(doc.data_model_notes),
        "test_plan_md": to_markdown_list(doc.test_plan),
        "release_plan_md": to_markdown_list(doc.release_plan),
        "risks_md": to_markdown_list(doc.risks),
        "context_summary": doc.context_summary,
    }
    return _render_template(template_path, mapping)


def _build_design_principles(doc: DesignDoc) -> list[str]:
    principles = [
        "实用性：设计内容与需求目标一一对应，避免与需求无关的过度设计。",
        "可扩展性：模块边界清晰，支持后续功能增量迭代和上下游扩展。",
        "一致性：交互、数据口径、错误码语义在各模块保持统一。",
        "安全性：严格遵循权限控制、审计留痕和敏感数据保护要求。",
    ]
    for item in doc.constraints[:3]:
        principles.append(f"约束遵循：{item}")
    return principles


def _strip_design_title_suffix(title: str) -> str:
    raw = (title or "").strip()
    if not raw:
        return "未命名需求"

    candidates = [
        " - 开发设计文档",
        " - 技术开发设计",
        " - 功能设计文档",
        " 开发设计文档",
        " 技术开发设计",
        " 功能设计文档",
        " FRD",
    ]
    for suffix in candidates:
        if raw.endswith(suffix):
            stripped = raw[: -len(suffix)].strip()
            return stripped or "未命名需求"
    return raw


def _build_detailed_function_design(doc: DesignDoc, sequence_md: str) -> str:
    if not doc.impacts:
        return "\n\n".join(
            [
                "## 3.1 模块概述",
                "当前未识别影响模块，需在需求评审后补充模块边界。",
                "## 3.2 交互逻辑",
                sequence_md or "- 无",
            ]
        )

    sections: list[str] = []
    for idx, impact in enumerate(doc.impacts, start=1):
        feature_rows: list[list[str]] = []
        for jdx, change in enumerate(impact.changes or [], start=1):
            feature_rows.append(
                [
                    f"FP-{idx:02d}-{jdx:02d}",
                    change,
                    "关键输入参数与字段校验规则详见接口文档。",
                    "返回结构与错误码口径详见接口文档。",
                    "异常分支处理见第六章。",
                ]
            )
        if not feature_rows:
            feature_rows = [
                [
                    f"FP-{idx:02d}-01",
                    "待补充具体功能点（建议在需求评审会确认）。",
                    "待补充",
                    "待补充",
                    "需补充异常处理与回滚策略。",
                ]
            ]

        feature_table = to_markdown_table(
            ["功能点ID", "功能描述", "输入项", "输出项", "补充说明"],
            feature_rows,
        )
        sections.append(
            "\n\n".join(
                [
                    f"## 3.{idx} 模块：{impact.system or f'module-{idx}'}",
                    f"模块概述：{impact.reason or '待补充模块背景。'}",
                    f"### 3.{idx}.1 功能点设计",
                    feature_table,
                ]
            )
        )

    sections.append("## 3.99 模块交互逻辑")
    sections.append(sequence_md or "- 无")
    return "\n\n".join(sections)


def _extract_table_system_pairs(doc: DesignDoc, limit: int = 30) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()

    for note in doc.data_model_notes:
        text = str(note).strip()
        if not text:
            continue
        match = re.search(r"`([^`]+)`\s*涉及表（示例）：\s*(.+)$", text)
        if not match:
            continue
        system = match.group(1).strip() or "-"
        tables = [item.strip() for item in re.split(r"[，,]", match.group(2)) if item.strip()]
        for table in tables:
            pair = (system, table)
            if pair in seen:
                continue
            seen.add(pair)
            pairs.append(pair)
            if len(pairs) >= limit:
                return pairs

    if pairs:
        return pairs

    for impact in doc.impacts:
        system = (impact.system or "system").strip()
        table = f"{system.replace('-', '_')}_main"
        pair = (system, table)
        if pair in seen:
            continue
        seen.add(pair)
        pairs.append(pair)
        if len(pairs) >= limit:
            break
    return pairs


def _build_database_overview_rows(doc: DesignDoc) -> list[list[str]]:
    pairs = _extract_table_system_pairs(doc, limit=30)
    rows: list[list[str]] = []
    for system, table in pairs:
        rows.append(
            [
                system,
                table,
                "id, biz_key, status, updated_at",
                "主键：id；索引建议：biz_key/status",
                "主键查询 + 条件检索 + 状态过滤",
                "字段类型与索引策略需结合真实 DDL 二次确认。",
            ]
        )
    if not rows:
        rows = [["-", "-", "-", "-", "-", "待补充数据库对象。"]]
    return rows


def _to_er_entity_name(raw: str) -> str:
    text = re.sub(r"[^0-9a-zA-Z_]", "_", raw or "").strip("_")
    if not text:
        text = "ENTITY"
    if text[0].isdigit():
        text = f"T_{text}"
    return text.upper()


def _build_er_diagram(doc: DesignDoc) -> str:
    pairs = _extract_table_system_pairs(doc, limit=12)
    if not pairs:
        return "erDiagram\n  MAIN_ENTITY {\n    string id PK\n  }"

    lines: list[str] = ["erDiagram"]
    system_primary: dict[str, str] = {}
    system_tables: dict[str, list[str]] = {}

    for system, table in pairs:
        entity = _to_er_entity_name(table)
        lines.extend(
            [
                f"  {entity} {{",
                "    string id PK",
                "    string biz_key",
                "    int status",
                "    datetime updated_at",
                "  }",
            ]
        )
        system_tables.setdefault(system, []).append(entity)
        if system not in system_primary:
            system_primary[system] = entity

    relation_lines: list[str] = []
    relation_seen: set[str] = set()

    for entities in system_tables.values():
        if len(entities) <= 1:
            continue
        primary = entities[0]
        for sub in entities[1:]:
            edge = f"  {primary} ||--o{{ {sub} : contains"
            if edge in relation_seen:
                continue
            relation_seen.add(edge)
            relation_lines.append(edge)

    systems_in_order = [impact.system for impact in doc.impacts if impact.system in system_primary]
    if not systems_in_order:
        systems_in_order = list(system_primary.keys())
    for idx in range(len(systems_in_order) - 1):
        left = system_primary[systems_in_order[idx]]
        right = system_primary[systems_in_order[idx + 1]]
        edge = f"  {left} ||--o{{ {right} : depends_on"
        if edge in relation_seen:
            continue
        relation_seen.add(edge)
        relation_lines.append(edge)

    lines.extend(relation_lines)
    return "\n".join(lines)


def _build_data_entity_rows(doc: DesignDoc) -> list[list[str]]:
    rows: list[list[str]] = []
    for system, table in _extract_table_system_pairs(doc, limit=10):
        entity_name = f"{table}（{system}）"
        rows.extend(
            [
                [entity_name, "id", "String", "64", "是", "自动生成", "主键ID"],
                [entity_name, "biz_key", "String", "64", "是", "-", "业务唯一键，建议建立唯一索引"],
                [entity_name, "status", "Integer", "1", "是", "1", "状态字段（启用/禁用）"],
                [entity_name, "updated_at", "Datetime", "19", "是", "CURRENT_TIMESTAMP", "更新时间，用于增量同步"],
            ]
        )

    if rows:
        return rows[:40]

    if doc.impacts:
        fallback_rows: list[list[str]] = []
        for impact in doc.impacts[:5]:
            entity_name = f"{impact.system}_entity"
            fallback_rows.extend(
                [
                    [entity_name, "id", "String", "64", "是", "自动生成", "主键ID"],
                    [entity_name, "requestId", "String", "64", "是", "-", "请求唯一标识，用于链路追踪"],
                ]
            )
        return fallback_rows

    return [["common_entity", "id", "String", "64", "是", "自动生成", "主键ID"]]


def _build_data_relations(doc: DesignDoc) -> list[str]:
    relations: list[str] = []
    systems = [item.system for item in doc.impacts if item.system]
    for idx in range(len(systems) - 1):
        relations.append(
            f"{systems[idx]} 与 {systems[idx + 1]}：通过业务接口形成上下游调用关系，需保证口径一致与幂等处理。"
        )
    table_pairs = _extract_table_system_pairs(doc, limit=12)
    if len(table_pairs) >= 2:
        for idx in range(len(table_pairs) - 1):
            left_system, left_table = table_pairs[idx]
            right_system, right_table = table_pairs[idx + 1]
            relations.append(
                f"{left_table}（{left_system}） -> {right_table}（{right_system}）：建议以 `biz_key/request_id` 建立可追踪关联。"
            )
    if any("共享表提示" in item for item in doc.data_model_notes):
        relations.append("存在跨仓共享表场景，需在详细设计中明确归属域与写入责任边界。")
    if not relations:
        relations.append("当前未识别显式实体关联，建议在详细设计阶段补充 ER 关系。")
    return relations


def _build_data_storage_rules(doc: DesignDoc) -> list[str]:
    rules = [
        "核心业务数据采用关系型数据库存储，结构变更遵循向后兼容策略（先加后切）。",
        "数据访问遵循最小权限原则，接口返回需脱敏敏感字段并保留审计日志。",
        "关键数据需配置备份与恢复策略，保障故障场景下的数据可回溯性。",
    ]
    if any("兼容" in item for item in doc.constraints):
        rules.append("兼容性约束下，新增字段应提供默认值并保持历史读写链路可用。")
    if any("性能" in item for item in doc.constraints):
        rules.append("性能敏感场景应建立热点索引与分级缓存策略，避免慢查询放大。")
    return rules


def _build_interface_rows(doc: DesignDoc) -> list[list[str]]:
    rows: list[list[str]] = []
    for impact in doc.impacts:
        rows.append(
            [
                f"{impact.system}.execute",
                "POST",
                "requestId、bizKey、bizPayload",
                "code、message、data",
                _short_text(impact.reason or "需求相关接口能力。", 52),
            ]
        )
    if rows:
        return rows[:20]
    return [["system.execute", "POST", "requestId、bizPayload", "code、message、data", "通用能力接口，待细化。"]]


def _build_exception_rows(doc: DesignDoc) -> list[list[str]]:
    rows: list[list[str]] = []
    for risk in doc.risks:
        text = str(risk).strip()
        if not text:
            continue
        lower = text.lower()
        if any(key in lower for key in ["超时", "失败", "异常", "timeout", "error"]):
            category = "系统异常"
            handle = "提示系统繁忙并按策略重试，重试失败触发告警。"
            logs = "记录异常时间、错误堆栈、链路ID、调用参数摘要。"
        elif any(key in lower for key in ["权限", "安全", "泄露", "攻击", "非法"]):
            category = "安全异常"
            handle = "拦截请求并触发安全校验，必要时冻结高风险操作。"
            logs = "记录异常IP、用户标识、异常动作、策略命中详情。"
        elif any(key in lower for key in ["参数", "格式", "输入"]):
            category = "输入异常"
            handle = "实时提示输入错误并阻断提交。"
            logs = "记录校验失败次数与字段维度统计。"
        else:
            category = "业务异常"
            handle = "返回明确业务错误码并提示可执行的处理建议。"
            logs = "记录业务上下文、关键参数与异常原因。"
        rows.append([category, text, handle, logs])

    if rows:
        return rows[:20]
    return [["系统异常", "未识别明确异常项。", "提示系统繁忙并触发告警。", "记录时间、堆栈、链路ID。"]]


def _build_constraints_limits(doc: DesignDoc) -> list[str]:
    items: list[str] = []
    for constraint in doc.constraints:
        items.append(f"约束：{constraint}")
    for assumption in doc.assumptions[:4]:
        items.append(f"前提：{assumption}")
    items.extend(
        [
            "性能约束：核心链路需满足响应时延与成功率目标，压测口径需与验收口径一致。",
            "资源约束：需在既有资源配额下完成本期能力建设，扩容需求需提前评估。",
            "合规约束：涉及权限、审计、隐私处理的链路需满足组织规范与监管要求。",
        ]
    )
    return items


def render_requirement_analysis_markdown(
    requirement: RequirementInput,
    impacts: list[ImpactItem],
    context: ContextSnapshot,
    template_path: Path | None = None,
    requirement_breakdown: list[dict[str, str]] | None = None,
    public_knowledge: dict[str, Any] | None = None,
) -> str:
    requirement_breakdown = requirement_breakdown or []
    public_knowledge = public_knowledge or {}

    priority_lookup = _build_priority_lookup(requirement_breakdown)
    requirement_breakdown_rows = [
        [
            str(idx),
            str(item.get("type", "")),
            str(item.get("priority", "")),
            str(item.get("item", "")),
            str(item.get("reason", "")),
        ]
        for idx, item in enumerate(requirement_breakdown, start=1)
    ]
    if not requirement_breakdown_rows:
        requirement_breakdown_rows = [["1", "-", "-", "-", "-"]]
    breakdown_table = to_markdown_table(
        ["#", "类型", "优先级", "拆解项", "分析依据"],
        requirement_breakdown_rows,
    )

    overview_table = to_markdown_table(
        ["项目", "值"],
        [
            ["需求标题", requirement.title or "-"],
            ["目标数量", str(len(requirement.goals))],
            ["范围内条目数量", str(len(requirement.scope_in))],
            ["范围外条目数量", str(len(requirement.scope_out))],
            ["约束数量", str(len(requirement.constraints))],
            ["验收标准数量", str(len(requirement.acceptance_criteria))],
            ["识别影响系统数量", str(len(impacts))],
        ],
    )

    goal_rows: list[list[str]] = []
    for goal in requirement.goals:
        goal_priority = priority_lookup.get(goal) or priority_lookup.get(_normalize_text(goal), "P0")
        goal_rows.append(
            [
                goal,
                goal_priority,
                _interpret_goal(goal),
                _goal_success_signal(goal),
            ]
        )
    if not goal_rows:
        goal_rows = [["-", "-", "-", "-"]]
    goal_table = to_markdown_table(
        ["目标条目", "优先级", "需求解读", "建议成功信号"],
        goal_rows,
    )

    scope_rows: list[list[str]] = []
    for item in requirement.scope_in:
        scope_rows.append([item, "In Scope", _scope_implication(item, is_out=False)])
    for item in requirement.scope_out:
        scope_rows.append([item, "Out Scope", _scope_implication(item, is_out=True)])
    if not scope_rows:
        scope_rows = [["-", "-", "-"]]
    scope_table = to_markdown_table(
        ["范围条目", "类型", "边界解读"],
        scope_rows,
    )

    constraint_rows: list[list[str]] = []
    for item in requirement.constraints:
        constraint_rows.append(
            [
                item,
                _constraint_risk(item),
                _constraint_recommendation(item),
            ]
        )
    if not constraint_rows:
        constraint_rows = [["-", "-", "-"]]
    constraint_table = to_markdown_table(
        ["约束条目", "潜在风险", "需求侧补充建议"],
        constraint_rows,
    )

    acceptance_rows: list[list[str]] = []
    for item in requirement.acceptance_criteria:
        acceptance_rows.append(
            [
                item,
                _acceptance_check(item),
                _acceptance_method(item),
            ]
        )
    if not acceptance_rows:
        acceptance_rows = [["-", "-", "-"]]
    acceptance_table = to_markdown_table(
        ["验收条目", "可验证检查点", "建议验证方式"],
        acceptance_rows,
    )

    impact_rows: list[list[str]] = []
    for impact in impacts:
        impact_rows.append(
            [
                impact.system,
                impact.reason,
                "<br>".join(impact.changes) if impact.changes else "-",
            ]
        )
    if not impact_rows:
        impact_rows = [["-", "-", "-"]]
    impact_table = to_markdown_table(
        ["影响系统", "影响原因", "需求相关改动关注点"],
        impact_rows,
    )

    repo_map = {repo.name: repo for repo in context.repos}
    impact_context_rows: list[list[str]] = []
    for impact in impacts:
        repo = repo_map.get(impact.system)
        if not repo:
            impact_context_rows.append([impact.system, "-", "-", "-", "-"])
            continue
        impact_context_rows.append(
            [
                impact.system,
                _join_sample(repo.modules, 5),
                _join_sample(repo.datasources, 5),
                _join_sample(repo.dubbo_references, 5),
                str(len(repo.tables)),
            ]
        )
    if not impact_context_rows:
        impact_context_rows = [["-", "-", "-", "-", "-"]]
    impact_context_table = to_markdown_table(
        ["系统", "模块样例", "数据源", "依赖接口样例", "表数量"],
        impact_context_rows,
    )

    public_kb_summary_rows = [
        ["source", str(public_knowledge.get("source", ""))],
        ["namespace", str(public_knowledge.get("namespace", ""))],
        ["domain_systems", str(len(public_knowledge.get("domain_systems", [])))],
        ["requirement_patterns", str(len(public_knowledge.get("requirement_patterns", [])))],
        ["recent_cases", str(len(public_knowledge.get("recent_cases", [])))],
        ["retrieval_hits", str(len(public_knowledge.get("retrieval_hits", [])))],
        ["retrieval_avg_score", str((public_knowledge.get("retrieval_metrics", {}) or {}).get("avg_score", ""))],
    ]
    public_kb_summary_table = to_markdown_table(["知识项", "值"], public_kb_summary_rows)

    requirement_pattern_rows: list[list[str]] = []
    for idx, pattern in enumerate(public_knowledge.get("requirement_patterns", []), start=1):
        text = str(pattern).strip()
        if not text:
            continue
        requirement_pattern_rows.append([str(idx), text, "可作为需求补充检查清单"])
    if not requirement_pattern_rows:
        requirement_pattern_rows = [["1", "-", "-"]]
    requirement_pattern_table = to_markdown_table(
        ["#", "知识库需求模式", "对当前需求的补充价值"],
        requirement_pattern_rows,
    )

    recent_case_rows: list[list[str]] = []
    for idx, item in enumerate(public_knowledge.get("recent_cases", []), start=1):
        if not isinstance(item, dict):
            continue
        case_id = str(item.get("id", "")).strip() or f"case-{idx}"
        title = str(item.get("title", item.get("name", "-"))).strip() or "-"
        summary = _short_text(
            str(item.get("summary", item.get("desc", item.get("context", "-")))),
            limit=80,
        )
        recent_case_rows.append([case_id, title, summary, _case_relevance(title, summary)])
    if not recent_case_rows:
        recent_case_rows = [["-", "-", "-", "-"]]
    recent_case_table = to_markdown_table(
        ["案例ID", "案例标题", "案例摘要", "关联解读"],
        recent_case_rows,
    )

    hit_rows: list[list[str]] = []
    for idx, item in enumerate(public_knowledge.get("retrieval_hits", [])[:10], start=1):
        if not isinstance(item, dict):
            continue
        hit_rows.append(
            [
                str(idx),
                str(item.get("id", "")),
                str(item.get("title", "")),
                str(item.get("type", "")),
                str(item.get("score", "")),
                _hit_relevance(str(item.get("type", ""))),
            ]
        )
    if not hit_rows:
        hit_rows = [["1", "-", "-", "-", "-", "-"]]
    hit_table = to_markdown_table(
        ["#", "文档ID", "标题", "类型", "得分", "关联解读"],
        hit_rows,
    )

    kb_supplement_suggestions = _build_requirement_kb_suggestions(
        requirement=requirement,
        impacts=impacts,
        requirement_breakdown=requirement_breakdown,
        public_knowledge=public_knowledge,
    )

    report_scope_md = to_markdown_list(
        [
            f"包含范围：{', '.join(requirement.scope_in) if requirement.scope_in else '待补充'}",
            f"不包含范围：{', '.join(requirement.scope_out) if requirement.scope_out else '未在原文明确'}",
            f"影响系统：{', '.join(item.system for item in impacts) if impacts else '待识别'}",
        ]
    )
    document_version_table_md = to_markdown_table(
        ["版本号", "编制人", "编制日期", "审核人", "审核日期", "批准人", "批准日期"],
        [["v1.0", "AI Agent", "自动生成", "待指定", "待指定", "待指定", "待指定"]],
    )

    requirement_source_rows: list[list[str]] = [
        [
            "需求文档原文",
            "输入需求文档正文（原文）",
            "P0",
            f"作为背景、目标、范围、约束、验收标准分析的主依据（标题：{requirement.title or '-'}）。",
        ],
        [
            "系统上下文扫描",
            "代码仓上下文与影响系统识别",
            "P1",
            f"识别需求相关影响系统 {len(impacts)} 个，并补充模块/数据源/接口上下文。",
        ],
    ]
    retrieval_hits = public_knowledge.get("retrieval_hits", [])
    if isinstance(retrieval_hits, list) and retrieval_hits:
        requirement_source_rows.append(
            [
                "知识库语义检索",
                "公共知识库语义检索命中",
                "P1",
                f"命中 {len(retrieval_hits)} 条，补充需求模式、历史案例和相关文档参考。",
            ]
        )
    requirement_sources_md = to_markdown_table(
        ["需求来源", "来源说明", "优先级", "对本次分析的贡献"],
        requirement_source_rows,
    )

    user_rows: list[list[str]] = []
    for idx, item in enumerate(requirement.scope_in[:5], start=1):
        user_rows.append(
            [
                f"用户群体{idx}",
                f"围绕“{_short_text(item, 28)}”的业务角色",
                "高" if idx <= 2 else "中",
                "角色定义与权限边界需在需求评审中明确。",
            ]
        )
    if not user_rows:
        user_rows = [["业务用户", "需求文档未明确用户分层，需补充角色画像", "高", "建议在评审会补齐用户分类与诉求。"]]
    user_analysis_md = to_markdown_table(
        ["用户群体分类", "核心诉求", "优先级", "补充说明"],
        user_rows,
    )

    functional_rows: list[list[str]] = []
    for idx, item in enumerate(requirement.scope_in, start=1):
        priority = priority_lookup.get(item) or priority_lookup.get(_normalize_text(item), "P1")
        acceptance = (
            requirement.acceptance_criteria[idx - 1]
            if idx - 1 < len(requirement.acceptance_criteria)
            else (requirement.acceptance_criteria[0] if requirement.acceptance_criteria else "待补充")
        )
        functional_rows.append([f"FR-{idx:03d}", item, priority, acceptance])
    if not functional_rows:
        functional_rows = [["FR-001", "待补充功能需求", "P1", "待补充验收标准"]]
    functional_requirements_table_md = to_markdown_table(
        ["需求ID", "功能需求描述", "优先级", "关联验收标准"],
        functional_rows,
    )

    non_functional_items: list[str] = []
    for item in requirement.constraints:
        non_functional_items.append(f"约束要求：{item}")
    if any(_contains_any(goal.lower(), ["稳定", "可用", "容灾", "故障"]) for goal in requirement.goals):
        non_functional_items.append("稳定性要求：需补充异常场景、故障恢复与可用性目标阈值。")
    if any(_contains_any(goal.lower(), ["性能", "时效", "延迟", "吞吐", "qps", "tps"]) for goal in requirement.goals):
        non_functional_items.append("性能要求：需补充响应时间、吞吐量与并发指标口径。")
    if any(_contains_any(goal.lower(), ["安全", "审计", "合规", "权限"]) for goal in requirement.goals):
        non_functional_items.append("安全与合规要求：需补充权限控制、审计留痕与数据保护要求。")
    if not non_functional_items:
        non_functional_items.append("当前需求文档未明确非功能需求，建议补充性能、安全、可用性、兼容性约束。")
    non_functional_requirements_md = to_markdown_list(non_functional_items)

    priority_rows: list[list[str]] = []
    cycle_map = {"P0": "第一迭代", "P1": "第一/第二迭代", "P2": "后续迭代", "P3": "按资源评估"}
    for idx, item in enumerate(requirement_breakdown, start=1):
        if not isinstance(item, dict):
            continue
        priority = str(item.get("priority", "P1")).upper()
        priority_rows.append(
            [
                f"REQ-{idx:03d}",
                str(item.get("item", "-")),
                str(item.get("type", "-")),
                priority,
                cycle_map.get(priority, "待评估"),
                str(item.get("reason", "-")),
            ]
        )
    if not priority_rows:
        priority_rows = [["REQ-001", "-", "-", "P1", "第一/第二迭代", "-"]]
    priority_table_md = to_markdown_table(
        ["需求ID", "需求名称", "需求类型", "优先级", "实现周期", "备注"],
        priority_rows,
    )

    assumptions = [
        "假设当前需求文档版本可作为本轮评审基线，重大变更需走变更评审流程。",
        "假设影响系统清单与上下游责任边界以需求评审会议结论为准。",
        "假设知识库命中结果可作为补充依据，关键条目仍需人工确认业务适配性。",
    ]
    assumptions_md = to_markdown_list(assumptions)

    pending_items: list[str] = []
    if not requirement.scope_out:
        pending_items.append("范围外条目未明确，需补充不做项以避免范围蔓延。")
    if not requirement.constraints:
        pending_items.append("约束条件不足，需补充时间、资源、技术或合规边界。")
    if not requirement.acceptance_criteria:
        pending_items.append("验收标准缺失，需补充可验证检查点与判定阈值。")
    avg_score = _safe_float((public_knowledge.get("retrieval_metrics", {}) or {}).get("avg_score"))
    if retrieval_hits and avg_score < 0.2:
        pending_items.append(f"知识库命中平均相关度较低（avg_score={avg_score:.4f}），建议补充关键词后复核。")
    if not pending_items:
        pending_items.append("当前未识别明显分歧项，建议在需求评审会再次确认边界与优先级。")

    confirmation_and_disputes_md = "\n\n".join(
        [
            "已确认内容：",
            to_markdown_list(
                [
                    f"已识别目标 {len(requirement.goals)} 项、范围内条目 {len(requirement.scope_in)} 项、约束 {len(requirement.constraints)} 项、验收标准 {len(requirement.acceptance_criteria)} 项。",
                    f"已识别影响系统 {len(impacts)} 个，并补充相关上下文信息。",
                    f"已纳入知识库补充信息（需求模式 {len(public_knowledge.get('requirement_patterns', []))} 条、历史案例 {len(public_knowledge.get('recent_cases', []))} 条）。",
                ]
            ),
            "待确认/潜在分歧：",
            to_markdown_list(pending_items),
        ]
    )

    risk_rows: list[list[str]] = []
    if not requirement.acceptance_criteria:
        risk_rows.append(
            ["验收风险", "缺少验收标准会导致交付判断口径不一致。", "高", "补充可验证验收条目并明确通过阈值。"]
        )
    if not requirement.scope_out:
        risk_rows.append(
            ["范围风险", "范围外边界不清晰，可能引发需求蔓延。", "中", "补充范围外条目并在评审中冻结边界。"]
        )
    if retrieval_hits and avg_score < 0.2:
        risk_rows.append(
            [
                "知识补充风险",
                f"知识库平均相关度偏低（{avg_score:.4f}），可能造成补充信息偏差。",
                "中",
                "补充业务关键词并复核 Top 命中文档后更新分析结论。",
            ]
        )
    if len(impacts) >= 8:
        risk_rows.append(
            ["协同风险", f"影响系统数量较多（{len(impacts)} 个），上下游责任界面易产生偏差。", "中", "组织跨系统需求评审，明确接口边界和责任人。"]
        )
    if not risk_rows:
        risk_rows = [["综合风险", "当前需求分析未识别高风险项。", "低", "在需求评审会上持续跟踪边界与验收项变化。"]]
    risk_table_md = to_markdown_table(
        ["风险类型", "风险描述", "风险等级（高/中/低）", "应对措施"],
        risk_rows,
    )

    follow_up_plan_md = to_markdown_list(
        [
            "需求评审：组织业务/产品/技术评审会，确认目标、范围、约束、验收标准。",
            "需求澄清：输出待确认问题清单并闭环，更新需求分析报告基线版本。",
            "优先级冻结：基于 P0/P1/P2 清单确认迭代边界，冻结本期需求范围。",
            "变更管理：需求冻结后新增事项统一进入变更流程并评估影响。",
        ]
    )

    attachments_md = to_markdown_list(
        [
            "附件1：需求文档原文（本次分析输入）。",
            f"附件2：需求影响系统清单（共 {len(impacts)} 个）。",
            f"附件3：知识库语义检索命中清单（共 {len(retrieval_hits)} 条）。",
            f"附件4：需求拆解与优先级明细（共 {len(requirement_breakdown)} 条）。",
        ]
    )
    signoff_table_md = to_markdown_table(
        ["编制人签字", "日期", "审核人签字", "日期"],
        [["待签字", "待填写", "待签字", "待填写"]],
    ) + "\n\n" + to_markdown_table(
        ["批准人签字", "日期", "业务代表签字", "日期"],
        [["待签字", "待填写", "待签字", "待填写"]],
    )

    template_mapping = {
        "requirement_title": requirement.title or "未命名需求",
        "report_purpose": (
            f"对《{requirement.title or '当前需求'}》进行结构化解读，明确背景、目标、范围、约束、验收标准，"
            "并结合知识库补充分析形成可评审的需求基线。"
        ),
        "project_background": requirement.background or "需求文档未提供明确背景信息，需在评审阶段补充。",
        "report_scope_md": report_scope_md,
        "document_version_table_md": document_version_table_md,
        "requirement_sources_md": requirement_sources_md,
        "user_analysis_md": user_analysis_md,
        "knowledge_summary_table_md": public_kb_summary_table,
        "requirement_pattern_table_md": requirement_pattern_table,
        "recent_case_table_md": recent_case_table,
        "hit_table_md": hit_table,
        "kb_supplement_suggestions_md": to_markdown_list(kb_supplement_suggestions),
        "business_requirements_md": goal_table,
        "functional_requirements_table_md": functional_requirements_table_md,
        "non_functional_requirements_md": non_functional_requirements_md,
        "priority_table_md": priority_table_md,
        "constraint_table_md": constraint_table,
        "assumptions_md": assumptions_md,
        "confirmation_and_disputes_md": confirmation_and_disputes_md,
        "risk_table_md": risk_table_md,
        "follow_up_plan_md": follow_up_plan_md,
        "attachments_md": attachments_md,
        "signoff_table_md": signoff_table_md,
    }
    if template_path and template_path.exists():
        return _render_template(template_path, template_mapping)

    # 若模板不可用，回退到简化结构，保障主流程可用。
    sections = [
        f"# {requirement.title or '未命名需求'} - 需求分析报告",
        "## 报告概述",
        overview_table,
        "## 核心需求解读",
        goal_table,
        scope_table,
        constraint_table,
        acceptance_table,
        "## 需求拆解与优先级",
        breakdown_table,
        "## 影响范围分析",
        impact_table,
        impact_context_table,
        "## 知识库补充分析",
        public_kb_summary_table,
        requirement_pattern_table,
        recent_case_table,
        hit_table,
        to_markdown_list(kb_supplement_suggestions),
    ]
    return "\n\n".join(section for section in sections if section.strip())


def render_quality_assessment_markdown(
    requirement: RequirementInput,
    quality_report: dict[str, Any] | None = None,
    quality_gate: dict[str, Any] | None = None,
    validation: dict[str, Any] | None = None,
    public_knowledge: dict[str, Any] | None = None,
) -> str:
    """渲染独立质量评估文档（量化指标 + 门禁结论）。

    设计目标：
    - 把第三阶段质量评估与第四阶段质量门禁从分析报告中独立成专门产物；
    - 输出可追踪的量化指标，便于 CI/CD 留痕与复盘；
    - 保持与现有字段兼容，不引入额外工作流依赖。
    """
    quality_report = quality_report or {}
    quality_gate = quality_gate or {}
    quantitative_rows_payload = quality_report.get("quantitative_metrics", []) if isinstance(quality_report, dict) else []
    quantitative_summary = quality_report.get("quantitative_summary", {}) if isinstance(quality_report, dict) else {}

    score_rows: list[list[str]] = []
    detail_rows: list[list[str]] = []
    for item in quantitative_rows_payload:
        if not isinstance(item, dict):
            continue
        dimension = str(item.get("dimension", ""))
        metric_name = str(item.get("metric_name", ""))
        value_display = str(item.get("value_display", ""))
        metric_score = str(item.get("score", "0"))
        explanation = str(item.get("explanation", ""))
        formula = str(item.get("formula", ""))
        normal_range = str(item.get("normal_range", ""))

        score_rows.append([dimension, metric_name, value_display, metric_score])
        detail_rows.append([metric_name, explanation, formula, normal_range])

    if not score_rows:
        score_rows.append(["-", "-", "-", "0"])
    if not detail_rows:
        detail_rows.append(["-", "-", "-", "-"])

    score_table = to_markdown_table(["维度", "指标名称", "值", "得分"], score_rows)
    detail_table = to_markdown_table(["指标名称", "指标解释", "计算方法", "衡量标准"], detail_rows)

    total_metrics = quantitative_summary.get("total_metrics", len(score_rows))
    pass_count = quantitative_summary.get("pass_count", 0)
    fail_count = quantitative_summary.get("fail_count", 0)
    pass_ratio = quantitative_summary.get("pass_ratio", "0.00%")
    avg_score = quantitative_summary.get("avg_score", "0.00")
    grade = quantitative_summary.get("grade", "D")
    gate_decision = str(quality_gate.get("decision", "UNKNOWN"))
    gate_score = str(quality_gate.get("score", "0"))
    policy_source = str(quality_gate.get("policy_source", ""))

    risk_items = quality_gate.get("blocking_issues", []) or quality_gate.get("warning_issues", [])
    if not risk_items:
        risk_items = quality_report.get("risk_signals", [])
    top_risk = "；".join(str(item) for item in risk_items[:3]) if risk_items else "未识别显著风险项。"

    conclusion_lines = [
        f"本次共评估 {total_metrics} 个指标，达标 {pass_count} 个，未达标 {fail_count} 个，达标率 {pass_ratio}。",
        f"指标平均分 {avg_score}（等级 {grade}），质量门禁为 {gate_decision}（门禁分 {gate_score}）。",
        f"主要关注点：{top_risk}",
        f"门禁策略来源：{policy_source}",
    ]

    sections = [
        f"# {requirement.title} - 质量评估报告",
        "## 1. 指标评分总表",
        score_table,
        "## 2. 指标解释与计算口径",
        detail_table,
        "## 3. 结论",
        to_markdown_list(conclusion_lines),
    ]
    return "\n\n".join(section for section in sections if section.strip())


def render_api_markdown(doc: ApiDoc, template_path: Path) -> str:
    index_rows = []
    for idx, endpoint in enumerate(doc.endpoints, start=1):
        index_rows.append(
            [
                str(idx),
                endpoint.name,
                endpoint.owner_system,
                endpoint.protocol,
                endpoint.interface,
            ]
        )
    if not index_rows:
        index_rows = [["1", "-", "-", "-", "-"]]
    endpoint_index_md = to_markdown_table(["#", "接口名称", "归属系统", "协议", "接口"], index_rows)

    details: list[str] = []
    for idx, endpoint in enumerate(doc.endpoints, start=1):
        details.append(_render_endpoint_detail(idx, endpoint))

    common_error_rows = [[item.get("code", ""), item.get("desc", "")] for item in doc.common_errors]
    if not common_error_rows:
        common_error_rows = [["-", "-"]]
    common_errors_md = to_markdown_table(["错误码", "说明"], common_error_rows)

    mapping = {
        "title": doc.title,
        "overview": doc.overview,
        "endpoint_index_md": endpoint_index_md,
        "endpoint_details_md": "\n\n".join(details),
        "common_errors_md": common_errors_md,
        "common_policy_md": to_markdown_list(doc.common_policy),
    }
    return _render_template(template_path, mapping)


def _render_endpoint_detail(idx: int, endpoint: ApiEndpoint) -> str:
    base_info = to_markdown_table(
        ["字段", "值"],
        [
            ["接口名称", endpoint.name or "-"],
            ["归属系统", endpoint.owner_system or "-"],
            ["协议", endpoint.protocol or "-"],
            ["接口", endpoint.interface or "-"],
            ["场景", endpoint.scenario or "-"],
            ["调用方", ", ".join(endpoint.consumers) if endpoint.consumers else "-"],
            ["超时(ms)", str(endpoint.timeout_ms)],
            ["幂等策略", endpoint.idempotency or "-"],
            ["重试策略", endpoint.retry_policy or "-"],
            ["备注", endpoint.notes or "-"],
        ],
    )

    request_rows = [
        [
            field.get("name", ""),
            field.get("type", ""),
            field.get("required", ""),
            json.dumps(_example_value(field.get("type", "")), ensure_ascii=False),
            field.get("desc", ""),
        ]
        for field in endpoint.request_fields
    ]
    response_rows = [
        [
            field.get("name", ""),
            field.get("type", ""),
            json.dumps(_example_value(field.get("type", "")), ensure_ascii=False),
            field.get("desc", ""),
        ]
        for field in endpoint.response_fields
    ]
    error_rows = [[item.get("code", ""), item.get("desc", "")] for item in endpoint.error_codes]

    request_table = to_markdown_table(
        ["字段", "类型", "必填", "示例值", "说明"],
        _ensure_table_rows(request_rows, 5),
    )
    response_table = to_markdown_table(
        ["字段", "类型", "示例值", "说明"],
        _ensure_table_rows(response_rows, 4),
    )
    error_table = to_markdown_table(["错误码", "说明"], _ensure_table_rows(error_rows, 2))

    request_structure_table = to_markdown_table(
        ["字段路径", "类型", "必填", "示例值", "说明", "约束说明"],
        _build_structure_rows(endpoint.request_fields, include_required=True),
    )
    response_structure_table = to_markdown_table(
        ["字段路径", "类型", "示例值", "说明", "约束说明"],
        _build_structure_rows(endpoint.response_fields, include_required=False),
    )

    request_example_table = to_markdown_table(
        ["字段路径", "示例值", "说明"],
        _build_example_rows(endpoint.request_fields, include_required=True),
    )
    response_example_table = to_markdown_table(
        ["字段路径", "示例值", "说明"],
        _build_example_rows(endpoint.response_fields, include_required=False),
    )

    test_case_rows = _build_test_case_rows(endpoint)
    test_case_table = to_markdown_table(
        ["用例ID", "测试场景", "前置条件", "输入数据", "预期结果"],
        test_case_rows,
    )

    return (
        f"### {idx}. {endpoint.name}\n"
        f"{base_info}\n\n"
        "#### 请求字段\n\n"
        f"{request_table}\n\n"
        "#### 响应字段\n\n"
        f"{response_table}\n\n"
        "#### 错误码\n\n"
        f"{error_table}\n\n"
        "#### 请求数据结构（详细）\n\n"
        f"{request_structure_table}\n\n"
        "#### 请求示例（表格）\n\n"
        f"{request_example_table}\n\n"
        "#### 响应数据结构（详细）\n\n"
        f"{response_structure_table}\n\n"
        "#### 响应示例（表格）\n\n"
        f"{response_example_table}\n\n"
        "#### 测试用例（详细）\n\n"
        f"{test_case_table}"
    )


def _join_sample(items: list[str], limit: int) -> str:
    if not items:
        return "-"
    return ", ".join(items[:limit])


def _build_priority_lookup(requirement_breakdown: list[dict[str, str]]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for item in requirement_breakdown:
        if not isinstance(item, dict):
            continue
        raw_key = str(item.get("item", "")).strip()
        if not raw_key:
            continue
        priority = str(item.get("priority", "")).strip().upper() or "P1"
        lookup[raw_key] = priority
        lookup[_normalize_text(raw_key)] = priority
    return lookup


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", "", text or "").strip().lower()


def _contains_any(text: str, keywords: list[str]) -> bool:
    return any(keyword in text for keyword in keywords if keyword)


def _interpret_goal(goal: str) -> str:
    text = goal.strip()
    if not text:
        return "-"
    lower = text.lower()
    interpretations: list[str] = []
    if _contains_any(lower, ["一致", "对账", "准确", "精度", "差错", "错误"]):
        interpretations.append("该目标强调结果正确性，需求侧需明确口径、维度与判定阈值。")
    if _contains_any(lower, ["实时", "时效", "延迟", "吞吐", "性能", "qps", "tps"]):
        interpretations.append("该目标强调时效/性能表现，需在需求中定义基线与目标值。")
    if _contains_any(lower, ["自动", "自动化", "提效", "效率", "批量", "减少人工"]):
        interpretations.append("该目标强调流程效率提升，应明确前后动作变化与人机边界。")
    if _contains_any(lower, ["稳定", "可用", "容灾", "降级", "故障"]):
        interpretations.append("该目标关注稳定性，需求应补充异常场景与失败处理边界。")
    if _contains_any(lower, ["风控", "合规", "审计", "监管", "权限", "安全"]):
        interpretations.append("该目标包含合规/安全诉求，需要明确审计证据与责任边界。")
    if not interpretations:
        interpretations.append("该目标描述了业务预期产出，建议补充量化阈值、触发条件与边界。")
    return "；".join(interpretations)


def _goal_success_signal(goal: str) -> str:
    text = goal.strip()
    if not text:
        return "-"
    lower = text.lower()
    if _contains_any(lower, ["一致", "对账", "准确", "精度", "差错", "错误"]):
        return "关键口径差异率满足目标阈值，抽样核对与全量核对结果一致。"
    if _contains_any(lower, ["实时", "时效", "延迟", "吞吐", "性能", "qps", "tps"]):
        return "核心链路在目标流量下成功率达标，P95/P99 耗时满足需求阈值。"
    if _contains_any(lower, ["自动", "自动化", "提效", "效率", "批量", "减少人工"]):
        return "人工操作步骤显著减少，关键流程自动执行成功率达到目标值。"
    if _contains_any(lower, ["稳定", "可用", "容灾", "降级", "故障"]):
        return "故障演练与异常注入场景可闭环，恢复时长与可用性满足约束。"
    if _contains_any(lower, ["风控", "合规", "审计", "监管", "权限", "安全"]):
        return "关键审计日志完整可追溯，权限/合规校验覆盖核心业务路径。"
    return "建议将目标转化为“可量化指标 + 验证方式 + 判定阈值”的验收口径。"


def _scope_implication(item: str, is_out: bool) -> str:
    text = _short_text(item, limit=70)
    if is_out:
        return f"“{text}”被定义为范围外，本轮需求不承诺交付该能力，可用于控制评审与验收边界。"
    return f"“{text}”属于本轮范围，应在需求阶段明确输入、输出、依赖及责任归属。"


def _constraint_risk(constraint: str) -> str:
    text = (constraint or "").lower()
    if _contains_any(text, ["时间", "排期", "上线窗口", "工期", "deadline"]):
        return "排期压缩可能导致需求澄清不足，验收口径或边界定义不完整。"
    if _contains_any(text, ["兼容", "历史", "存量", "向前兼容", "回滚"]):
        return "兼容性约束下，历史行为与新需求冲突风险上升。"
    if _contains_any(text, ["性能", "并发", "延迟", "吞吐", "容量"]):
        return "性能约束若缺少基线，可能导致验收时标准不一致。"
    if _contains_any(text, ["合规", "审计", "监管", "安全", "隐私", "脱敏"]):
        return "合规约束未细化到条款时，存在审计不可追溯风险。"
    if _contains_any(text, ["成本", "预算", "资源", "人力"]):
        return "资源受限可能导致需求范围与优先级持续波动。"
    return "约束描述较抽象时，容易在需求评审阶段产生理解偏差。"


def _constraint_recommendation(constraint: str) -> str:
    text = (constraint or "").lower()
    if _contains_any(text, ["时间", "排期", "上线窗口", "工期", "deadline"]):
        return "补充里程碑节点、最晚冻结时间与需求变更窗口。"
    if _contains_any(text, ["兼容", "历史", "存量", "向前兼容", "回滚"]):
        return "补充兼容清单、灰度范围与回退触发条件。"
    if _contains_any(text, ["性能", "并发", "延迟", "吞吐", "容量"]):
        return "补充性能基线、目标阈值与测试数据口径。"
    if _contains_any(text, ["合规", "审计", "监管", "安全", "隐私", "脱敏"]):
        return "补充合规条款映射、审计留痕字段和责任人。"
    if _contains_any(text, ["成本", "预算", "资源", "人力"]):
        return "按优先级拆分需求并明确最小可交付范围。"
    return "将约束细化为可检核条款（触发条件、阈值、责任方）。"


def _acceptance_check(acceptance_item: str) -> str:
    text = acceptance_item.strip()
    if not text:
        return "-"
    lower = text.lower()
    if _contains_any(lower, ["接口", "api", "字段", "请求", "响应", "错误码"]):
        return "检查接口契约完整性（字段、必填项、错误码、幂等行为）是否满足条目描述。"
    if _contains_any(lower, ["性能", "延迟", "吞吐", "并发", "qps", "tps"]):
        return "检查关键性能指标是否达到条目要求，并记录测试口径。"
    if _contains_any(lower, ["数据", "一致", "对账", "准确", "报表"]):
        return "检查关键口径数据一致性，确保统计结果与业务事实一致。"
    if _contains_any(lower, ["告警", "日志", "审计", "追踪"]):
        return "检查监控告警与日志留痕是否可定位、可追溯、可审计。"
    return f"围绕“{_short_text(text, 36)}”定义输入条件、执行动作和可验证输出。"


def _acceptance_method(acceptance_item: str) -> str:
    text = acceptance_item.lower()
    if _contains_any(text, ["接口", "api", "字段", "请求", "响应", "错误码"]):
        return "接口契约检查 + 联调验证 + 异常场景回归。"
    if _contains_any(text, ["性能", "延迟", "吞吐", "并发", "qps", "tps"]):
        return "压测/稳态测试 + 峰值场景验证 + 指标看板留档。"
    if _contains_any(text, ["数据", "一致", "对账", "准确", "报表"]):
        return "全量或抽样数据核对 + 口径对齐评审 + 偏差复核。"
    if _contains_any(text, ["告警", "日志", "审计", "追踪"]):
        return "故障注入演练 + 日志链路追踪 + 审计记录抽查。"
    return "按照“前置条件-操作步骤-预期结果”执行结构化验收。"


def _short_text(text: str, limit: int = 80) -> str:
    normalized = re.sub(r"\s+", " ", text or "").strip()
    if not normalized:
        return "-"
    if len(normalized) <= limit:
        return normalized
    if limit <= 3:
        return normalized[:limit]
    return f"{normalized[: limit - 3]}..."


def _extract_keywords(text: str) -> set[str]:
    normalized = re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", " ", text or "").strip().lower()
    if not normalized:
        return set()
    tokens = [token for token in normalized.split() if len(token) >= 2]
    return set(tokens)


def _case_relevance(title: str, summary: str) -> str:
    keywords = _extract_keywords(f"{title} {summary}")
    if not keywords:
        return "案例信息较少，建议补充场景与结果后再用于对标。"
    if len(keywords) >= 8:
        return "案例信息较完整，可用于补充需求边界、约束口径与验收条件。"
    if len(keywords) >= 4:
        return "案例具备可参考信息，适合用于需求拆解与边界校验。"
    return "案例与当前需求可能有局部相关性，建议仅作为辅助参考。"


def _hit_relevance(type_text: str) -> str:
    kind = type_text.lower().strip()
    if not kind:
        return "命中类型未标注，建议人工核验其与需求的相关性。"
    if _contains_any(kind, ["requirement", "analysis", "acceptance"]):
        return "直接关联需求分析，可用于补充背景、范围与验收口径。"
    if _contains_any(kind, ["case", "history", "incident", "problem"]):
        return "可用于补充历史经验与风险场景，减少需求遗漏。"
    if _contains_any(kind, ["architecture", "design"]):
        return "偏设计侧知识，需抽取其中与需求边界直接相关的部分。"
    if _contains_any(kind, ["interface", "api", "contract"]):
        return "可用于补充需求的输入输出定义与调用边界描述。"
    if _contains_any(kind, ["rule", "policy", "standard", "spec"]):
        return "可用于校验需求是否满足既有规则与规范。"
    return "建议结合命中文档标题与得分人工确认其需求相关性。"


def _safe_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _append_unique(items: list[str], value: str) -> None:
    text = value.strip()
    if not text:
        return
    if text not in items:
        items.append(text)


def _build_requirement_kb_suggestions(
    requirement: RequirementInput,
    impacts: list[ImpactItem],
    requirement_breakdown: list[dict[str, str]],
    public_knowledge: dict[str, Any],
) -> list[str]:
    suggestions: list[str] = []

    if requirement.goals:
        if all(
            not _contains_any(goal.lower(), ["%", "ms", "秒", "分钟", "小时", "天", "次", "笔", "qps", "tps"])
            for goal in requirement.goals
        ):
            _append_unique(
                suggestions,
                "目标条目以描述性表达为主，建议补充可量化阈值（如时效、成功率、准确率）以提升可验收性。",
            )
    else:
        _append_unique(suggestions, "需求文档未提取到明确目标，建议先补齐“业务目标-成功判定”再进入评审。")

    if not requirement.scope_out:
        _append_unique(
            suggestions,
            "需求文档缺少范围外条目，建议补充“明确不做项”以避免评审和验收阶段范围漂移。",
        )

    if not requirement.constraints:
        _append_unique(suggestions, "需求文档缺少约束条目，建议补充时间、合规、兼容或资源边界。")
    if not requirement.acceptance_criteria:
        _append_unique(suggestions, "需求文档缺少验收标准，建议补充可验证检查点与验证方式。")

    if impacts:
        impacted_systems = ", ".join(item.system for item in impacts[:8] if item.system) or "-"
        _append_unique(
            suggestions,
            f"本次识别到 {len(impacts)} 个影响系统（{impacted_systems}），建议在需求评审中逐一确认系统责任边界与上下游输入输出。",
        )
    else:
        _append_unique(suggestions, "当前未识别到明确影响系统，建议结合范围条目补充系统边界。")

    requirement_patterns = public_knowledge.get("requirement_patterns", [])
    if isinstance(requirement_patterns, list) and requirement_patterns:
        _append_unique(
            suggestions,
            f"知识库命中需求模式 {len(requirement_patterns)} 条，建议将其转化为本需求的检查清单逐项核对。",
        )

    retrieval_hits = public_knowledge.get("retrieval_hits", [])
    if isinstance(retrieval_hits, list) and retrieval_hits:
        top_titles = []
        sorted_hits = sorted(
            [item for item in retrieval_hits if isinstance(item, dict)],
            key=lambda item: _safe_float(item.get("score")),
            reverse=True,
        )
        for hit in sorted_hits[:3]:
            title = str(hit.get("title") or hit.get("id") or "").strip()
            if title:
                top_titles.append(title)
        if top_titles:
            _append_unique(
                suggestions,
                f"语义检索高分条目建议优先复核：{', '.join(top_titles)}。",
            )
        metrics = public_knowledge.get("retrieval_metrics", {})
        avg_score = _safe_float((metrics or {}).get("avg_score"))
        if avg_score and avg_score < 0.2:
            _append_unique(
                suggestions,
                "当前语义检索平均相关度偏低，建议补充业务关键词后再次检索以提高知识补充质量。",
            )
    else:
        _append_unique(
            suggestions,
            "未命中语义检索条目，建议补充需求关键词（业务名词、系统名、关键口径）后重试检索。",
        )

    recent_cases = public_knowledge.get("recent_cases", [])
    if isinstance(recent_cases, list) and recent_cases:
        _append_unique(
            suggestions,
            f"知识库提供历史案例 {len(recent_cases)} 条，建议抽取其中与当前目标最相近的 1-2 条进行边界对比。",
        )

    knowledge_breakdown = [
        item
        for item in requirement_breakdown
        if isinstance(item, dict) and str(item.get("type", "")).strip().lower() == "knowledge"
    ]
    if knowledge_breakdown:
        _append_unique(
            suggestions,
            "需求拆解已纳入知识项，建议将关键知识依据写入评审结论，确保分析过程可追溯。",
        )

    if not suggestions:
        suggestions.append("知识库补充信息有限，建议在需求评审会中人工补充背景、边界与验收细节。")
    return suggestions


def _build_structure_rows(fields: list[dict[str, str]], include_required: bool) -> list[list[str]]:
    rows: list[list[str]] = []
    for field in fields:
        name = field.get("name", "")
        field_type = field.get("type", "")
        desc = field.get("desc", "")
        sample = _example_value(field_type)
        sample_json = json.dumps(sample, ensure_ascii=False)
        required = field.get("required", "")
        rule = "必填字段" if str(required).upper() == "Y" else "选填字段"
        if include_required:
            rows.append([name, field_type, required, sample_json, desc or "-", rule])
        else:
            rows.append([name, field_type, sample_json, desc or "-", rule])
    return _ensure_table_rows(rows, 6 if include_required else 5)


def _build_example_rows(fields: list[dict[str, str]], include_required: bool) -> list[list[str]]:
    rows: list[list[str]] = []
    for field in fields:
        name = str(field.get("name", "")).strip()
        if not name:
            continue
        field_type = str(field.get("type", "string"))
        value = json.dumps(_example_value(field_type), ensure_ascii=False)
        desc = str(field.get("desc", "")).strip() or "-"
        if include_required:
            required = str(field.get("required", "")).upper()
            required_text = "必填" if required == "Y" else "选填"
            rows.append([name, value, f"{desc}（{required_text}）"])
        else:
            rows.append([name, value, desc])
    return _ensure_table_rows(rows, 3)


def _ensure_table_rows(rows: list[list[str]], width: int) -> list[list[str]]:
    if rows:
        normalized: list[list[str]] = []
        for row in rows:
            row_values = [str(item) if str(item).strip() else "-" for item in row[:width]]
            if len(row_values) < width:
                row_values.extend(["-"] * (width - len(row_values)))
            normalized.append(row_values)
        return normalized
    return [["-"] * width]


def _build_test_case_rows(endpoint: ApiEndpoint) -> list[list[str]]:
    required_fields = [field.get("name", "") for field in endpoint.request_fields if field.get("required", "") == "Y"]
    first_required = required_fields[0] if required_fields else "requestId"
    error_codes = [item.get("code", "") for item in endpoint.error_codes if item.get("code", "")]
    non_success_error = next(
        (
            code
            for code in error_codes
            if code.lower() not in {"success", "ok", "passed", "pass"}
        ),
        "",
    )
    first_error = non_success_error or (error_codes[0] if error_codes else "SYSTEM_ERROR")

    rows: list[list[str]] = [
        [
            "TC-01",
            "正常路径",
            "服务可用，鉴权通过",
            "提供所有必填字段，业务参数合法",
            "返回成功码，响应字段完整，耗时在超时阈值内",
        ],
        [
            "TC-02",
            "必填参数缺失",
            "服务可用",
            f"缺失必填字段 `{first_required}`",
            "返回参数错误码，明确缺失字段，不触发下游副作用",
        ],
        [
            "TC-03",
            "参数类型异常",
            "服务可用",
            "金额/数值字段传入非法字符串或负值",
            "返回参数校验失败，不写入业务数据",
        ],
        [
            "TC-04",
            "幂等性验证",
            "首次请求已成功",
            "同一幂等键重复请求两次",
            "第二次返回与首次一致，不重复执行写操作",
        ],
        [
            "TC-05",
            "超时与重试",
            "人为注入下游超时",
            "发送标准请求并触发一次超时",
            f"按重试策略执行，最终返回超时或业务错误码（如 `{first_error}`）并记录日志",
        ],
    ]
    return rows


def _example_value(raw_type: str) -> Any:
    value = (raw_type or "string").lower()
    if "bool" in value:
        return True
    if "long" in value:
        return 1
    if "int" in value:
        return 1
    if any(token in value for token in ["double", "float", "decimal", "number", "amount"]):
        return 1.0
    if any(token in value for token in ["json", "object", "map", "dict"]):
        return {}
    if any(token in value for token in ["list", "array", "[]"]):
        return []
    return ""
