from __future__ import annotations

from typing import Any

from app.agents.impact_analyzer import ImpactAnalyzer
from app.agents.requirement_parser import RequirementParser
from app.schemas import ContextSnapshot, ImpactItem, RequirementInput


class RequirementAnalyzer:
    """需求/产品分析专家：需求拆解、影响范围、优先级分析。"""

    def __init__(
        self,
        requirement_parser: RequirementParser,
        impact_analyzer: ImpactAnalyzer,
    ) -> None:
        self.requirement_parser = requirement_parser
        self.impact_analyzer = impact_analyzer

    def analyze(
        self,
        requirement_text: str,
        context: ContextSnapshot,
        knowledge_input: dict[str, Any] | None = None,
    ) -> tuple[RequirementInput, list[ImpactItem], list[dict[str, str]]]:
        requirement = self.requirement_parser.parse(requirement_text)
        impacts = self.impact_analyzer.analyze(requirement, context)
        breakdown = self._build_requirement_breakdown(requirement, knowledge_input or {})
        return requirement, impacts, breakdown

    @staticmethod
    def _build_requirement_breakdown(
        requirement: RequirementInput,
        knowledge_input: dict[str, Any],
    ) -> list[dict[str, str]]:
        items: list[dict[str, str]] = []
        known_systems = set(knowledge_input.get("domain_systems", []))
        recent_count = len(knowledge_input.get("recent_requirements", []))
        public_source = str(knowledge_input.get("public_kb_source", "")).strip()
        public_patterns = len(knowledge_input.get("public_requirement_patterns", []))
        public_cases = len(knowledge_input.get("public_recent_cases", []))

        for goal in requirement.goals:
            items.append(
                {
                    "item": goal,
                    "priority": "P0",
                    "type": "goal",
                    "reason": "核心业务目标，决定方案与开发主路径。",
                }
            )
        for constraint in requirement.constraints:
            items.append(
                {
                    "item": constraint,
                    "priority": "P1",
                    "type": "constraint",
                    "reason": "实施边界，影响方案可行性与上线风险。",
                }
            )
        for acceptance in requirement.acceptance_criteria:
            items.append(
                {
                    "item": acceptance,
                    "priority": "P0",
                    "type": "acceptance",
                    "reason": "验收闭环条件，直接决定交付是否完成。",
                }
            )

        if known_systems:
            items.append(
                {
                    "item": f"知识库可用系统数：{len(known_systems)}",
                    "priority": "P1",
                    "type": "knowledge",
                    "reason": "需求分析已结合已有领域知识库进行上下游边界校验。",
                }
            )
        if recent_count:
            items.append(
                {
                    "item": f"历史相似需求沉淀：{recent_count} 条（近5条已加载）",
                    "priority": "P2",
                    "type": "knowledge",
                    "reason": "复用历史沉淀可降低需求遗漏与设计偏差。",
                }
            )
        if public_source:
            items.append(
                {
                    "item": f"公共知识库来源：{public_source}",
                    "priority": "P1",
                    "type": "knowledge",
                    "reason": "需求分析阶段已接入公共知识库进行模式复用与边界校验。",
                }
            )
        if public_patterns:
            items.append(
                {
                    "item": f"公共需求模式命中：{public_patterns} 条",
                    "priority": "P1",
                    "type": "knowledge",
                    "reason": "复用公共需求分析模式，降低漏项风险。",
                }
            )
        if public_cases:
            items.append(
                {
                    "item": f"公共历史案例参考：{public_cases} 条",
                    "priority": "P2",
                    "type": "knowledge",
                    "reason": "可参考历史交付经验，减少方案偏差。",
                }
            )
        return items
