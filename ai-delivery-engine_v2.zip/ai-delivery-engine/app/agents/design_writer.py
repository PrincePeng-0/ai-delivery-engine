from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

from app.llm import (
    LLMClient,
    context_snapshot_brief,
    ensure_str,
    ensure_str_list,
    impacts_brief,
    requirement_brief,
)
from app.schemas import ContextSnapshot, DesignDoc, ImpactItem, RequirementInput, SequenceDiagram


class DesignWriter:
    def __init__(
        self,
        llm_client: LLMClient | None = None,
        use_llm: bool = True,
        allow_fallback: bool = True,
        technical_design_rule: str = "",
    ) -> None:
        self.llm_client = llm_client
        self.use_llm = use_llm
        self.allow_fallback = allow_fallback
        self.technical_design_rule = technical_design_rule.strip()

    def build(
        self,
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        knowledge_input: dict[str, Any] | None = None,
    ) -> DesignDoc:
        if self.use_llm and self.llm_client and self.llm_client.is_ready:
            try:
                return self._build_with_llm(requirement, context, impacts, knowledge_input=knowledge_input)
            except Exception:
                if not self.allow_fallback:
                    raise

        if self.use_llm and self.llm_client and not self.llm_client.is_ready and not self.allow_fallback:
            raise RuntimeError("LLM is not ready and fallback is disabled.")

        return self._build_with_rules(requirement, context, impacts, knowledge_input=knowledge_input)

    def _build_with_llm(
        self,
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        knowledge_input: dict[str, Any] | None = None,
    ) -> DesignDoc:
        assert self.llm_client is not None
        base_doc = self._build_with_rules(requirement, context, impacts, knowledge_input=knowledge_input)

        system_prompt = (
            "你是资深架构师。"
            "请基于需求、影响系统和代码上下文输出开发设计文档 JSON。"
            "只允许输出 JSON，不要输出代码块。"
        )
        if self.technical_design_rule:
            system_prompt += (
                "\n你必须严格遵守以下《技术开发文档编写规范》，"
                "并确保输出章节与规范要求一致：\n"
                f"{_trim_rule_text(self.technical_design_rule)}"
            )
        knowledge_hint = _knowledge_hint_text(knowledge_input)
        user_prompt = (
            "请输出如下结构：\n"
            "{\n"
            '  "title": "string",\n'
            '  "background": "string",\n'
            '  "goals": ["string"],\n'
            '  "scope_in": ["string"],\n'
            '  "scope_out": ["string"],\n'
            '  "constraints": ["string"],\n'
            '  "assumptions": ["string"],\n'
            '  "architecture_diagram": "Mermaid flowchart source only",\n'
            '  "sequence_diagrams": [{"title": "string", "mermaid": "Mermaid sequenceDiagram source only"}],\n'
            '  "data_model_notes": ["string"],\n'
            '  "test_plan": ["string"],\n'
            '  "release_plan": ["string"],\n'
            '  "risks": ["string"],\n'
            '  "context_summary": "string"\n'
            "}\n\n"
            "要求：\n"
            "- architecture_diagram 必须是 flowchart 语法\n"
            "- sequence_diagrams 至少提供 2 个\n"
            "- 内容需具体到当前业务上下文，不写空泛描述\n\n"
            f"requirement:\n{requirement_brief(requirement)}\n\n"
            f"impacts:\n{impacts_brief(impacts)}\n\n"
            f"context_brief:\n{context_snapshot_brief(context)}\n"
            f"\npublic_knowledge_hint:\n{knowledge_hint}\n"
        )
        payload = self.llm_client.generate_json(system_prompt=system_prompt, user_prompt=user_prompt)
        if not isinstance(payload, dict):
            raise ValueError("Design writer expects a JSON object.")

        sequence_diagrams = self._parse_sequence_diagrams(payload.get("sequence_diagrams")) or base_doc.sequence_diagrams
        architecture_diagram = ensure_str(payload.get("architecture_diagram"), base_doc.architecture_diagram)
        if not architecture_diagram.strip():
            architecture_diagram = base_doc.architecture_diagram

        return DesignDoc(
            title=ensure_str(payload.get("title"), base_doc.title),
            background=ensure_str(payload.get("background"), base_doc.background),
            goals=ensure_str_list(payload.get("goals")) or base_doc.goals,
            scope_in=ensure_str_list(payload.get("scope_in")) or base_doc.scope_in,
            scope_out=ensure_str_list(payload.get("scope_out")) or base_doc.scope_out,
            constraints=ensure_str_list(payload.get("constraints")) or base_doc.constraints,
            assumptions=ensure_str_list(payload.get("assumptions")) or base_doc.assumptions,
            impacts=impacts,
            architecture_diagram=architecture_diagram,
            sequence_diagrams=sequence_diagrams,
            data_model_notes=ensure_str_list(payload.get("data_model_notes")) or base_doc.data_model_notes,
            test_plan=ensure_str_list(payload.get("test_plan")) or base_doc.test_plan,
            release_plan=ensure_str_list(payload.get("release_plan")) or base_doc.release_plan,
            risks=ensure_str_list(payload.get("risks")) or base_doc.risks,
            context_summary=ensure_str(payload.get("context_summary"), base_doc.context_summary),
        )

    def _build_with_rules(
        self,
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        knowledge_input: dict[str, Any] | None = None,
    ) -> DesignDoc:
        impacted_systems = [item.system for item in impacts]

        assumptions = [
            "默认沿用现有 RPC/HTTP 协议版本，不在本次设计中强制升级。",
            "若涉及 DB 表结构调整，采用向后兼容方式（先加后切）。",
            "跨系统调用均需保留 traceId/requestId 贯穿能力。",
        ]
        if _has_tag(impacted_systems, "gateway") and _has_tag(impacted_systems, "risk"):
            assumptions.append("入口到决策链路需满足低时延要求，并提供超时降级策略。")

        data_model_notes = self._build_data_model_notes(context, impacted_systems)
        data_model_notes.extend(_extract_design_patterns(knowledge_input))
        test_plan = self._build_test_plan(requirement, impacted_systems)
        release_plan = self._build_release_plan(impacted_systems)
        risks = self._build_risks(impacted_systems)
        summary = self._build_context_summary(context, impacted_systems)
        architecture_diagram = self._build_architecture_mermaid(impacted_systems)
        sequence_diagrams = self._build_sequence_diagrams(impacted_systems)

        return DesignDoc(
            title=f"{requirement.title} - 开发设计文档",
            background=requirement.background,
            goals=requirement.goals,
            scope_in=requirement.scope_in,
            scope_out=requirement.scope_out or ["不涉及系统保持现状"],
            constraints=requirement.constraints,
            assumptions=assumptions,
            impacts=impacts,
            architecture_diagram=architecture_diagram,
            sequence_diagrams=sequence_diagrams,
            data_model_notes=data_model_notes,
            test_plan=test_plan,
            release_plan=release_plan,
            risks=risks,
            context_summary=summary,
        )

    @staticmethod
    def _parse_sequence_diagrams(value: object) -> list[SequenceDiagram]:
        if not isinstance(value, list):
            return []

        diagrams: list[SequenceDiagram] = []
        for item in value:
            if not isinstance(item, dict):
                continue
            title = ensure_str(item.get("title"))
            mermaid = ensure_str(item.get("mermaid"))
            if not title or not mermaid:
                continue
            diagrams.append(SequenceDiagram(title=title, mermaid=mermaid))
        return diagrams

    def _build_architecture_mermaid(self, impacted_systems: list[str]) -> str:
        systems = impacted_systems[:] or ["system-core"]
        lines = ["flowchart LR", 'REQ["需求入口"]']
        for system in systems:
            lines.append(f'{self._node(system)}["{_display_name(system)}"]')
        lines.append(f"REQ --> {self._node(systems[0])}")
        if len(systems) > 1:
            for idx in range(len(systems) - 1):
                lines.append(f"{self._node(systems[idx])} --> {self._node(systems[idx + 1])}")
        return "\n".join(lines)

    def _build_sequence_diagrams(self, impacted_systems: list[str]) -> list[SequenceDiagram]:
        main_chain = self._build_main_chain(impacted_systems)
        main_lines = ["sequenceDiagram", "    autonumber", '    actor Client as "需求调用方"']
        for system in main_chain:
            main_lines.append(f'    participant {self._node(system)} as "{_display_name(system)}"')

        if main_chain:
            main_lines.append(f'    Client->>{self._node(main_chain[0])}: 发起需求相关调用')
            for idx in range(len(main_chain) - 1):
                src = self._node(main_chain[idx])
                dst = self._node(main_chain[idx + 1])
                main_lines.append(f"    {src}->>{dst}: 传递业务请求/上下文")
                main_lines.append(f"    {dst}-->>{src}: 返回处理结果")
            main_lines.append(f'    {self._node(main_chain[0])}-->>Client: 返回最终结果')

        release_lines = [
            "sequenceDiagram",
            "    autonumber",
            '    actor Dev as "研发"',
            '    participant CI as "CI/CD"',
            '    participant Gray as "灰度环境"',
            '    participant Prod as "生产环境"',
            "    Dev->>CI: 提交代码并触发流水线",
            "    CI->>Gray: 部署灰度版本",
            "    Gray-->>CI: 回传验证结果",
            "    CI->>Prod: 分批发布",
            "    alt 监控异常",
            "      CI->>Prod: 触发回滚",
            "    else 指标正常",
            "      Prod-->>Dev: 发布完成",
            "    end",
        ]
        return [
            SequenceDiagram(title="核心业务时序", mermaid="\n".join(main_lines)),
            SequenceDiagram(title="发布与回滚时序", mermaid="\n".join(release_lines)),
        ]

    @staticmethod
    def _build_main_chain(impacted_systems: list[str]) -> list[str]:
        if not impacted_systems:
            return []
        ordered = sorted(impacted_systems, key=_system_priority)
        return ordered

    @staticmethod
    def _build_data_model_notes(context: ContextSnapshot, impacted_systems: list[str]) -> list[str]:
        repo_map = {repo.name: repo for repo in context.repos}
        notes: list[str] = []

        for system in impacted_systems:
            repo = repo_map.get(system)
            if not repo:
                continue
            if repo.tables:
                sample_tables = ", ".join(repo.tables[:6])
                notes.append(f"`{system}` 涉及表（示例）：{sample_tables}")
            else:
                notes.append(f"`{system}` 暂未扫描到 `@TableName` 映射，需在详细设计阶段确认数据落点。")

        shared_hit: dict[str, list[str]] = defaultdict(list)
        for table, repos in context.shared_tables.items():
            if set(repos).intersection(impacted_systems):
                shared_hit[table] = repos

        if shared_hit:
            notes.append("跨仓库共享表提示（需重点评估边界与一致性）：")
            for table, repos in list(shared_hit.items())[:10]:
                notes.append(f"`{table}` -> {', '.join(repos)}")

        return notes

    @staticmethod
    def _build_test_plan(requirement: RequirementInput, impacted_systems: list[str]) -> list[str]:
        plan = [
            "单元测试：新增/改造逻辑分支覆盖，核心方法覆盖率提升。",
            "集成测试：覆盖跨系统调用链、异常返回、超时和重试。",
            "回归测试：重点验证核心业务口径一致性与终态一致性。",
            "压测与容量：关注入口链路、决策链路、记账链路高峰表现。",
        ]
        if requirement.acceptance_criteria:
            plan.append("需求验收项映射：")
            plan.extend(requirement.acceptance_criteria)
        if _has_tag(impacted_systems, "risk"):
            plan.append("决策专项：验证规则灰度切换、误判回放与回滚效果。")
        return plan

    @staticmethod
    def _build_release_plan(impacted_systems: list[str]) -> list[str]:
        plan = [
            "先发布基础依赖系统，再发布调用方系统，确保接口已就绪。",
            "采用灰度发布：5% -> 20% -> 50% -> 100%。",
            "发布窗口内开启关键指标监控：成功率、超时率、错误码分布、消息积压。",
            "准备回滚预案：配置开关回退 + 版本回滚双保险。",
        ]
        if _has_tag(impacted_systems, "gateway"):
            plan.append("入口层发布需优先验证回调链路与幂等行为。")
        if _has_tag(impacted_systems, "risk"):
            plan.append("决策规则发布建议采用灰度规则集并支持快速切换。")
        return plan

    @staticmethod
    def _build_risks(impacted_systems: list[str]) -> list[str]:
        risks = [
            "跨系统调用链较长，任一节点超时会放大整体失败率。",
            "共享表/跨域读写可能引入数据一致性与边界不清问题。",
            "错误码映射不统一可能导致上游误判失败原因。",
        ]
        if _has_tag(impacted_systems, "gateway"):
            risks.append("入口层变更若未充分灰度，可能影响整体吞吐。")
        if _has_tag(impacted_systems, "risk"):
            risks.append("决策策略误配置可能导致误拒绝或放行风险上升。")
        return risks

    @staticmethod
    def _build_context_summary(context: ContextSnapshot, impacted_systems: list[str]) -> str:
        repo_count = len(context.repos)
        impacted = ", ".join(impacted_systems) if impacted_systems else "无"
        shared_count = len(context.shared_tables)
        return (
            f"- 扫描时间：{context.generated_at}\n"
            f"- 仓库总数：{repo_count}\n"
            f"- 本次影响系统：{impacted}\n"
            f"- 共享表数量：{shared_count}\n"
            f"- 项目根目录：`{context.project_root}`"
        )

    @staticmethod
    def _node(system: str) -> str:
        return re.sub(r"[^A-Za-z0-9_]+", "_", system).upper().strip("_") or "SYSTEM"


def _display_name(system: str) -> str:
    parts = [item.capitalize() for item in re.split(r"[-_/.]+", system) if item]
    return "".join(parts) or system


def _system_priority(system: str) -> tuple[int, str]:
    rules = [
        ("orchestr", 1),
        ("gateway", 2),
        ("risk", 3),
        ("trans", 4),
        ("bill", 5),
        ("user", 6),
    ]
    lower = system.lower()
    for token, score in rules:
        if token in lower:
            return score, lower
    return 99, lower


def _has_tag(systems: list[str], token: str) -> bool:
    return any(token.lower() in system.lower() for system in systems)


def _trim_rule_text(text: str, max_chars: int = 8000) -> str:
    content = text.strip()
    if len(content) <= max_chars:
        return content
    return content[:max_chars] + "\n...（规范内容过长，已截断）"


def _knowledge_hint_text(knowledge_input: dict[str, Any] | None, max_items: int = 6) -> str:
    if not knowledge_input:
        return "无"

    sections: list[str] = []
    source = str(knowledge_input.get("public_kb_source", "")).strip()
    namespace = str(knowledge_input.get("public_kb_namespace", "")).strip()
    if source:
        sections.append(f"- source: {source}")
    if namespace:
        sections.append(f"- namespace: {namespace}")

    patterns = _to_text_items(knowledge_input.get("public_architecture_patterns"))[:max_items]
    if patterns:
        sections.append("- architecture_patterns:")
        sections.extend(f"  - {item}" for item in patterns)

    references = _to_text_items(knowledge_input.get("public_references"))[:max_items]
    if references:
        sections.append("- references:")
        sections.extend(f"  - {item}" for item in references)

    cases = knowledge_input.get("public_recent_cases")
    if isinstance(cases, list) and cases:
        sections.append(f"- recent_cases_count: {len(cases)}")

    return "\n".join(sections) if sections else "无"


def _extract_design_patterns(knowledge_input: dict[str, Any] | None, limit: int = 5) -> list[str]:
    if not knowledge_input:
        return []
    patterns = _to_text_items(knowledge_input.get("public_architecture_patterns"))[:limit]
    return [f"公共知识建议：{item}" for item in patterns]


def _to_text_items(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    output: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            output.append(text)
    return output
