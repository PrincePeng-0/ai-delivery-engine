from __future__ import annotations

from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, ValidationReport
from app.validators import validate_outputs


class Reviewer:
    """文档质量审查 Agent。"""

    def review(
        self,
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        context: ContextSnapshot,
    ) -> ValidationReport:
        return validate_outputs(design_doc, api_doc, impacts, context)

