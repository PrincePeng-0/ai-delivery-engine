from __future__ import annotations

from typing import Any

from app.schemas import ApiDoc, ImpactItem, RequirementInput


class TestingPlanner:
    """测试验证阶段规划器（E 阶段）。"""

    def build(
        self,
        requirement: RequirementInput,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        coding_plan: dict[str, Any],
    ) -> dict[str, Any]:
        endpoint_cases: list[dict[str, Any]] = []
        for endpoint in api_doc.endpoints:
            positive_input = self._build_payload(endpoint.request_fields)
            negative_input = self._build_negative_payload(endpoint.request_fields)
            first_error = next((item.get("code", "") for item in endpoint.error_codes if item.get("code")), "SYSTEM_ERROR")
            endpoint_cases.append(
                {
                    "endpoint": endpoint.interface,
                    "owner_system": endpoint.owner_system,
                    "cases": [
                        {
                            "case_id": "POS-01",
                            "type": "正向用例",
                            "input": positive_input,
                            "expected": "返回成功结果，响应字段完整，耗时满足 SLA",
                        },
                        {
                            "case_id": "NEG-01",
                            "type": "反向用例",
                            "input": negative_input,
                            "expected": f"返回参数错误或业务错误码（如 {first_error}）",
                        },
                    ],
                }
            )

        bug_fix_hints = [
            "优先定位字段映射与类型转换错误",
            "检查重试与幂等键是否导致重复写入",
            "核对超时边界与降级策略开关是否生效",
            "复核错误码映射，避免上游误判",
        ]

        return {
            "stage": "测试验证阶段",
            "stage_code": "E",
            "ai_boost": "AI提效4：测试生成与Bug定位",
            "core_actions": ["用例设计", "测试执行", "Bug修复"],
            "ai_actions": [
                "按需求与代码逻辑自动生成单元测试与集成测试样例",
                "自动覆盖正向/反向用例并形成输入样本",
                "执行测试后给出疑似缺陷定位与修复提示",
            ],
            "entry_criteria": [
                "编码开发阶段通过基础质量门禁",
                "接口契约与测试环境配置可用",
            ],
            "exit_criteria": [
                "关键用例执行通过",
                "高优先级 Bug 已修复或完成风险豁免",
                "回归结果可用于上线评审",
            ],
            "test_case_sets": endpoint_cases,
            "bug_fix_hints": bug_fix_hints,
            "regression_focus": [
                "交易终态一致性",
                "账单口径一致性",
                "风控决策稳定性",
                "网关入口时延与错误码分布",
            ],
            "linked_coding_summary": coding_plan.get("summary", ""),
            "summary": (
                f"需求《{requirement.title}》共生成 {len(endpoint_cases)} 组接口测试集，"
                f"覆盖 {len(impacts)} 个影响系统。"
            ),
        }

    @staticmethod
    def _build_payload(fields: list[dict[str, str]]) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        for field in fields:
            name = field.get("name", "").strip()
            if not name:
                continue
            payload[name] = _example_value(field.get("type", "string"))
        return payload

    @staticmethod
    def _build_negative_payload(fields: list[dict[str, str]]) -> dict[str, Any]:
        payload = TestingPlanner._build_payload(fields)
        required = [item.get("name", "").strip() for item in fields if item.get("required", "").upper() == "Y"]
        if required:
            payload.pop(required[0], None)
            payload["_missing_field"] = required[0]
        else:
            payload["_invalid_field"] = "invalid_type"
        return payload


def _example_value(raw_type: str) -> Any:
    text = (raw_type or "string").lower()
    if "bool" in text:
        return True
    if "long" in text or "int" in text:
        return 1
    if any(token in text for token in ["double", "float", "decimal", "number", "amount"]):
        return 1.0
    if any(token in text for token in ["json", "object", "map", "dict"]):
        return {}
    if any(token in text for token in ["list", "array", "[]"]):
        return []
    return ""
