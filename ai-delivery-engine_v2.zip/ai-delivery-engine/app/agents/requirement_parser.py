from __future__ import annotations

import re
from typing import Iterable

from app.llm import LLMClient, ensure_str, ensure_str_list
from app.schemas import RequirementInput


class RequirementParser:
    """将原始需求文本解析为结构化对象（LLM 优先，规则回退）。"""

    SECTION_ALIASES: dict[str, list[str]] = {
        "background": [
            "背景",
            "背景说明",
            "需求背景",
            "现状",
            "现状问题",
            "业务背景",
            "问题描述",
            "痛点",
            "context",
            "why",
            "overview",
        ],
        "goals": [
            "目标",
            "建设目标",
            "业务目标",
            "预期目标",
            "目标与价值",
            "想达成什么",
            "本次目标",
            "目标定义",
            "goals",
            "goal",
            "objective",
            "objectives",
        ],
        "scope_in": [
            "in scope",
            "scope in",
            "范围",
            "本次范围",
            "涉及范围",
            "纳入范围",
            "影响范围",
            "覆盖范围",
            "涉及系统",
            "影响系统",
        ],
        "scope_out": [
            "out scope",
            "scope out",
            "out of scope",
            "不在范围",
            "非范围",
            "排除范围",
            "不涉及",
            "不包含",
            "暂不支持",
            "暂不改动",
        ],
        "constraints": [
            "约束",
            "约束条件",
            "限制",
            "边界条件",
            "前提",
            "依赖",
            "constraint",
            "constraints",
            "非功能要求",
            "合规要求",
            "注意事项",
        ],
        "acceptance": [
            "验收",
            "验收标准",
            "完成标准",
            "成功标准",
            "交付标准",
            "acceptance",
            "acceptance criteria",
            "definition of done",
            "dod",
            "kpi",
        ],
    }

    GOAL_HINTS = [
        "目标",
        "希望",
        "实现",
        "提升",
        "提高",
        "优化",
        "降低",
        "减少",
        "支持",
        "达成",
        "完善",
        "增强",
        "goal",
        "objective",
    ]
    CONSTRAINT_HINTS = [
        "必须",
        "不能",
        "不可",
        "禁止",
        "限制",
        "依赖",
        "前提",
        "需满足",
        "兼容",
        "不变",
        "保持",
        "sla",
        "合规",
        "mandatory",
        "must",
    ]
    ACCEPTANCE_HINTS = [
        "验收",
        "完成标准",
        "成功标准",
        "交付标准",
        "kpi",
        "验证",
        "测试通过",
        "可回滚",
        "可灰度",
        "done",
        "dod",
        "acceptance",
    ]

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        use_llm: bool = True,
        allow_fallback: bool = True,
        requirement_analysis_rule: str = "",
    ) -> None:
        self.llm_client = llm_client
        self.use_llm = use_llm
        self.allow_fallback = allow_fallback
        self.requirement_analysis_rule = requirement_analysis_rule.strip()

    def parse(self, raw_text: str) -> RequirementInput:
        if self.use_llm and self.llm_client and self.llm_client.is_ready:
            try:
                return self._parse_with_llm(raw_text)
            except Exception:
                if not self.allow_fallback:
                    raise

        if self.use_llm and self.llm_client and not self.llm_client.is_ready and not self.allow_fallback:
            raise RuntimeError("LLM is not ready and fallback is disabled.")

        return self._parse_with_rules(raw_text)

    def _parse_with_llm(self, raw_text: str) -> RequirementInput:
        base = self._parse_with_rules(raw_text)
        assert self.llm_client is not None

        system_prompt = (
            "你是资深支付中台需求分析师。"
            "你需要从非标准、格式混乱、术语不统一的需求文档中提取结构化信息。"
            "请将输入需求文本解析成结构化 JSON。"
            "只输出 JSON 对象，不要输出 Markdown 或解释。"
        )
        if self.requirement_analysis_rule:
            system_prompt += (
                "\n你必须严格遵守以下《需求分析报告规范》，"
                "当需求原文与规范存在冲突时，以规范为准并在输出中显式补齐缺失项：\n"
                f"{_trim_rule_text(self.requirement_analysis_rule)}"
            )
        user_prompt = (
            "请按如下结构输出：\n"
            "{\n"
            '  "title": "string",\n'
            '  "background": "string",\n'
            '  "goals": ["string"],\n'
            '  "scope_in": ["string"],\n'
            '  "scope_out": ["string"],\n'
            '  "constraints": ["string"],\n'
            '  "acceptance_criteria": ["string"]\n'
            "}\n\n"
            "要求：\n"
            "- 即使原文没有明确小节，也要根据语义归纳。\n"
            "- 背景要是可读的一段话，不要只返回标题。\n"
            "- goals/scope/constraints/acceptance_criteria 尽量返回多条，避免空数组。\n"
            "- 若 scope_out 未提及，可返回空数组。\n\n"
            f"需求原文：\n{raw_text}\n"
        )

        payload = self.llm_client.generate_json(system_prompt=system_prompt, user_prompt=user_prompt)
        if not isinstance(payload, dict):
            raise ValueError("Requirement parser expects a JSON object.")

        title = ensure_str(_first_value(payload, ["title", "标题"]), base.title)
        background = ensure_str(_first_value(payload, ["background", "背景", "context"]), base.background)
        goals = ensure_str_list(_first_value(payload, ["goals", "goal", "目标", "objectives"])) or base.goals
        scope_in = ensure_str_list(_first_value(payload, ["scope_in", "in_scope", "范围", "scope"])) or base.scope_in
        scope_out = ensure_str_list(_first_value(payload, ["scope_out", "out_scope", "不涉及", "out_of_scope"]))
        if not scope_out:
            scope_out = base.scope_out
        constraints = (
            ensure_str_list(_first_value(payload, ["constraints", "constraint", "约束", "限制"]))
            or base.constraints
        )
        acceptance = (
            ensure_str_list(
                _first_value(
                    payload,
                    [
                        "acceptance_criteria",
                        "acceptance",
                        "acceptanceCriteria",
                        "验收标准",
                        "完成标准",
                        "definition_of_done",
                        "dod",
                    ],
                )
            )
            or base.acceptance_criteria
        )

        return self._finalize_requirement(
            RequirementInput(
                title=title,
                background=background,
                goals=goals,
                scope_in=scope_in,
                scope_out=scope_out,
                constraints=constraints,
                acceptance_criteria=acceptance,
                raw_text=raw_text,
            )
        )

    def _parse_with_rules(self, raw_text: str) -> RequirementInput:
        lines = raw_text.splitlines()
        plain_lines = [line.strip() for line in lines if line.strip()]
        sections = self._collect_sections(lines)

        title = self._parse_title(plain_lines, sections)
        background = self._extract_background(raw_text, sections)
        goals = self._extract_goals(lines, sections)
        scope_in, scope_out = self._extract_scopes(lines, sections)
        constraints = self._extract_constraints(lines, sections)
        acceptance = self._extract_acceptance(lines, sections)
        if goals and constraints:
            goal_set = set(goals)
            constraints = [item for item in constraints if item not in goal_set]

        return self._finalize_requirement(
            RequirementInput(
                title=title,
                background=background,
                goals=goals,
                scope_in=scope_in,
                scope_out=scope_out,
                constraints=constraints,
                acceptance_criteria=acceptance,
                raw_text=raw_text,
            )
        )

    def _parse_title(self, lines: list[str], sections: dict[str, list[str]]) -> str:
        inline_title = self._extract_inline_with_aliases(
            lines,
            ["标题", "title", "需求名称", "需求标题"],
            split_items=False,
        )
        if inline_title:
            return inline_title[0]

        if not lines:
            return "领域需求开发设计"

        for line in lines[:8]:
            if _looks_like_key_value_line(line):
                continue
            if _looks_like_heading(line):
                value = _strip_heading_prefix(line)
                if len(value) >= 2 and not self._is_alias_heading(value):
                    return value
                continue
            if len(line) >= 2 and not self._is_alias_heading(line):
                return line

        for heading in sections:
            normalized = _strip_heading_prefix(heading)
            if len(normalized) >= 2 and not self._is_alias_heading(normalized):
                return normalized
        return "领域需求开发设计"

    def _extract_background(self, raw_text: str, sections: dict[str, list[str]]) -> str:
        from_section = self._collect_section_sentences(sections, self.SECTION_ALIASES["background"])
        if from_section:
            return " ".join(from_section[:2]).strip()

        paragraphs = [item.strip() for item in raw_text.split("\n\n") if item.strip()]
        for paragraph in paragraphs:
            if _looks_like_heading(paragraph):
                continue
            if self._line_should_skip_for_background(paragraph):
                continue
            return paragraph.lstrip("#").strip()
        return "本需求需要在多仓库架构下输出详细开发设计和接口文档。"

    def _extract_goals(self, lines: list[str], sections: dict[str, list[str]]) -> list[str]:
        result: list[str] = []
        result.extend(self._collect_section_items(sections, self.SECTION_ALIASES["goals"], split_items=False))
        result.extend(self._extract_inline_with_aliases(lines, self.SECTION_ALIASES["goals"], split_items=False))
        if not result:
            classified = self._classify_lines(lines, self.GOAL_HINTS, max_len=140)
            for line in classified:
                if any(token in line.lower() for token in self.CONSTRAINT_HINTS):
                    continue
                if any(token in line.lower() for token in self.ACCEPTANCE_HINTS):
                    continue
                result.append(line)
        return _unique(result)

    def _extract_scopes(self, lines: list[str], sections: dict[str, list[str]]) -> tuple[list[str], list[str]]:
        scope_in: list[str] = []
        scope_out: list[str] = []

        in_direct_aliases = ["in scope", "scope in", "涉及系统", "影响系统", "纳入范围"]
        out_direct_aliases = ["out scope", "scope out", "out of scope", "不在范围", "非范围", "排除范围"]

        for heading, content_lines in sections.items():
            heading_lower = heading.lower()
            if _contains_any(heading_lower, out_direct_aliases):
                scope_out.extend(_extract_items_from_lines(content_lines, split_items=True))
                continue
            if _contains_any(heading_lower, in_direct_aliases):
                scope_in.extend(_extract_items_from_lines(content_lines, split_items=True))
                continue
            if _contains_any(heading_lower, ["范围", "scope"]):
                for line in content_lines:
                    self._split_scope_line(line, scope_in, scope_out)

        for line in lines:
            self._split_scope_line(line, scope_in, scope_out)

        return _unique(scope_in), _unique(scope_out)

    def _extract_constraints(self, lines: list[str], sections: dict[str, list[str]]) -> list[str]:
        result: list[str] = []
        result.extend(self._collect_section_items(sections, self.SECTION_ALIASES["constraints"], split_items=False))
        result.extend(self._extract_inline_with_aliases(lines, self.SECTION_ALIASES["constraints"], split_items=False))
        classified = self._classify_lines(lines, self.CONSTRAINT_HINTS, max_len=180)
        for line in classified:
            lower = line.lower()
            if any(token in lower for token in self.ACCEPTANCE_HINTS):
                continue
            if any(token in lower for token in ["uat", "接口文档", "请求字段", "响应字段", "错误码", "幂等", "重试策略"]):
                continue
            result.append(line)
        return _unique(result)

    def _extract_acceptance(self, lines: list[str], sections: dict[str, list[str]]) -> list[str]:
        result: list[str] = []
        result.extend(self._collect_section_items(sections, self.SECTION_ALIASES["acceptance"], split_items=False))
        result.extend(self._extract_inline_with_aliases(lines, self.SECTION_ALIASES["acceptance"], split_items=False))
        result.extend(self._classify_lines(lines, self.ACCEPTANCE_HINTS, max_len=180))
        return _unique(result)

    def _collect_sections(self, lines: list[str]) -> dict[str, list[str]]:
        headings: list[tuple[int, str]] = []
        for idx, line in enumerate(lines):
            heading = self._extract_heading(line)
            if heading:
                headings.append((idx, heading))

        sections: dict[str, list[str]] = {}
        for pos, (start_idx, heading) in enumerate(headings):
            end_idx = headings[pos + 1][0] if pos + 1 < len(headings) else len(lines)
            content = []
            for item in lines[start_idx + 1 : end_idx]:
                stripped = item.strip()
                if stripped:
                    content.append(stripped)
            sections[heading] = content
        return sections

    def _extract_heading(self, line: str) -> str | None:
        text = line.strip()
        if not text:
            return None

        markdown = re.match(r"^#{1,6}\s*(.+)$", text)
        if markdown:
            return markdown.group(1).strip()

        bracket = re.match(r"^[【\[]\s*([^\]】]+)\s*[\]】]$", text)
        if bracket and self._is_alias_heading(bracket.group(1)):
            return bracket.group(1).strip()

        colon_heading = re.match(r"^(.+?)[：:]\s*$", text)
        if colon_heading and self._is_alias_heading(colon_heading.group(1)):
            return colon_heading.group(1).strip()

        numbered = re.match(r"^(?:\d+[\.\、\)]|[（(]\d+[)）])\s*(.+)$", text)
        if numbered:
            candidate = numbered.group(1).strip()
            if self._is_alias_heading(candidate):
                return candidate

        plain = _strip_heading_prefix(text)
        if self._is_alias_heading(plain):
            return plain
        return None

    def _collect_section_items(
        self,
        sections: dict[str, list[str]],
        aliases: list[str],
        split_items: bool,
    ) -> list[str]:
        result: list[str] = []
        for heading, lines in sections.items():
            if not _contains_any(heading, aliases):
                continue
            result.extend(_extract_items_from_lines(lines, split_items=split_items))
        return _unique(result)

    def _collect_section_sentences(self, sections: dict[str, list[str]], aliases: list[str]) -> list[str]:
        result: list[str] = []
        for heading, lines in sections.items():
            if not _contains_any(heading, aliases):
                continue
            for line in lines:
                text = _normalize_line(line)
                if text:
                    result.append(text)
        return _unique(result)

    def _extract_inline_with_aliases(
        self,
        lines: Iterable[str],
        aliases: list[str],
        split_items: bool,
    ) -> list[str]:
        result: list[str] = []
        for raw_line in lines:
            line = _normalize_line(raw_line)
            if not line:
                continue
            for alias in aliases:
                pattern = rf"^{re.escape(alias)}\s*[:：]\s*(.+)$"
                match = re.match(pattern, line, flags=re.IGNORECASE)
                if not match:
                    continue
                tail = match.group(1).strip()
                if not tail:
                    continue
                split = _split_items(tail) if split_items else []
                if split_items and split:
                    result.extend(split)
                else:
                    result.append(_strip_line_prefix(tail))
                break
        return _unique(result)

    def _classify_lines(self, lines: list[str], hints: list[str], max_len: int) -> list[str]:
        result: list[str] = []
        for raw_line in lines:
            line = _normalize_line(raw_line)
            if not line:
                continue
            if _looks_like_heading(line) and not _is_numbered_item(line):
                continue
            if self._is_alias_heading(line):
                continue
            if len(line) > max_len:
                continue
            if _looks_like_key_value_line(line) and not any(hint in line.lower() for hint in hints):
                continue
            lower = line.lower()
            if any(hint.lower() in lower for hint in hints):
                cleaned = _strip_line_prefix(line)
                if cleaned:
                    result.append(cleaned)
                    continue
            if _is_checklist_item(raw_line):
                cleaned = _strip_line_prefix(line)
                if cleaned and any(hint.lower() in cleaned.lower() for hint in hints):
                    result.append(cleaned)
        return _unique(result)

    def _split_scope_line(self, raw_line: str, scope_in: list[str], scope_out: list[str]) -> None:
        line = _normalize_line(raw_line)
        if not line:
            return
        lower = line.lower()

        in_then_out = re.search(
            r"in\s*scope\s*[:：]\s*(.+?)\s*(?:out\s*scope|out\s*of\s*scope)\s*[:：]\s*(.+)$",
            line,
            flags=re.IGNORECASE,
        )
        if in_then_out:
            scope_in.extend(_split_items(in_then_out.group(1)))
            scope_out.extend(_split_items(in_then_out.group(2)))
            return

        if "in scope" in lower or "scope in" in lower:
            tail = _extract_after_colon(line)
            scope_in.extend(_split_items(tail or line))
        if "out scope" in lower or "out of scope" in lower or "scope out" in lower:
            tail = _extract_after_colon(line)
            scope_out.extend(_split_items(tail or line))

        if any(token in line for token in ["不涉及", "不包含", "排除", "暂不支持", "暂不改动"]):
            scope_out.extend(_split_items(_extract_after_colon(line) or line))
        if any(token in line for token in ["涉及", "包含", "纳入", "覆盖"]) and "不涉及" not in line:
            scope_in.extend(_split_items(_extract_after_colon(line) or line))

    def _is_alias_heading(self, text: str) -> bool:
        normalized = _strip_heading_prefix(text).lower().strip()
        if not normalized:
            return False
        if len(normalized) > 48:
            return False
        if ":" in normalized or "：" in normalized:
            return False
        if any(token in normalized for token in ["，", "。", ",", ";", "；"]):
            return False

        basic = {"scope", "constraints", "acceptance", "background", "goals"}
        if normalized in basic:
            return True

        for aliases in self.SECTION_ALIASES.values():
            for alias in aliases:
                target = alias.lower().strip()
                if not target:
                    continue
                if normalized == target:
                    return True
                if normalized.startswith(target) and len(normalized) <= len(target) + 8:
                    return True
                if len(normalized) <= 24 and target in normalized:
                    return True
        return False

    def _line_should_skip_for_background(self, line: str) -> bool:
        lower = line.lower()
        if any(word in lower for word in self.CONSTRAINT_HINTS + self.ACCEPTANCE_HINTS):
            return True
        if _contains_any(lower, self.SECTION_ALIASES["scope_in"] + self.SECTION_ALIASES["scope_out"]):
            return True
        return False

    def _finalize_requirement(self, value: RequirementInput) -> RequirementInput:
        value.title = ensure_str(value.title, "领域需求开发设计")
        value.background = ensure_str(
            value.background,
            "本需求需要在多仓库架构下输出详细开发设计和接口文档。",
        )
        value.goals = _unique(_clean_items(value.goals))
        value.scope_in = _unique(_clean_items(value.scope_in))
        value.scope_out = _unique(_clean_items(value.scope_out))
        value.constraints = _unique(_clean_items(value.constraints))
        value.acceptance_criteria = _unique(_clean_items(value.acceptance_criteria))

        if not value.goals:
            value.goals = [
                "沉淀可评审的详细开发设计方案",
                "生成可落地的接口文档（请求/响应/错误码）",
                "明确上下游影响和发布风险",
            ]
        if not value.scope_in:
            inferred_repos = _extract_repo_names(value.raw_text)
            value.scope_in = inferred_repos or ["待根据需求关键词自动识别影响系统"]
        if value.scope_out:
            out_repos = set(_extract_repo_names("\n".join(value.scope_out)))
            if out_repos:
                value.scope_in = [item for item in value.scope_in if item.lower() not in out_repos]
        if not value.constraints:
            value.constraints = ["保持现有接口版本兼容", "不破坏现网调用链", "方案可灰度发布"]
        if not value.acceptance_criteria:
            value.acceptance_criteria = ["生成开发设计文档", "生成接口文档", "包含测试与回滚策略"]
        return value


def _clean_items(items: list[str]) -> list[str]:
    result: list[str] = []
    for item in items:
        text = _normalize_line(item)
        if not text:
            continue
        result.append(text)
    return result


def _split_items(line: str) -> list[str]:
    text = _normalize_line(line)
    if not text:
        return []

    text = re.sub(
        r"^(?:in\s*scope|scope\s*in|out\s*scope|scope\s*out|out\s*of\s*scope|范围|本次范围|涉及|包含|纳入|不涉及|不包含|排除)\s*[:：]?\s*",
        "",
        text,
        flags=re.IGNORECASE,
    )
    normalized = text.replace("、", ",").replace("；", ";").replace("|", ",")
    candidates = re.split(r"[，,;；/\n]", normalized)

    result: list[str] = []
    for candidate in candidates:
        item = _strip_line_prefix(candidate).strip()
        if not item:
            continue
        if len(item) <= 1:
            continue
        if _looks_like_heading(item):
            continue
        result.append(item)
    return _unique(result)


def _unique(items: list[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        output.append(item)
    return output


def _looks_like_heading(line: str) -> bool:
    text = line.strip()
    if not text:
        return False
    if text.startswith("#"):
        return True
    if re.match(r"^(?:[0-9]+[\.\、\)]|[（(][0-9]+[)）])\s*[^\s].*$", text):
        return True
    if text.endswith(":") or text.endswith("："):
        return True
    if re.match(r"^[【\[][^】\]]+[】\]]$", text):
        return True
    return False


def _is_numbered_item(line: str) -> bool:
    text = line.strip()
    return bool(re.match(r"^(?:[0-9]+[\.\、\)]|[（(][0-9]+[)）])\s+", text))


def _normalize_line(value: str) -> str:
    return value.replace("\u3000", " ").strip()


def _strip_line_prefix(value: str) -> str:
    text = _normalize_line(value)
    text = re.sub(r"^#{1,6}\s*", "", text)
    text = re.sub(r"^[-*]\s+", "", text)
    text = re.sub(r"^\[[ xX]\]\s*", "", text)
    text = re.sub(r"^(?:\d+[\.\、\)]|[（(]\d+[)）])\s*", "", text)
    return text.strip()


def _strip_heading_prefix(value: str) -> str:
    return _strip_line_prefix(value).strip(":： ").strip()


def _contains_any(text: str, aliases: list[str]) -> bool:
    lower = text.lower()
    return any(alias.lower() in lower for alias in aliases)


def _first_value(payload: dict[str, object], keys: list[str]) -> object | None:
    for key in keys:
        if key in payload:
            return payload.get(key)

    lowered = {str(k).lower(): v for k, v in payload.items()}
    for key in keys:
        if key.lower() in lowered:
            return lowered[key.lower()]
    return None


def _extract_items_from_lines(lines: list[str], split_items: bool) -> list[str]:
    result: list[str] = []
    for line in lines:
        text = _normalize_line(line)
        if not text:
            continue
        if _looks_like_heading(text) and not _is_numbered_item(text):
            continue
        split = _split_items(text) if split_items else []
        if split_items and split:
            result.extend(split)
            continue
        result.append(_strip_line_prefix(text))
    return _unique([item for item in result if item])


def _extract_after_colon(line: str) -> str:
    if "：" in line:
        return line.split("：", 1)[1].strip()
    if ":" in line:
        return line.split(":", 1)[1].strip()
    return ""


def _looks_like_key_value_line(line: str) -> bool:
    return bool(re.match(r"^[^:：]{1,30}[:：]\s*.+$", _normalize_line(line)))


def _is_checklist_item(raw_line: str) -> bool:
    return bool(re.match(r"^\s*[-*]\s*\[[ xX]\]\s+.+$", raw_line))


def _extract_repo_names(text: str) -> list[str]:
    names = re.findall(r"\b[a-z][a-z0-9]+-[a-z0-9-]+\b", text.lower())
    return _unique(names)


def _trim_rule_text(text: str, max_chars: int = 8000) -> str:
    content = text.strip()
    if len(content) <= max_chars:
        return content
    return content[:max_chars] + "\n...（规范内容过长，已截断）"
