from __future__ import annotations

from typing import Any

from app.agents.development_planner import DevelopmentPlanner
from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput


class Developer:
    """资深开发工程师：按设计编码并规划单测覆盖。"""

    def __init__(self, development_planner: DevelopmentPlanner) -> None:
        self.development_planner = development_planner

    def build(
        self,
        requirement: RequirementInput,
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        context: ContextSnapshot,
        knowledge_input: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        plan = self.development_planner.build(
            requirement,
            design_doc,
            api_doc,
            impacts,
            context,
            knowledge_input=knowledge_input,
        )
        plan["unit_test_targets"] = [
            "核心业务服务层覆盖率 >= 90%",
            "接口层参数校验与异常分支覆盖",
            "幂等与重试路径覆盖",
        ]
        plan["coverage_target"] = ">=90%"
        plan["implementation_guardrails"] = [
            "严格遵循 FRD 中的目标、范围、约束与数据结构定义",
            "接口字段、错误码、超时策略与接口文档保持一致",
            "新增代码必须同时提交单元测试",
        ]
        return plan
