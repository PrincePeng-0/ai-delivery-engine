from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput
from app.utils import dump_json, load_json, now_iso, write_text


class KnowledgeBaseAdministrator:
    """领域知识库管理员，负责知识沉淀与技能资产累积。"""

    def __init__(self, knowledge_dir: str = "knowledge_base") -> None:
        self.knowledge_dir = Path(knowledge_dir)

    def load_context_knowledge(self, context: ContextSnapshot) -> dict[str, Any]:
        kb = self._load_or_init_kb(context)
        recent_requirements = kb.get("requirement_entries", [])[-5:]
        return {
            "domain_systems": [repo.name for repo in context.repos],
            "shared_tables": context.shared_tables,
            "recent_requirements": recent_requirements,
            "knowledge_version": kb.get("version", "1.0"),
            "updated_at": kb.get("updated_at", ""),
        }

    def persist_knowledge_and_skills(
        self,
        requirement_name: str,
        requirement: RequirementInput,
        impacts: list[ImpactItem],
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        context: ContextSnapshot,
    ) -> dict[str, str]:
        knowledge_dir = self.knowledge_dir
        skills_dir = knowledge_dir / "skills"
        kb_path = knowledge_dir / "Domain_Knowledge_Base.json"
        skills_catalog_path = knowledge_dir / "Domain_Skills_Catalog.md"
        skills_readme_path = knowledge_dir / "Domain_Knowledge_and_Skills.md"

        kb = self._load_or_init_kb(context)
        self._merge_context_snapshot(kb, context)
        entry = self._build_requirement_entry(requirement_name, requirement, impacts, design_doc, api_doc)
        self._upsert_requirement_entry(kb, entry)
        kb["updated_at"] = now_iso()
        dump_json(kb_path, kb)

        domain_skill_path = skills_dir / "Domain_Context_Skill.md"
        requirement_skill_path = skills_dir / f"{_safe_name(requirement_name)}_Skill.md"
        write_text(domain_skill_path, self._render_domain_skill(context))
        write_text(requirement_skill_path, self._render_requirement_skill(entry))
        write_text(skills_catalog_path, self._render_skills_catalog(kb, domain_skill_path, requirement_skill_path))
        write_text(
            skills_readme_path,
            self._render_knowledge_readme(
                kb_path=kb_path,
                catalog_path=skills_catalog_path,
                skills_dir=skills_dir,
            ),
        )
        display_root = "{{KNOWLEDGE_DIR}}"

        return {
            "knowledge_base": f"{display_root}/{kb_path.name}",
            "skills_catalog": f"{display_root}/{skills_catalog_path.name}",
            "skills_readme": f"{display_root}/{skills_readme_path.name}",
            "domain_skill": f"{display_root}/skills/{domain_skill_path.name}",
            "requirement_skill": f"{display_root}/skills/{requirement_skill_path.name}",
        }

    def _load_or_init_kb(self, context: ContextSnapshot) -> dict[str, Any]:
        kb_path = self.knowledge_dir / "Domain_Knowledge_Base.json"
        if kb_path.exists():
            try:
                payload = load_json(kb_path)
                if isinstance(payload, dict):
                    payload.setdefault("version", "1.0")
                    payload.setdefault("created_at", now_iso())
                    payload.setdefault("updated_at", now_iso())
                    payload.setdefault("domain", "DOMAIN_PLACEHOLDER")
                    payload.setdefault("systems", [])
                    payload.setdefault("shared_tables", {})
                    payload.setdefault("requirement_entries", [])
                    return payload
            except Exception:
                pass
        return {
            "version": "1.0",
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "domain": "DOMAIN_PLACEHOLDER",
            "systems": [repo.name for repo in context.repos],
            "shared_tables": context.shared_tables,
            "requirement_entries": [],
        }

    @staticmethod
    def _merge_context_snapshot(kb: dict[str, Any], context: ContextSnapshot) -> None:
        existing = set(kb.get("systems", []))
        for repo in context.repos:
            existing.add(repo.name)
        kb["systems"] = sorted(existing)

        merged_tables = dict(kb.get("shared_tables", {}))
        for table, repos in context.shared_tables.items():
            old = set(merged_tables.get(table, []))
            old.update(repos)
            merged_tables[table] = sorted(old)
        kb["shared_tables"] = merged_tables

    @staticmethod
    def _build_requirement_entry(
        requirement_name: str,
        requirement: RequirementInput,
        impacts: list[ImpactItem],
        design_doc: DesignDoc,
        api_doc: ApiDoc,
    ) -> dict[str, Any]:
        return {
            "source_name": requirement_name,
            "title": requirement.title,
            "recorded_at": now_iso(),
            "background": requirement.background,
            "goals": requirement.goals,
            "scope_in": requirement.scope_in,
            "scope_out": requirement.scope_out,
            "constraints": requirement.constraints,
            "acceptance_criteria": requirement.acceptance_criteria,
            "impacted_systems": [item.system for item in impacts],
            "impact_reasons": {item.system: item.reason for item in impacts},
            "architecture_focus": design_doc.data_model_notes[:8],
            "risks": design_doc.risks,
            "api_interfaces": [endpoint.interface for endpoint in api_doc.endpoints],
            "api_owners": sorted({endpoint.owner_system for endpoint in api_doc.endpoints}),
        }

    @staticmethod
    def _upsert_requirement_entry(kb: dict[str, Any], entry: dict[str, Any]) -> None:
        entries = kb.get("requirement_entries", [])
        if not isinstance(entries, list):
            entries = []
        filtered = [item for item in entries if item.get("source_name") != entry.get("source_name")]
        filtered.append(entry)
        kb["requirement_entries"] = filtered[-200:]

    @staticmethod
    def _render_domain_skill(context: ContextSnapshot) -> str:
        systems = ", ".join(sorted(repo.name for repo in context.repos)) or "无"
        shared_table_count = len(context.shared_tables)
        return (
            "# Domain Context Skill\n\n"
            "## 目标\n"
            "- 统一领域术语与系统边界。\n"
            "- 在需求分析阶段快速定位影响系统。\n"
            "- 在设计阶段复用共享数据模型与调用链经验。\n\n"
            "## 当前系统清单\n"
            f"- {systems}\n\n"
            "## 关键实践\n"
            "- 新需求必须先识别影响系统，再输出接口契约。\n"
            "- 所有写接口需定义幂等键和重试策略。\n"
            "- 共享表变更采用先加后切、可回滚策略。\n\n"
            "## 数据协同提醒\n"
            f"- 已识别共享表组数：{shared_table_count}\n"
        )

    @staticmethod
    def _render_requirement_skill(entry: dict[str, Any]) -> str:
        source_name = str(entry.get("source_name", "Requirement"))
        goals = entry.get("goals", [])
        impacted = entry.get("impacted_systems", [])
        interfaces = entry.get("api_interfaces", [])
        constraints = entry.get("constraints", [])
        acceptance = entry.get("acceptance_criteria", [])
        return (
            f"# {source_name} Skill\n\n"
            "## 适用场景\n"
            f"- 需求：{entry.get('title', source_name)}\n"
            f"- 影响系统：{', '.join(impacted) if impacted else '待补充'}\n\n"
            "## 关键目标\n"
            f"{_to_list(goals)}\n\n"
            "## 核心约束\n"
            f"{_to_list(constraints)}\n\n"
            "## 接口关注点\n"
            f"{_to_list(interfaces)}\n\n"
            "## 验收标准\n"
            f"{_to_list(acceptance)}\n"
        )

    @staticmethod
    def _render_skills_catalog(
        kb: dict[str, Any],
        domain_skill_path: Path,
        requirement_skill_path: Path,
    ) -> str:
        latest = kb.get("requirement_entries", [])[-10:]
        latest_lines = []
        for idx, item in enumerate(reversed(latest), start=1):
            latest_lines.append(
                f"{idx}. {item.get('source_name', '')} | {item.get('title', '')} | "
                f"{', '.join(item.get('impacted_systems', []))}"
            )
        latest_text = "\n".join(latest_lines) if latest_lines else "1. 暂无历史需求沉淀"
        return (
            "# Domain Skills Catalog\n\n"
            f"- Domain Skill: `{domain_skill_path.name}`\n"
            f"- Latest Requirement Skill: `{requirement_skill_path.name}`\n"
            f"- Requirement Entries: {len(kb.get('requirement_entries', []))}\n\n"
            "## 最近需求沉淀\n"
            f"{latest_text}\n"
        )

    @staticmethod
    def _render_knowledge_readme(
        kb_path: Path,
        catalog_path: Path,
        skills_dir: Path,
    ) -> str:
        return (
            "# 领域知识库与 Skills\n\n"
            "该目录用于累积领域知识与每次需求沉淀结果。\n\n"
            "## 文件说明\n"
            f"- `{kb_path.name}`：结构化知识库，累计系统信息与需求分析结论。\n"
            f"- `{catalog_path.name}`：Skills 索引与最近需求沉淀记录。\n"
            f"- `{skills_dir.name}/`：领域 skill 与需求专属 skill 文件。\n"
            "- `public_rules/`：公共规则库目录（使用者维护，执行时读取，不由本流程生成）。\n"
        )


def _safe_name(text: str) -> str:
    value = re.sub(r'[\\/:*?"<>|]+', "_", text.strip())
    return value or "Requirement"


def _to_list(items: list[str]) -> str:
    if not items:
        return "- 无"
    return "\n".join(f"- {item}" for item in items)
