from __future__ import annotations

import re
from typing import Any

from app.llm import (
    LLMClient,
    context_snapshot_brief,
    ensure_dict_list_str,
    ensure_str,
    ensure_str_list,
    impacts_brief,
    requirement_brief,
)
from app.schemas import ApiDoc, ApiEndpoint, ContextSnapshot, ImpactItem, RequirementInput


class ApiWriter:
    """按影响系统生成接口文档骨架（LLM 优先，规则回退）。"""

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        use_llm: bool = True,
        allow_fallback: bool = True,
        interface_document_rule: str = "",
    ) -> None:
        self.llm_client = llm_client
        self.use_llm = use_llm
        self.allow_fallback = allow_fallback
        self.interface_document_rule = interface_document_rule.strip()

    def build(
        self,
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        knowledge_input: dict[str, Any] | None = None,
    ) -> ApiDoc:
        if self.use_llm and self.llm_client and self.llm_client.is_ready:
            try:
                return self._build_with_llm(requirement, context, impacts, knowledge_input=knowledge_input)
            except Exception:
                if not self.allow_fallback:
                    raise

        if self.use_llm and self.llm_client and not self.llm_client.is_ready and not self.allow_fallback:
            raise RuntimeError("LLM is not ready and fallback is disabled.")

        return self._build_with_rules(requirement, context, impacts, knowledge_input=knowledge_input)

    def _build_with_llm(
        self,
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        knowledge_input: dict[str, Any] | None = None,
    ) -> ApiDoc:
        assert self.llm_client is not None
        base_doc = self._build_with_rules(requirement, context, impacts, knowledge_input=knowledge_input)

        system_prompt = (
            "你是资深接口架构师。"
            "请根据需求和系统上下文生成接口文档 JSON。"
            "只允许输出 JSON 对象，不要输出代码块。"
        )
        if self.interface_document_rule:
            system_prompt += (
                "\n你必须严格遵守以下《接口文档规范》，"
                "确保字段完整、测试用例充分、并可用于 Postman/Apifox 导入：\n"
                f"{_trim_rule_text(self.interface_document_rule)}"
            )
        knowledge_hint = _knowledge_hint_text(knowledge_input)
        user_prompt = (
            "输出结构：\n"
            "{\n"
            '  "title": "string",\n'
            '  "overview": "string",\n'
            '  "endpoints": [\n'
            "    {\n"
            '      "name": "string",\n'
            '      "owner_system": "system-xxx",\n'
            '      "protocol": "RPC|HTTP|MQ",\n'
            '      "interface": "string",\n'
            '      "scenario": "string",\n'
            '      "consumers": ["string"],\n'
            '      "request_fields": [{"name":"", "type":"", "required":"Y|N", "desc":""}],\n'
            '      "response_fields": [{"name":"", "type":"", "desc":""}],\n'
            '      "error_codes": [{"code":"", "desc":""}],\n'
            '      "idempotency": "string",\n'
            '      "timeout_ms": 3000,\n'
            '      "retry_policy": "string",\n'
            '      "notes": "string"\n'
            "    }\n"
            "  ],\n"
            '  "common_errors": [{"code":"", "desc":""}],\n'
            '  "common_policy": ["string"]\n'
            "}\n\n"
            "约束：\n"
            "- owner_system 必须来自影响系统\n"
            "- 每个 endpoint 必须含请求字段、响应字段、错误码\n"
            "- 超时单位毫秒，范围 100~60000\n\n"
            f"requirement:\n{requirement_brief(requirement)}\n\n"
            f"impacts:\n{impacts_brief(impacts)}\n\n"
            f"context_brief:\n{context_snapshot_brief(context)}\n"
            f"\npublic_knowledge_hint:\n{knowledge_hint}\n"
        )
        payload = self.llm_client.generate_json(system_prompt=system_prompt, user_prompt=user_prompt)
        if not isinstance(payload, dict):
            raise ValueError("API writer expects a JSON object.")

        impacted_systems = {item.system for item in impacts}
        endpoints = self._normalize_endpoints(payload.get("endpoints"), impacted_systems)
        if not endpoints:
            endpoints = base_doc.endpoints

        common_errors = ensure_dict_list_str(payload.get("common_errors")) or base_doc.common_errors
        common_policy = ensure_str_list(payload.get("common_policy")) or base_doc.common_policy

        overview = ensure_str(payload.get("overview"))
        if not overview:
            overview = (
                f"需求《{requirement.title}》识别到 {len(endpoints)} 个关键接口。"
                f" 影响系统：{', '.join(item.system for item in impacts) if impacts else '无'}。"
            )

        return ApiDoc(
            title=ensure_str(payload.get("title"), base_doc.title),
            overview=overview,
            endpoints=endpoints,
            common_errors=common_errors,
            common_policy=common_policy,
        )

    def _normalize_endpoints(self, value: object, impacted_systems: set[str]) -> list[ApiEndpoint]:
        if not isinstance(value, list):
            return []

        endpoints: list[ApiEndpoint] = []
        for item in value:
            if not isinstance(item, dict):
                continue
            endpoint = self._normalize_endpoint(item, impacted_systems)
            if endpoint is not None:
                endpoints.append(endpoint)
        return endpoints

    def _normalize_endpoint(self, item: dict[str, object], impacted_systems: set[str]) -> ApiEndpoint | None:
        owner_system = ensure_str(item.get("owner_system"))
        if not owner_system or (impacted_systems and owner_system not in impacted_systems):
            return None

        name = ensure_str(item.get("name"))
        interface = ensure_str(item.get("interface"))
        if not name or not interface:
            return None

        request_fields = ensure_dict_list_str(item.get("request_fields"))
        response_fields = ensure_dict_list_str(item.get("response_fields"))
        error_codes = ensure_dict_list_str(item.get("error_codes"))
        if not request_fields or not response_fields or not error_codes:
            return None

        return ApiEndpoint(
            name=name,
            owner_system=owner_system,
            protocol=ensure_str(item.get("protocol"), "RPC"),
            interface=interface,
            scenario=ensure_str(item.get("scenario"), "需求场景待补充"),
            consumers=ensure_str_list(item.get("consumers")) or ["TBD"],
            request_fields=request_fields,
            response_fields=response_fields,
            error_codes=error_codes,
            idempotency=ensure_str(item.get("idempotency"), "需在详细设计中补充幂等策略"),
            timeout_ms=self._to_timeout_ms(item.get("timeout_ms")),
            retry_policy=ensure_str(item.get("retry_policy"), "需在详细设计中补充重试策略"),
            notes=ensure_str(item.get("notes")),
        )

    @staticmethod
    def _to_timeout_ms(value: object) -> int:
        try:
            parsed = int(float(str(value)))
        except Exception:
            return 3000
        return min(max(parsed, 100), 60000)

    def _build_with_rules(
        self,
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        knowledge_input: dict[str, Any] | None = None,
    ) -> ApiDoc:
        impacted_systems = [item.system for item in impacts]
        endpoints: list[ApiEndpoint] = []
        for system in impacted_systems:
            endpoints.append(self._build_generic_endpoint(system, impacted_systems))

        if not endpoints:
            endpoints.append(self._build_generic_endpoint("system-core", []))

        common_errors = [
            {"code": "SUCCESS", "desc": "调用成功"},
            {"code": "INVALID_PARAM", "desc": "参数校验失败"},
            {"code": "TIMEOUT", "desc": "调用超时"},
            {"code": "SYSTEM_ERROR", "desc": "系统异常"},
        ]
        common_policy = [
            "鉴权：敏感接口需补充调用方白名单或签名机制。",
            "幂等：写接口必须明确幂等键（如 requestId/orderId/bizId）。",
            "重试：区分可重试错误与业务拒绝错误，避免无效重放。",
            "日志：所有跨服务调用统一透传 traceId/requestId。",
        ]
        common_policy.extend(_extract_interface_policies(knowledge_input))

        overview = (
            f"需求《{requirement.title}》识别到 {len(endpoints)} 个关键接口。"
            f" 影响系统：{', '.join(impacted_systems) if impacted_systems else '无'}。"
            f" 上下文系统总数：{len(context.repos)}。"
        )

        return ApiDoc(
            title=f"{requirement.title} - 接口文档",
            overview=overview,
            endpoints=endpoints,
            common_errors=common_errors,
            common_policy=common_policy,
        )

    @staticmethod
    def _build_generic_endpoint(system: str, impacted_systems: list[str]) -> ApiEndpoint:
        service_name = _to_pascal(system)
        consumers = [item for item in impacted_systems if item != system][:3] or ["TBD"]
        return ApiEndpoint(
            name=f"{system} 核心业务接口",
            owner_system=system,
            protocol="RPC",
            interface=f"{service_name}Service.execute",
            scenario=f"{system} 提供核心业务能力给上下游系统调用",
            consumers=consumers,
            request_fields=[
                {"name": "requestId", "type": "string", "required": "Y", "desc": "请求唯一标识"},
                {"name": "bizId", "type": "string", "required": "Y", "desc": "业务唯一标识"},
                {"name": "payload", "type": "object", "required": "Y", "desc": "业务请求体"},
            ],
            response_fields=[
                {"name": "code", "type": "string", "desc": "结果码"},
                {"name": "message", "type": "string", "desc": "结果描述"},
                {"name": "data", "type": "object", "desc": "响应数据"},
            ],
            error_codes=[
                {"code": "SUCCESS", "desc": "成功"},
                {"code": "INVALID_PARAM", "desc": "参数错误"},
                {"code": "SYSTEM_ERROR", "desc": "系统错误"},
            ],
            idempotency="使用 requestId + bizId 作为幂等键",
            timeout_ms=5000,
            retry_policy="仅对可重试错误进行指数退避重试，最多 2 次",
            notes="请在详细设计阶段补充字段级约束、错误码细分和降级策略。",
        )


def _to_pascal(name: str) -> str:
    parts = [part for part in re.split(r"[-_/.]+", name) if part]
    return "".join(part[:1].upper() + part[1:] for part in parts) or "System"


def _trim_rule_text(text: str, max_chars: int = 8000) -> str:
    content = text.strip()
    if len(content) <= max_chars:
        return content
    return content[:max_chars] + "\n...（规范内容过长，已截断）"


def _knowledge_hint_text(knowledge_input: dict[str, Any] | None, max_items: int = 6) -> str:
    if not knowledge_input:
        return "无"
    rows: list[str] = []
    source = str(knowledge_input.get("public_kb_source", "")).strip()
    namespace = str(knowledge_input.get("public_kb_namespace", "")).strip()
    if source:
        rows.append(f"- source: {source}")
    if namespace:
        rows.append(f"- namespace: {namespace}")

    patterns = _to_text_items(knowledge_input.get("public_interface_patterns"))[:max_items]
    if patterns:
        rows.append("- interface_patterns:")
        rows.extend(f"  - {item}" for item in patterns)

    references = _to_text_items(knowledge_input.get("public_references"))[:max_items]
    if references:
        rows.append("- references:")
        rows.extend(f"  - {item}" for item in references)

    return "\n".join(rows) if rows else "无"


def _extract_interface_policies(knowledge_input: dict[str, Any] | None, limit: int = 5) -> list[str]:
    if not knowledge_input:
        return []
    patterns = _to_text_items(knowledge_input.get("public_interface_patterns"))[:limit]
    return [f"公共知识建议：{item}" for item in patterns]


def _to_text_items(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    output: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            output.append(text)
    return output
