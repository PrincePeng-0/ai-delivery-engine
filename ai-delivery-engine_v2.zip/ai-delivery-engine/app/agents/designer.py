from __future__ import annotations

from typing import Any

from app.agents.api_writer import ApiWriter
from app.agents.design_writer import DesignWriter
from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput


class Designer:
    """资深架构师：负责架构设计、数据模型、任务拆解与开发计划输入。"""

    def __init__(
        self,
        design_writer: DesignWriter,
        api_writer: ApiWriter,
    ) -> None:
        self.design_writer = design_writer
        self.api_writer = api_writer

    def design(
        self,
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        knowledge_input: dict[str, Any] | None = None,
    ) -> tuple[DesignDoc, ApiDoc]:
        design_doc = self.design_writer.build(requirement, context, impacts, knowledge_input=knowledge_input)
        api_doc = self.api_writer.build(requirement, context, impacts, knowledge_input=knowledge_input)
        return design_doc, api_doc
