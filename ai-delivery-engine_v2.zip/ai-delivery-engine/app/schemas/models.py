from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class RequirementInput:
    title: str
    background: str
    goals: list[str] = field(default_factory=list)
    scope_in: list[str] = field(default_factory=list)
    scope_out: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    acceptance_criteria: list[str] = field(default_factory=list)
    raw_text: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "RequirementInput":
        return RequirementInput(**data)


@dataclass
class RepoProfile:
    name: str
    path: str
    modules: list[str] = field(default_factory=list)
    port: str = ""
    datasources: list[str] = field(default_factory=list)
    dubbo_providers: list[str] = field(default_factory=list)
    dubbo_references: list[str] = field(default_factory=list)
    tables: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "RepoProfile":
        return RepoProfile(**data)


@dataclass
class ContextSnapshot:
    generated_at: str
    project_root: str
    repos: list[RepoProfile] = field(default_factory=list)
    shared_tables: dict[str, list[str]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        return data

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "ContextSnapshot":
        repos = [RepoProfile.from_dict(item) for item in data.get("repos", [])]
        project_root = data.get("project_root", "")
        if not project_root:
            for key, value in data.items():
                if str(key).lower().endswith("_root") and isinstance(value, str):
                    project_root = value
                    break
        return ContextSnapshot(
            generated_at=data.get("generated_at", ""),
            project_root=project_root,
            repos=repos,
            shared_tables=data.get("shared_tables", {}),
        )


@dataclass
class ImpactItem:
    system: str
    reason: str
    changes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class SequenceDiagram:
    title: str
    mermaid: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class DesignDoc:
    title: str
    background: str
    goals: list[str]
    scope_in: list[str]
    scope_out: list[str]
    constraints: list[str]
    assumptions: list[str]
    impacts: list[ImpactItem]
    architecture_diagram: str
    sequence_diagrams: list[SequenceDiagram]
    data_model_notes: list[str]
    test_plan: list[str]
    release_plan: list[str]
    risks: list[str]
    context_summary: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "background": self.background,
            "goals": self.goals,
            "scope_in": self.scope_in,
            "scope_out": self.scope_out,
            "constraints": self.constraints,
            "assumptions": self.assumptions,
            "impacts": [item.to_dict() for item in self.impacts],
            "architecture_diagram": self.architecture_diagram,
            "sequence_diagrams": [item.to_dict() for item in self.sequence_diagrams],
            "data_model_notes": self.data_model_notes,
            "test_plan": self.test_plan,
            "release_plan": self.release_plan,
            "risks": self.risks,
            "context_summary": self.context_summary,
        }


@dataclass
class ApiEndpoint:
    name: str
    owner_system: str
    protocol: str
    interface: str
    scenario: str
    consumers: list[str] = field(default_factory=list)
    request_fields: list[dict[str, str]] = field(default_factory=list)
    response_fields: list[dict[str, str]] = field(default_factory=list)
    error_codes: list[dict[str, str]] = field(default_factory=list)
    idempotency: str = ""
    timeout_ms: int = 3000
    retry_policy: str = ""
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ApiDoc:
    title: str
    overview: str
    endpoints: list[ApiEndpoint]
    common_errors: list[dict[str, str]]
    common_policy: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "overview": self.overview,
            "endpoints": [item.to_dict() for item in self.endpoints],
            "common_errors": self.common_errors,
            "common_policy": self.common_policy,
        }


@dataclass
class ValidationReport:
    passed: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    checks: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
