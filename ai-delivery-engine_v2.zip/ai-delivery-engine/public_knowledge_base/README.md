# 公共知识库（示例）

该目录是面向多项目复用的公共知识库样例，供 `AI Delivery Engine` 在需求分析和方案设计阶段读取。

## 使用说明

1. 使用方维护本目录内容（建议接入统一知识平台后改为 remote/hybrid 模式）。
2. `generate` 时通过 `--kb-mode local --kb-dir public_knowledge_base` 读取。
3. 若启用 `--strict-kb`，目录缺失或格式错误会导致流程直接失败。

## 最小文件

- `public_knowledge_snapshot.json`

可扩展字段请参考快照中的结构定义。

## 运行期目录（local 模式自动生成）

- `drafts/`：草稿回写区（状态默认 `PENDING_REVIEW`）
- `audit/audit_log.jsonl`：读写审计日志

可使用命令更新审批状态：

```bash
ai-delivery-engine kb-review \
  --draft-id <DRAFT_ID> \
  --approval-status APPROVED \
  --reviewer <REVIEWER> \
  --kb-mode local \
  --kb-dir public_knowledge_base
```
