# 公共规则库索引

该规则库用于沉淀跨项目可复用的交付规范，默认由 WorkflowManager 协调各角色按规范执行。

## 目录
- `Requirement_Analysis_Report_Standard.md`：需求分析报告规范。
- `Technical_Design_Document_Standard.md`：技术开发文档编写规范。
- `Interface_Document_Standard.md`：接口文档规范（含测试与导入约束）。
- `Code_Development_Standard.md`：代码编写规范。
- `Quality_Gate_Policy.json`：质量门禁策略（PASS/WARN/BLOCK 阈值与评分权重）。

## 角色使用建议
- RequirementAnalyzer：严格遵循需求分析报告规范，确保背景/目标/范围/约束/验收标准完整。
- Designer：遵循技术开发文档规范和接口文档规范，输出架构、数据模型、接口契约。
- Developer：遵循代码编写规范实现功能，并保证单元测试覆盖目标。
- Tester / Reviewer：以规则库为检查清单执行质量门禁，并按 `Quality_Gate_Policy.json` 输出决策与修复建议。
