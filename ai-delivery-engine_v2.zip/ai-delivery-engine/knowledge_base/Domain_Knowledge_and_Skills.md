# 领域知识库与 Skills

该目录用于累积领域知识与每次需求沉淀结果。

## 文件说明
- `Domain_Knowledge_Base.json`：结构化知识库，累计系统信息与需求分析结论。
- `Domain_Skills_Catalog.md`：Skills 索引与最近需求沉淀记录。
- `skills/`：领域 skill 与需求专属 skill 文件。
- `public_rules/`：公共规则库目录（使用者维护，执行时读取，不由本流程生成）。
