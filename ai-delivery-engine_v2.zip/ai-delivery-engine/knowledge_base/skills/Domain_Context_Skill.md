# Domain Context Skill

## 目标
- 统一领域术语与系统边界。
- 在需求分析阶段快速定位影响系统。
- 在设计阶段复用共享数据模型与调用链经验。

## 当前系统清单
- vcc-bill, vcc-cardcenter, vcc-channel, vcc-chargecenter, vcc-common, vcc-gateway, vcc-oms, vcc-risk, vcc-transcenter, vcc-usercenter

## 关键实践
- 新需求必须先识别影响系统，再输出接口契约。
- 所有写接口需定义幂等键和重试策略。
- 共享表变更采用先加后切、可回滚策略。

## 数据协同提醒
- 已识别共享表组数：16
