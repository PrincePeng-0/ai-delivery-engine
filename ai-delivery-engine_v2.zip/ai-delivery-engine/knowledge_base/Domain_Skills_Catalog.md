# Domain Skills Catalog

- Domain Skill: `Domain_Context_Skill.md`
- Latest Requirement Skill: `card-center-refactor_Skill.md`
- Requirement Entries: 2

## 最近需求沉淀
1. card-center-refactor | 卡产品中心独立能力建设 | vcc-cardcenter, vcc-oms, vcc-common
2. requirement_sample | 统一交易状态追踪能力建设 | vcc-bill, vcc-gateway, vcc-risk
