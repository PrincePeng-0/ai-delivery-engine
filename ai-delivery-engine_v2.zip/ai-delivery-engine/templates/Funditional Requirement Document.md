# {{frd_title}}

# 一、文档概述

## 1.1 文档目的

{{document_purpose}}

## 1.2 适用范围

{{applicable_scope_md}}

## 1.3 项目关联

{{project_links_md}}

## 1.4 文档版本

{{version_table_md}}

# 二、总体功能概述

## 2.1 软件定位

{{software_positioning}}

## 2.2 核心功能模块划分

{{core_modules_table_md}}

## 2.3 架构设计图

```mermaid
{{architecture_diagram}}
```

## 2.4 设计原则

{{design_principles_md}}

# 三、详细功能设计（核心模块）

{{detailed_function_design_md}}

# 四、数据设计

## 4.1 数据库设计总览

{{database_overview_table_md}}

## 4.2 核心数据实体

{{data_entities_table_md}}

## 4.3 数据关联

{{data_relations_md}}

## 4.4 ER图

```mermaid
{{er_diagram}}
```

## 4.5 数据存储与访问规则

{{data_storage_rules_md}}

# 五、接口设计（简要）

{{interface_overview_table_md}}

# 六、异常处理设计

{{exception_table_md}}

# 七、测试要点（参考）

{{test_points_md}}

# 八、约束与限制

{{constraints_limits_md}}

# 九、附件

{{attachments_md}}

# 十、签字确认

{{signoff_table_md}}

> （注：文档部分内容可能由 AI 生成）
