# {{requirement_title}} - 需求分析报告

# 一、报告概述

## 1.1 报告目的

{{report_purpose}}

## 1.2 项目背景

{{project_background}}

## 1.3 报告范围

{{report_scope_md}}

## 1.4 文档版本

{{document_version_table_md}}

# 二、需求来源与用户分析

## 2.1 需求来源

{{requirement_sources_md}}

## 2.2 用户分析

{{user_analysis_md}}

## 2.3 知识库补充分析

{{knowledge_summary_table_md}}

### 需求模式补充

{{requirement_pattern_table_md}}

### 历史案例补充

{{recent_case_table_md}}

### 语义检索高相关条目

{{hit_table_md}}

### 基于知识库的补充建议

{{kb_supplement_suggestions_md}}

# 三、核心需求描述

## 3.1 业务需求

{{business_requirements_md}}

## 3.2 功能需求

{{functional_requirements_table_md}}

## 3.3 非功能需求

{{non_functional_requirements_md}}

# 四、需求优先级划分

{{priority_table_md}}

# 五、需求约束与假设

## 5.1 需求约束

{{constraint_table_md}}

## 5.2 前提假设

{{assumptions_md}}

# 六、需求确认与分歧说明

{{confirmation_and_disputes_md}}

# 七、风险分析与应对措施

{{risk_table_md}}

# 八、后续工作计划

{{follow_up_plan_md}}

# 九、附件

{{attachments_md}}

# 十、签字确认

{{signoff_table_md}}

> （注：文档部分内容可能由 AI 生成）
