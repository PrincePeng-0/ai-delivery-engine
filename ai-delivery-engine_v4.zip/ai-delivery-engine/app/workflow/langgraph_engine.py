from __future__ import annotations

import time
from typing import Any, Callable, TypedDict

from app.kb import PublicKnowledgeContext
from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput, ValidationReport
from app.workflow.engine import AIDeliveryEngineWorkflow, WorkflowResult, _elapsed_ms

try:
    from langgraph.graph import END, StateGraph
except Exception:  # pragma: no cover - optional dependency is resolved at runtime
    END = None
    StateGraph = None


class LangGraphWorkflowState(TypedDict, total=False):
    requirement_text: str
    context: ContextSnapshot
    requirement_name: str
    run_started: float
    response_latency_ms: float
    stage_durations_ms: dict[str, float]
    node_traces: list[dict[str, Any]]

    public_knowledge_ctx: PublicKnowledgeContext
    knowledge_input: dict[str, Any]
    requirement: RequirementInput
    impacts: list[ImpactItem]
    requirement_breakdown: list[dict[str, str]]
    design_doc: DesignDoc
    api_doc: ApiDoc
    coding_plan: dict[str, Any]
    testing_plan: dict[str, Any]
    unit_test_report: dict[str, Any]
    validation: ValidationReport
    lifecycle_review: dict[str, Any]
    knowledge_assets: dict[str, str]
    public_kb_draft: dict[str, str]
    public_kb_audit: list[dict[str, str]]
    quality_report: dict[str, Any]
    quality_gate: dict[str, Any]
    result: WorkflowResult


class LangGraphAIDeliveryEngineWorkflow(AIDeliveryEngineWorkflow):
    """基于 LangGraph 的流程编排器。

    说明：
    - 复用现有 5 核心角色 Agent 与质量评估逻辑；
    - 通过 StateGraph 将阶段拆解为显式节点，便于后续扩展分支/人工介入；
    - 对外接口与经典编排器保持一致（`run` 返回 `WorkflowResult`）。
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        if StateGraph is None or END is None:
            raise RuntimeError(
                "LangGraph is not available. Please install dependency `langgraph` first."
            )
        self._graph = self._build_graph()

    def _build_graph(self) -> Any:
        graph = StateGraph(LangGraphWorkflowState)
        graph.add_node("knowledge_bootstrap", self._node_knowledge_bootstrap)
        graph.add_node("ba_analysis", self._node_ba_analysis)
        graph.add_node("solution_design", self._node_solution_design)
        graph.add_node("coding_planning", self._node_coding_planning)
        graph.add_node("qa_planning", self._node_qa_planning)
        graph.add_node("review", self._node_review)
        graph.add_node("knowledge_persist", self._node_knowledge_persist)
        graph.add_node("public_kb_submit", self._node_public_kb_submit)
        graph.add_node("public_kb_audit", self._node_public_kb_audit)
        graph.add_node("quality_gate", self._node_quality_gate)
        graph.add_node("finalize", self._node_finalize)

        graph.set_entry_point("knowledge_bootstrap")
        graph.add_edge("knowledge_bootstrap", "ba_analysis")
        graph.add_edge("ba_analysis", "solution_design")
        graph.add_edge("solution_design", "coding_planning")
        graph.add_edge("coding_planning", "qa_planning")
        graph.add_edge("qa_planning", "review")
        graph.add_edge("review", "knowledge_persist")
        graph.add_edge("knowledge_persist", "public_kb_submit")
        graph.add_edge("public_kb_submit", "public_kb_audit")
        graph.add_edge("public_kb_audit", "quality_gate")
        graph.add_edge("quality_gate", "finalize")
        graph.add_edge("finalize", END)
        return graph.compile()

    @staticmethod
    def _with_stage_duration(state: LangGraphWorkflowState, stage_key: str, started: float) -> dict[str, float]:
        durations = dict(state.get("stage_durations_ms", {}))
        durations[stage_key] = _elapsed_ms(started)
        return durations

    @staticmethod
    def _with_node_trace(
        state: LangGraphWorkflowState,
        *,
        node_name: str,
        stage_key: str,
        attempt: int,
        status: str,
        duration_ms: float,
        error: str = "",
    ) -> list[dict[str, Any]]:
        traces = list(state.get("node_traces", []))
        traces.append(
            {
                "node": node_name,
                "stage_key": stage_key,
                "attempt": attempt,
                "status": status,
                "duration_ms": round(duration_ms, 2),
                "error": error,
            }
        )
        return traces

    @staticmethod
    def _build_retry_summary(node_traces: list[dict[str, Any]]) -> dict[str, dict[str, int]]:
        summary: dict[str, dict[str, int]] = {}
        for item in node_traces:
            node_name = str(item.get("node", "")).strip()
            if not node_name:
                continue
            node_status = str(item.get("status", "")).upper()
            node_stats = summary.setdefault(
                node_name,
                {
                    "attempts": 0,
                    "success": 0,
                    "failed": 0,
                    "retries": 0,
                },
            )
            node_stats["attempts"] += 1
            if node_status == "SUCCESS":
                node_stats["success"] += 1
            elif node_status == "FAILED":
                node_stats["failed"] += 1
        for node_stats in summary.values():
            node_stats["retries"] = max(0, node_stats["attempts"] - 1)
        return summary

    def _run_node_with_retry(
        self,
        state: LangGraphWorkflowState,
        *,
        node_name: str,
        stage_key: str,
        action: Callable[[], dict[str, Any]],
    ) -> LangGraphWorkflowState:
        """执行单个节点并应用重试策略。

        设计说明：
        - 该方法只负责节点执行重试与可观测数据记录，不承载业务逻辑；
        - 每次尝试都会记录 trace，便于后续质量评估与问题定位；
        - stage duration 记录的是节点整体耗时（包含失败重试与退避等待）。
        """
        stage_started = time.perf_counter()
        max_attempts = max(1, int(self.node_retry_max_attempts))
        backoff_ms = max(0, int(self.node_retry_backoff_ms))
        current_state = dict(state)
        last_error: Exception | None = None

        for attempt in range(1, max_attempts + 1):
            attempt_started = time.perf_counter()
            try:
                payload = action()
                merged = dict(payload)
                merged["stage_durations_ms"] = self._with_stage_duration(state, stage_key, stage_started)
                merged["node_traces"] = self._with_node_trace(
                    current_state,
                    node_name=node_name,
                    stage_key=stage_key,
                    attempt=attempt,
                    status="SUCCESS",
                    duration_ms=_elapsed_ms(attempt_started),
                )
                return merged
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                current_state["node_traces"] = self._with_node_trace(
                    current_state,
                    node_name=node_name,
                    stage_key=stage_key,
                    attempt=attempt,
                    status="FAILED",
                    duration_ms=_elapsed_ms(attempt_started),
                    error=str(exc),
                )
                if attempt >= max_attempts:
                    break
                if backoff_ms > 0:
                    time.sleep((backoff_ms * attempt) / 1000.0)

        error_message = str(last_error) if last_error is not None else "unknown error"
        raise RuntimeError(
            f"LangGraph node `{node_name}` failed after {max_attempts} attempt(s): {error_message}"
        ) from last_error

    def _node_knowledge_bootstrap(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        return self._run_node_with_retry(
            state,
            node_name="knowledge_bootstrap",
            stage_key="knowledge_bootstrap_ms",
            action=lambda: self._node_knowledge_bootstrap_action(state),
        )

    def _node_knowledge_bootstrap_action(self, state: LangGraphWorkflowState) -> dict[str, Any]:
        context = state["context"]
        requirement_text = state["requirement_text"]
        private_knowledge = self.knowledge_base_administrator.load_context_knowledge(context)
        public_knowledge = self._load_public_knowledge(requirement_text=requirement_text, context=context)
        knowledge_input = self._merge_knowledge_input(private_knowledge, public_knowledge)
        return {
            "public_knowledge_ctx": public_knowledge,
            "knowledge_input": knowledge_input,
        }

    def _node_ba_analysis(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        correction_feedback: list[str] = []

        def _action() -> dict[str, Any]:
            stage_knowledge = self._with_stage_correction_knowledge(
                knowledge_input=state.get("knowledge_input", {}),
                stage_name="ba",
                feedback=correction_feedback,
            )
            requirement, impacts, requirement_breakdown = self.ba.analyze(
                requirement_text=state["requirement_text"],
                context=state["context"],
                knowledge_input=stage_knowledge,
            )
            requirement_review = self.reviewer.review_requirement(
                requirement=requirement,
                impacts=impacts,
                context=state["context"],
            )
            if not requirement_review.passed:
                correction_feedback[:] = self._build_stage_feedback("ba", requirement_review)
                summary = "; ".join(correction_feedback[:3]) or "需求分析阶段评审未通过。"
                raise RuntimeError(summary)
            return {
                "requirement": requirement,
                "impacts": impacts,
                "requirement_breakdown": requirement_breakdown,
                "response_latency_ms": _elapsed_ms(state["run_started"]),
            }

        return self._run_node_with_retry(
            state,
            node_name="ba_analysis",
            stage_key="ba_analysis_ms",
            action=_action,
        )

    def _node_solution_design(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        correction_feedback: list[str] = []

        def _action() -> dict[str, Any]:
            stage_knowledge = self._with_stage_correction_knowledge(
                knowledge_input=state.get("knowledge_input", {}),
                stage_name="architecture",
                feedback=correction_feedback,
            )
            design_doc, api_doc = self.architecture.design(
                state["requirement"],
                state["context"],
                state["impacts"],
                knowledge_input=stage_knowledge,
            )
            architecture_review = self.reviewer.review_architecture(
                design_doc=design_doc,
                api_doc=api_doc,
                impacts=state["impacts"],
                context=state["context"],
            )
            if not architecture_review.passed:
                correction_feedback[:] = self._build_stage_feedback("architecture", architecture_review)
                summary = "; ".join(correction_feedback[:3]) or "架构阶段评审未通过。"
                raise RuntimeError(summary)
            return {
                "design_doc": design_doc,
                "api_doc": api_doc,
            }

        return self._run_node_with_retry(
            state,
            node_name="solution_design",
            stage_key="solution_design_ms",
            action=_action,
        )

    def _node_coding_planning(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        correction_feedback: list[str] = []

        def _action() -> dict[str, Any]:
            stage_knowledge = self._with_stage_correction_knowledge(
                knowledge_input=state.get("knowledge_input", {}),
                stage_name="developer",
                feedback=correction_feedback,
            )
            coding_plan = self.developer.build(
                state["requirement"],
                state["design_doc"],
                state["api_doc"],
                state["impacts"],
                state["context"],
                knowledge_input=stage_knowledge,
            )
            developer_review = self.reviewer.review_developer(
                coding_plan=coding_plan,
                impacts=state["impacts"],
            )
            if not developer_review.passed:
                correction_feedback[:] = self._build_stage_feedback("developer", developer_review)
                summary = "; ".join(correction_feedback[:3]) or "开发计划阶段评审未通过。"
                raise RuntimeError(summary)
            return {"coding_plan": coding_plan}

        return self._run_node_with_retry(
            state,
            node_name="coding_planning",
            stage_key="coding_planning_ms",
            action=_action,
        )

    def _node_qa_planning(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        correction_feedback: list[str] = []

        def _action() -> dict[str, Any]:
            stage_coding_plan = self._with_stage_correction_coding_plan(
                coding_plan=state["coding_plan"],
                stage_name="qa",
                feedback=correction_feedback,
            )
            testing_plan, unit_test_report = self.qa.build(
                state["requirement"],
                state["api_doc"],
                state["impacts"],
                stage_coding_plan,
            )
            qa_review = self.reviewer.review_qa(
                testing_plan=testing_plan,
                unit_test_report=unit_test_report,
                coding_plan=state["coding_plan"],
            )
            if not qa_review.passed:
                correction_feedback[:] = self._build_stage_feedback("qa", qa_review)
                summary = "; ".join(correction_feedback[:3]) or "测试计划阶段评审未通过。"
                raise RuntimeError(summary)
            return {
                "testing_plan": testing_plan,
                "unit_test_report": unit_test_report,
            }

        return self._run_node_with_retry(
            state,
            node_name="qa_planning",
            stage_key="qa_planning_ms",
            action=_action,
        )

    def _node_review(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        return self._run_node_with_retry(
            state,
            node_name="review",
            stage_key="review_ms",
            action=lambda: self._node_review_action(state),
        )

    def _node_review_action(self, state: LangGraphWorkflowState) -> dict[str, Any]:
        validation, lifecycle_review = self.reviewer.review_lifecycle(
            requirement=state["requirement"],
            design_doc=state["design_doc"],
            api_doc=state["api_doc"],
            impacts=state["impacts"],
            context=state["context"],
            coding_plan=state["coding_plan"],
            testing_plan=state["testing_plan"],
            unit_test_report=state["unit_test_report"],
        )
        return {"validation": validation, "lifecycle_review": lifecycle_review}

    def _node_knowledge_persist(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        return self._run_node_with_retry(
            state,
            node_name="knowledge_persist",
            stage_key="knowledge_persist_ms",
            action=lambda: self._node_knowledge_persist_action(state),
        )

    def _node_knowledge_persist_action(self, state: LangGraphWorkflowState) -> dict[str, Any]:
        knowledge_assets = self.knowledge_base_administrator.persist_knowledge_and_skills(
            requirement_name=state["requirement_name"],
            requirement=state["requirement"],
            impacts=state["impacts"],
            design_doc=state["design_doc"],
            api_doc=state["api_doc"],
            context=state["context"],
        )
        return {"knowledge_assets": knowledge_assets}

    def _node_public_kb_submit(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        return self._run_node_with_retry(
            state,
            node_name="public_kb_submit",
            stage_key="public_kb_submit_ms",
            action=lambda: self._node_public_kb_submit_action(state),
        )

    def _node_public_kb_submit_action(self, state: LangGraphWorkflowState) -> dict[str, Any]:
        public_kb_draft = self._submit_public_kb_draft(
            requirement_name=state["requirement_name"],
            requirement=state["requirement"],
            impacts=state["impacts"],
            design_doc=state["design_doc"],
            api_doc=state["api_doc"],
            context=state["context"],
            public_knowledge=state["public_knowledge_ctx"],
        )
        return {"public_kb_draft": public_kb_draft}

    def _node_public_kb_audit(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        return self._run_node_with_retry(
            state,
            node_name="public_kb_audit",
            stage_key="public_kb_audit_ms",
            action=lambda: self._node_public_kb_audit_action(),
        )

    def _node_public_kb_audit_action(self) -> dict[str, Any]:
        public_kb_audit = self._read_public_kb_audit(limit=20)
        return {"public_kb_audit": public_kb_audit}

    def _node_quality_gate(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        node_state = self._run_node_with_retry(
            state,
            node_name="quality_gate",
            stage_key="quality_gate_ms",
            action=lambda: self._node_quality_gate_action(state),
        )
        # 把当前节点（quality_gate）成功后的 trace 回填到 runtime_stats，
        # 便于外层直接消费完整的“截至质量门禁节点”为止的执行轨迹。
        quality_report = node_state.get("quality_report")
        if isinstance(quality_report, dict):
            runtime_stats = quality_report.get("runtime_stats")
            if isinstance(runtime_stats, dict):
                node_traces = list(node_state.get("node_traces", []))
                runtime_stats["node_trace"] = node_traces
                runtime_stats["node_retry_summary"] = self._build_retry_summary(node_traces)
                quality_report["runtime_stats"] = runtime_stats
                node_state["quality_report"] = quality_report
        return node_state

    def _node_quality_gate_action(self, state: LangGraphWorkflowState) -> dict[str, Any]:
        node_traces = list(state.get("node_traces", []))
        retry_summary = self._build_retry_summary(node_traces)
        runtime_stats = {
            "runtime_mode": self.runtime_mode(),
            "model": self.llm_client.model,
            "response_latency_ms": round(float(state.get("response_latency_ms", 0.0)), 2),
            "total_processing_ms": round(_elapsed_ms(state["run_started"]), 2),
            "stage_durations_ms": {
                key: round(value, 2) for key, value in dict(state.get("stage_durations_ms", {})).items()
            },
            "node_retry_max_attempts": int(self.node_retry_max_attempts),
            "node_retry_backoff_ms": int(self.node_retry_backoff_ms),
            "node_retry_summary": retry_summary,
            "node_trace": node_traces,
        }
        quality_report = self._build_quality_report(
            requirement=state["requirement"],
            context=state["context"],
            impacts=state["impacts"],
            design_doc=state["design_doc"],
            api_doc=state["api_doc"],
            coding_plan=state["coding_plan"],
            testing_plan=state["testing_plan"],
            unit_test_report=state["unit_test_report"],
            public_knowledge=state["public_knowledge_ctx"],
            validation=state["validation"],
            lifecycle_review=state.get("lifecycle_review", {}),
            runtime_stats=runtime_stats,
        )
        quality_gate = self._build_quality_gate(
            quality_report=quality_report,
            validation=state["validation"],
            lifecycle_review=state.get("lifecycle_review", {}),
            policy=self.quality_gate_policy,
        )
        quality_gate["policy_source"] = self.quality_gate_policy_source
        return {"quality_report": quality_report, "quality_gate": quality_gate}

    def _node_finalize(self, state: LangGraphWorkflowState) -> LangGraphWorkflowState:
        return self._run_node_with_retry(
            state,
            node_name="finalize",
            stage_key="finalize_ms",
            action=lambda: self._node_finalize_action(state),
        )

    def _node_finalize_action(self, state: LangGraphWorkflowState) -> dict[str, Any]:
        result = WorkflowResult(
            requirement=state["requirement"],
            impacts=state["impacts"],
            requirement_breakdown=state["requirement_breakdown"],
            design_doc=state["design_doc"],
            api_doc=state["api_doc"],
            coding_plan=state["coding_plan"],
            testing_plan=state["testing_plan"],
            unit_test_report=state["unit_test_report"],
            public_knowledge=state["public_knowledge_ctx"].to_dict(),
            quality_report=state["quality_report"],
            quality_gate=state["quality_gate"],
            lifecycle_review=state.get("lifecycle_review", {}),
            public_kb_draft=state["public_kb_draft"],
            public_kb_audit=state["public_kb_audit"],
            knowledge_assets=state["knowledge_assets"],
            validation=state["validation"],
        )
        return {"result": result}

    def run(
        self,
        requirement_text: str,
        context: ContextSnapshot,
        requirement_name: str = "Requirement",
    ) -> WorkflowResult:
        initial_state: LangGraphWorkflowState = {
            "requirement_text": requirement_text,
            "context": context,
            "requirement_name": requirement_name,
            "run_started": time.perf_counter(),
            "response_latency_ms": 0.0,
            "stage_durations_ms": {},
            "node_traces": [],
        }
        final_state = self._graph.invoke(initial_state)
        result = final_state.get("result")
        if not isinstance(result, WorkflowResult):
            raise RuntimeError("LangGraph workflow finished without WorkflowResult.")
        return result
