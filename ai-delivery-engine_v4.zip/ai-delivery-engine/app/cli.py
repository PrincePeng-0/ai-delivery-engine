from __future__ import annotations

import argparse
import sys
from pathlib import Path
from app.services import execute_generate, execute_kb_review, execute_scan_context


def build_parser() -> argparse.ArgumentParser:
    """构建命令行参数。

    子命令：
    - scan-context: 扫描仓库上下文并保存快照；
    - generate: 执行全流程并生成四类文档 + 两类接口 JSON；
    - generate-simple: 极简模式（仅 6 个参数）；
    - kb-review: 更新公共知识草稿审批状态。
    """
    parser = argparse.ArgumentParser(
        prog="ai-delivery-engine",
        description="AI Delivery Engine（MVP）",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan-context", help="扫描代码上下文")
    scan_parser.add_argument("--project-root", required=True, help="项目根目录")
    scan_parser.add_argument(
        "--output",
        default="outputs/context_snapshot.json",
        help="上下文输出 JSON 路径",
    )

    gen_parser = subparsers.add_parser("generate", help="生成交付文档与接口文档")
    gen_parser.add_argument("--requirement-file", required=True, help="需求文件路径")
    gen_parser.add_argument("--project-root", help="项目根目录（若不传，则必须传 context-file）")
    gen_parser.add_argument("--context-file", help="上下文快照 JSON 路径")
    gen_parser.add_argument("--out-dir", default="outputs/latest", help="输出目录")
    gen_parser.add_argument("--templates-dir", default="templates", help="模板目录")
    gen_parser.add_argument("--knowledge-dir", default="knowledge_base", help="知识库与skills目录（累计）")
    gen_parser.add_argument(
        "--kb-mode",
        choices=["local", "remote", "hybrid"],
        default="local",
        help="公共知识库接入模式",
    )
    gen_parser.add_argument(
        "--kb-dir",
        default="public_knowledge_base",
        help="本地公共知识库目录（local/hybrid 模式）",
    )
    gen_parser.add_argument(
        "--kb-url",
        default="",
        help="公共知识库服务地址（remote/hybrid 模式）",
    )
    gen_parser.add_argument(
        "--kb-token",
        default="",
        help="公共知识库访问令牌（未传则读取 PUBLIC_KB_TOKEN）",
    )
    gen_parser.add_argument(
        "--kb-namespace",
        default="default",
        help="公共知识命名空间",
    )
    gen_parser.add_argument(
        "--kb-cache-dir",
        default="outputs/kb_cache",
        help="公共知识缓存目录（hybrid 模式）",
    )
    gen_parser.add_argument(
        "--strict-kb",
        action="store_true",
        help="公共知识库不可用时直接失败（不降级）",
    )
    gen_parser.add_argument(
        "--rules-dir",
        default="knowledge_base/public_rules",
        help="公共规则库目录（使用者维护，执行时严格遵守）",
    )
    gen_parser.add_argument("--disable-llm", action="store_true", help="关闭 LLM，使用规则模式")
    gen_parser.add_argument("--model", help="LLM 模型名（默认取 OPENAI_MODEL 或 gpt-5）")
    gen_parser.add_argument("--strict-llm", action="store_true", help="强制 LLM 模式（失败不回退）")
    gen_parser.add_argument(
        "--orchestrator",
        choices=["classic", "langgraph"],
        default="langgraph",
        help="流程编排器（默认 langgraph；classic: 内置编排；langgraph: LangGraph 状态图编排）",
    )
    gen_parser.add_argument(
        "--node-retry-max-attempts",
        type=int,
        default=2,
        help="LangGraph 节点失败重试总尝试次数（含首次执行，最小值 1）",
    )
    gen_parser.add_argument(
        "--node-retry-backoff-ms",
        type=int,
        default=200,
        help="LangGraph 节点重试退避时间（毫秒，线性退避：backoff * attempt）",
    )
    gen_parser.add_argument(
        "--quality-gate-policy-file",
        default="",
        help="质量门禁策略 JSON 文件路径（默认读取 rules-dir 下 Quality_Gate_Policy.json）",
    )
    gen_parser.add_argument(
        "--enforce-quality-gate",
        action="store_true",
        help="当质量门禁为 BLOCK 时返回失败码",
    )

    simple_gen_parser = subparsers.add_parser(
        "generate-simple",
        help="极简生成模式，仅需 6 个参数（公共知识库、本地知识库、需求、项目、输出、模型）",
    )
    simple_gen_parser.add_argument("--public-kb-dir", required=True, help="公共知识库路径")
    simple_gen_parser.add_argument("--local-kb-dir", required=True, help="本地知识库路径")
    simple_gen_parser.add_argument("--requirement-file", required=True, help="需求地址路径")
    simple_gen_parser.add_argument("--project-root", required=True, help="项目路径")
    simple_gen_parser.add_argument("--out-dir", required=True, help="文档输出路径")
    simple_gen_parser.add_argument("--model", required=True, help="指定大模型")

    review_parser = subparsers.add_parser("kb-review", help="更新公共知识草稿审批状态")
    review_parser.add_argument("--draft-id", required=True, help="草稿ID")
    review_parser.add_argument(
        "--approval-status",
        required=True,
        choices=["PENDING_REVIEW", "APPROVED", "REJECTED"],
        help="审批状态",
    )
    review_parser.add_argument("--reviewer", default="", help="审批人")
    review_parser.add_argument("--note", default="", help="审批备注")
    review_parser.add_argument(
        "--kb-mode",
        choices=["local", "remote", "hybrid"],
        default="local",
        help="公共知识库接入模式",
    )
    review_parser.add_argument(
        "--kb-dir",
        default="public_knowledge_base",
        help="本地公共知识库目录（local/hybrid 模式）",
    )
    review_parser.add_argument("--kb-url", default="", help="公共知识库服务地址（remote/hybrid 模式）")
    review_parser.add_argument("--kb-token", default="", help="公共知识库访问令牌（未传则读取 PUBLIC_KB_TOKEN）")
    review_parser.add_argument("--kb-namespace", default="default", help="公共知识命名空间")
    review_parser.add_argument("--kb-cache-dir", default="outputs/kb_cache", help="公共知识缓存目录（hybrid 模式）")

    return parser


def cmd_scan_context(project_root: str, output: str) -> int:
    """扫描项目上下文并输出标准化快照文件。"""
    result = execute_scan_context(project_root=project_root, output=output)
    for line in result.logs:
        print(line)
    return result.exit_code


def cmd_generate(
    requirement_file: str,
    out_dir: str,
    templates_dir: str,
    knowledge_dir: str,
    kb_mode: str,
    kb_dir: str,
    kb_url: str,
    kb_token: str,
    kb_namespace: str,
    kb_cache_dir: str,
    strict_kb: bool,
    rules_dir: str,
    project_root: str | None,
    context_file: str | None,
    disable_llm: bool,
    model: str | None,
    strict_llm: bool,
    orchestrator: str,
    node_retry_max_attempts: int,
    node_retry_backoff_ms: int,
    quality_gate_policy_file: str,
    enforce_quality_gate: bool,
) -> int:
    """执行生成主流程。"""
    result = execute_generate(
        requirement_file=requirement_file,
        out_dir=out_dir,
        templates_dir=templates_dir,
        knowledge_dir=knowledge_dir,
        kb_mode=kb_mode,
        kb_dir=kb_dir,
        kb_url=kb_url,
        kb_token=kb_token,
        kb_namespace=kb_namespace,
        kb_cache_dir=kb_cache_dir,
        strict_kb=strict_kb,
        rules_dir=rules_dir,
        project_root=project_root,
        context_file=context_file,
        disable_llm=disable_llm,
        model=model,
        strict_llm=strict_llm,
        orchestrator=orchestrator,
        node_retry_max_attempts=node_retry_max_attempts,
        node_retry_backoff_ms=node_retry_backoff_ms,
        quality_gate_policy_file=quality_gate_policy_file,
        enforce_quality_gate=enforce_quality_gate,
    )
    for line in result.logs:
        print(line)
    return result.exit_code


def cmd_generate_simple(
    public_kb_dir: str,
    local_kb_dir: str,
    requirement_file: str,
    project_root: str,
    out_dir: str,
    model: str,
) -> int:
    """极简模式：仅保留 6 个业务参数，其余参数采用内置默认值。"""
    engine_root = Path(__file__).resolve().parents[1]
    templates_dir = str((engine_root / "templates").resolve())
    local_kb_path = Path(local_kb_dir).expanduser().resolve()
    rules_candidate = local_kb_path / "public_rules"
    fallback_rules = (engine_root / "knowledge_base" / "public_rules").resolve()
    rules_dir = str(rules_candidate if rules_candidate.exists() else fallback_rules)
    if not rules_candidate.exists():
        print(f"[WARN] 未在本地知识库下找到规则目录，已回退到默认规则目录: {rules_dir}")

    kb_cache_dir = str((Path(out_dir).expanduser().resolve() / "_kb_cache").resolve())

    result = execute_generate(
        requirement_file=requirement_file,
        out_dir=out_dir,
        templates_dir=templates_dir,
        knowledge_dir=str(local_kb_path),
        kb_mode="local",
        kb_dir=public_kb_dir,
        kb_url="",
        kb_token="",
        kb_namespace="default",
        kb_cache_dir=kb_cache_dir,
        strict_kb=False,
        rules_dir=rules_dir,
        project_root=project_root,
        context_file=None,
        disable_llm=False,
        model=model,
        strict_llm=False,
        orchestrator="langgraph",
        node_retry_max_attempts=2,
        node_retry_backoff_ms=200,
        quality_gate_policy_file="",
        enforce_quality_gate=False,
    )
    for line in result.logs:
        print(line)
    return result.exit_code


def cmd_kb_review(
    draft_id: str,
    approval_status: str,
    reviewer: str,
    note: str,
    kb_mode: str,
    kb_dir: str,
    kb_url: str,
    kb_token: str,
    kb_namespace: str,
    kb_cache_dir: str,
) -> int:
    """更新公共知识库草稿审批状态（人工审核环节）。"""
    result = execute_kb_review(
        draft_id=draft_id,
        approval_status=approval_status,
        reviewer=reviewer,
        note=note,
        kb_mode=kb_mode,
        kb_dir=kb_dir,
        kb_url=kb_url,
        kb_token=kb_token,
        kb_namespace=kb_namespace,
        kb_cache_dir=kb_cache_dir,
    )
    for line in result.logs:
        print(line)
    return result.exit_code


def main(argv: list[str] | None = None) -> int:
    """CLI 入口：分发子命令并返回进程退出码。"""
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "scan-context":
        return cmd_scan_context(project_root=args.project_root, output=args.output)
    if args.command == "generate":
        return cmd_generate(
            requirement_file=args.requirement_file,
            out_dir=args.out_dir,
            templates_dir=args.templates_dir,
            knowledge_dir=args.knowledge_dir,
            kb_mode=args.kb_mode,
            kb_dir=args.kb_dir,
            kb_url=args.kb_url,
            kb_token=args.kb_token,
            kb_namespace=args.kb_namespace,
            kb_cache_dir=args.kb_cache_dir,
            strict_kb=args.strict_kb,
            rules_dir=args.rules_dir,
            project_root=args.project_root,
            context_file=args.context_file,
            disable_llm=args.disable_llm,
            model=args.model,
            strict_llm=args.strict_llm,
            orchestrator=args.orchestrator,
            node_retry_max_attempts=args.node_retry_max_attempts,
            node_retry_backoff_ms=args.node_retry_backoff_ms,
            quality_gate_policy_file=args.quality_gate_policy_file,
            enforce_quality_gate=args.enforce_quality_gate,
        )
    if args.command == "generate-simple":
        return cmd_generate_simple(
            public_kb_dir=args.public_kb_dir,
            local_kb_dir=args.local_kb_dir,
            requirement_file=args.requirement_file,
            project_root=args.project_root,
            out_dir=args.out_dir,
            model=args.model,
        )
    if args.command == "kb-review":
        return cmd_kb_review(
            draft_id=args.draft_id,
            approval_status=args.approval_status,
            reviewer=args.reviewer,
            note=args.note,
            kb_mode=args.kb_mode,
            kb_dir=args.kb_dir,
            kb_url=args.kb_url,
            kb_token=args.kb_token,
            kb_namespace=args.kb_namespace,
            kb_cache_dir=args.kb_cache_dir,
        )
    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
