from __future__ import annotations

from typing import Any

from app.agents.api_writer import ApiWriter
from app.agents.design_writer import DesignWriter
from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput


class Architecture:
    """Architecture 资深架构师。

    职责：
    - 严格基于需求分析报告和当前架构基线输出设计方案；
    - 覆盖业务架构、应用架构、技术架构、数据架构四个维度；
    - 形成可直接落地开发的 `DesignDoc` 与 `ApiDoc`。
    """

    def __init__(
        self,
        design_writer: DesignWriter,
        api_writer: ApiWriter,
    ) -> None:
        self.design_writer = design_writer
        self.api_writer = api_writer

    def design(
        self,
        requirement: RequirementInput,
        context: ContextSnapshot,
        impacts: list[ImpactItem],
        knowledge_input: dict[str, Any] | None = None,
    ) -> tuple[DesignDoc, ApiDoc]:
        design_doc = self.design_writer.build(requirement, context, impacts, knowledge_input=knowledge_input)
        api_doc = self.api_writer.build(requirement, context, impacts, knowledge_input=knowledge_input)
        return design_doc, api_doc
