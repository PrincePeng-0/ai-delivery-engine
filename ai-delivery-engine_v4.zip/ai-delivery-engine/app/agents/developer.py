from __future__ import annotations

from typing import Any

from app.agents.development_planner import DevelopmentPlanner
from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput


class Developer:
    """Developer 开发技术专家。

    职责：
    - 从代码实现角度给出功能开发计划；
    - 明确具体改动点、影响范围和联动风险；
    - 输出可执行的编码 guardrails 与测试覆盖目标。
    """

    def __init__(self, development_planner: DevelopmentPlanner) -> None:
        self.development_planner = development_planner

    def build(
        self,
        requirement: RequirementInput,
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        context: ContextSnapshot,
        knowledge_input: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        plan = self.development_planner.build(
            requirement,
            design_doc,
            api_doc,
            impacts,
            context,
            knowledge_input=knowledge_input,
        )
        plan["unit_test_targets"] = [
            "核心业务服务层覆盖率 >= 95%",
            "接口层参数校验与异常分支覆盖",
            "幂等与重试路径覆盖",
            "关键链路 end-to-end 单元测试覆盖",
        ]
        plan["coverage_target"] = ">=95%"
        plan["implementation_guardrails"] = [
            "严格遵循 FRD 中的目标、范围、约束与数据结构定义",
            "接口字段、错误码、超时策略与接口文档保持一致",
            "新增代码必须同时提交单元测试",
            "每个模块必须给出可定位到代码层的改动点与影响范围",
        ]
        return plan
