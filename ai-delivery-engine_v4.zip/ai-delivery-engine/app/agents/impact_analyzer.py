from __future__ import annotations

import re

from app.llm import LLMClient, context_snapshot_brief, ensure_str, ensure_str_list
from app.schemas import ContextSnapshot, ImpactItem, RequirementInput


class ImpactAnalyzer:
    """根据需求和仓库上下文推断影响系统（LLM 优先，规则回退）。"""

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        use_llm: bool = True,
        allow_fallback: bool = True,
    ) -> None:
        self.llm_client = llm_client
        self.use_llm = use_llm
        self.allow_fallback = allow_fallback

    TAG_HINTS: dict[str, list[str]] = {
        "orchestration": ["编排", "orchestr", "workflow", "后台", "中台"],
        "gateway": ["gateway", "网关", "入口", "接入"],
        "risk": ["risk", "风控", "决策", "审核", "黑白名单"],
        "transaction": ["transaction", "交易", "授权", "清算", "退款", "撤销", "支付"],
        "billing": ["bill", "账单", "对账", "费用", "记账", "费率"],
        "identity": ["user", "auth", "账号", "权限", "角色", "身份", "认证"],
        "channel": ["channel", "渠道", "适配", "处理商"],
    }

    GENERIC_CHANGE_HINTS: list[str] = [
        "补充该系统与上下游交互的输入输出字段定义",
        "补充幂等、超时、重试和异常分支处理策略",
        "补充关键日志与可观测指标（traceId/requestId/错误码）",
    ]

    def analyze(self, requirement: RequirementInput, context: ContextSnapshot) -> list[ImpactItem]:
        if self.use_llm and self.llm_client and self.llm_client.is_ready:
            try:
                return self._analyze_with_llm(requirement, context)
            except Exception:
                if not self.allow_fallback:
                    raise

        if self.use_llm and self.llm_client and not self.llm_client.is_ready and not self.allow_fallback:
            raise RuntimeError("LLM is not ready and fallback is disabled.")

        return self._analyze_with_rules(requirement, context)

    def _analyze_with_llm(self, requirement: RequirementInput, context: ContextSnapshot) -> list[ImpactItem]:
        assert self.llm_client is not None
        available_systems = sorted(repo.name for repo in context.repos)
        base = self._analyze_with_rules(requirement, context)

        system_prompt = (
            "你是资深架构师，负责评估需求影响系统。"
            "你只能从给定系统集合中选择系统。"
            "只输出 JSON。"
        )
        user_prompt = (
            "请输出格式：\n"
            "{\n"
            '  "impacts": [\n'
            "    {\n"
            '      "system": "system-xxx",\n'
            '      "reason": "string",\n'
            '      "changes": ["string"]\n'
            "    }\n"
            "  ]\n"
            "}\n\n"
            "要求：\n"
            "- system 必须来自 available_systems\n"
            "- 至少给出 1 个 impact\n"
            "- changes 每个系统给出 2-4 条\n\n"
            "- 优先最小必要影响集，通常 2-4 个系统；除非需求原文明确，否则不要把所有系统都选中。\n"
            "- 只选择与本需求直接相关的系统，避免“泛影响”输出。\n\n"
            f"available_systems:\n{available_systems}\n\n"
            f"requirement:\n{requirement.raw_text}\n\n"
            f"context_brief:\n{context_snapshot_brief(context)}\n"
        )
        payload = self.llm_client.generate_json(system_prompt=system_prompt, user_prompt=user_prompt)

        items = payload.get("impacts") if isinstance(payload, dict) else payload
        if not isinstance(items, list):
            raise ValueError("Impact analyzer expects a list output.")

        available_set = set(available_systems)
        impacts: list[ImpactItem] = []
        seen: set[str] = set()
        for item in items:
            if not isinstance(item, dict):
                continue
            system = ensure_str(item.get("system"))
            if not system or system not in available_set or system in seen:
                continue
            seen.add(system)
            reason = ensure_str(item.get("reason"), self._reason_text(system, requirement))
            changes = ensure_str_list(item.get("changes")) or self.GENERIC_CHANGE_HINTS
            impacts.append(ImpactItem(system=system, reason=reason, changes=changes))

        explicit_systems = {repo for repo in available_systems if repo.lower() in requirement.raw_text.lower()}
        if len(impacts) > 6 and explicit_systems:
            narrowed = [item for item in impacts if item.system in explicit_systems]
            if narrowed:
                return narrowed

        if impacts:
            return impacts
        return base

    def _analyze_with_rules(self, requirement: RequirementInput, context: ContextSnapshot) -> list[ImpactItem]:
        available = sorted({repo.name for repo in context.repos})
        if not available:
            return []

        selected: set[str] = set()
        text = requirement.raw_text.lower()

        # 1) 直接命中：需求文本包含系统名
        for repo_name in available:
            if repo_name.lower() in text:
                selected.add(repo_name)

        # 2) 按系统名分词命中
        for repo_name in available:
            tokens = _repo_tokens(repo_name)
            if any(token in text for token in tokens):
                selected.add(repo_name)

        # 3) 按语义标签命中
        for tag, hints in self.TAG_HINTS.items():
            if not any(hint.lower() in text for hint in hints):
                continue
            for repo_name in available:
                if tag in _repo_tokens(repo_name):
                    selected.add(repo_name)

        # 4) 兜底：优先取范围内系统，其次取前 4 个系统
        if not selected:
            for item in requirement.scope_in:
                lower = item.lower()
                for repo_name in available:
                    if repo_name.lower() == lower:
                        selected.add(repo_name)
            if not selected:
                selected.update(available[: min(4, len(available))])

        impacts: list[ImpactItem] = []
        for system in sorted(selected):
            impacts.append(
                ImpactItem(
                    system=system,
                    reason=self._reason_text(system, requirement),
                    changes=self.GENERIC_CHANGE_HINTS,
                )
            )
        return impacts

    @staticmethod
    def _reason_text(system: str, requirement: RequirementInput) -> str:
        return f"需求《{requirement.title}》包含与 `{system}` 相关关键词或链路依赖，需纳入影响评估。"


def _repo_tokens(repo_name: str) -> list[str]:
    parts = [item for item in re.split(r"[-_/.]+", repo_name.lower()) if item]
    stopwords = {
        "vcc",
        "service",
        "services",
        "system",
        "systems",
        "module",
        "modules",
        "center",
    }
    filtered = [item for item in parts if len(item) >= 3 and item not in stopwords]
    return sorted(set(filtered))
