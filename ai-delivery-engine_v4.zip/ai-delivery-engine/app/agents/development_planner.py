from __future__ import annotations

import re
from typing import Any

from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput


class DevelopmentPlanner:
    """编码开发阶段规划器（D 阶段）。"""

    def __init__(self, code_development_rule: str = "") -> None:
        self.code_development_rule = code_development_rule.strip()

    def build(
        self,
        requirement: RequirementInput,
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        context: ContextSnapshot,
        knowledge_input: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        repo_map = {repo.name: repo for repo in context.repos}

        module_plans: list[dict[str, Any]] = []
        for impact in impacts:
            repo = repo_map.get(impact.system)
            providers = repo.dubbo_providers[:5] if repo else []
            references = repo.dubbo_references[:5] if repo else []
            modules = repo.modules[:5] if repo else []
            endpoints = [
                endpoint.interface
                for endpoint in api_doc.endpoints
                if endpoint.owner_system == impact.system
            ][:5]
            module_plans.append(
                {
                    "system": impact.system,
                    "core_actions": [
                        "代码编写：按 FRD 与接口契约补齐业务实现",
                        "模块调试：对关键调用链进行本地联调",
                        "版本管理：按功能分支提交并控制变更粒度",
                    ],
                    "code_generation_targets": endpoints or ["待补充接口实现"],
                    "related_modules": modules,
                    "related_providers": providers,
                    "related_references": references,
                    "code_change_points": _build_code_change_points(
                        system=impact.system,
                        modules=modules,
                        providers=providers,
                        references=references,
                        endpoints=endpoints,
                    ),
                    "impact_scope": {
                        "immediate_system": impact.system,
                        "upstream_callers": references,
                        "downstream_services": providers,
                        "affected_endpoints": endpoints,
                    },
                    "ai_optimization_suggestions": [
                        "优先生成 DTO/VO/错误码映射骨架代码",
                        "自动补全参数校验与异常处理模板",
                        "对热点函数给出复杂度优化建议",
                    ],
                    "syntax_and_quality_checks": [
                        "静态语法检查（语法错误、未使用变量、导入冲突）",
                        "编码规范检查（命名、注释、空值处理、日志字段）",
                        "接口契约一致性检查（字段名/类型/必填项）",
                    ],
                }
            )

        rule_guardrails = _extract_rule_guardrails(self.code_development_rule)
        public_guardrails = _extract_public_coding_guardrails(knowledge_input)
        stage_feedback_guardrails = _extract_stage_correction_feedback(knowledge_input)
        global_quality_gate = [
            "关键路径增加 traceId/requestId 透传",
            "幂等键处理逻辑可观测且可回放",
            "异常路径覆盖超时/重试/降级",
        ]
        if rule_guardrails:
            global_quality_gate.extend(rule_guardrails)
        if public_guardrails:
            global_quality_gate.extend(public_guardrails)
        if stage_feedback_guardrails:
            global_quality_gate.extend(stage_feedback_guardrails)

        return {
            "stage": "编码开发阶段",
            "stage_code": "D",
            "ai_boost": "AI提效3：代码生成与语法校验",
            "core_actions": ["代码编写", "模块调试", "版本管理"],
            "ai_actions": [
                "根据需求与设计方案生成基础代码和注释",
                "实时校验语法错误与代码规范",
                "提供可落地的优化建议与重构提示",
            ],
            "entry_criteria": [
                "需求分析报告与 FRD 已确认",
                "接口契约已冻结或进入可控变更窗口",
                "已加载使用方代码编写规范并纳入执行约束",
            ],
            "exit_criteria": [
                "核心模块编码完成并通过基本联调",
                "关键语法/规范问题已关闭",
                "版本分支可提交测试验证阶段",
            ],
            "module_plans": module_plans,
            "global_quality_gate": global_quality_gate,
            "rule_source": "Code_Development_Standard (user-defined)",
            "summary": (
                f"需求《{requirement.title}》识别到 {len(module_plans)} 个系统编码任务，"
                "已给出代码改动点与影响范围建议。"
            ),
        }


def _extract_rule_guardrails(rule_text: str, limit: int = 6) -> list[str]:
    if not rule_text.strip():
        return []
    lines = [line.strip() for line in rule_text.splitlines()]
    candidates: list[str] = []
    for line in lines:
        if not line:
            continue
        if line.startswith("#"):
            continue
        if not (line.startswith("-") or re.match(r"^\d+\.\s+", line)):
            continue
        text = re.sub(r"^-\s*", "", line)
        text = re.sub(r"^\d+\.\s*", "", text)
        text = text.strip()
        if len(text) < 4:
            continue
        candidates.append(f"规则约束：{text}")
        if len(candidates) >= limit:
            break
    return candidates


def _extract_public_coding_guardrails(
    knowledge_input: dict[str, Any] | None,
    limit: int = 4,
) -> list[str]:
    if not knowledge_input:
        return []
    standards = knowledge_input.get("public_coding_standards")
    if not isinstance(standards, list):
        return []
    output: list[str] = []
    for item in standards:
        text = str(item).strip()
        if not text:
            continue
        output.append(f"公共知识约束：{text}")
        if len(output) >= limit:
            break
    return output


def _extract_stage_correction_feedback(
    knowledge_input: dict[str, Any] | None,
    limit: int = 4,
) -> list[str]:
    if not knowledge_input:
        return []
    rows = knowledge_input.get("stage_correction_feedback")
    if not isinstance(rows, list):
        return []
    output: list[str] = []
    for item in rows:
        text = str(item).strip()
        if not text:
            continue
        output.append(f"阶段纠偏：{text}")
        if len(output) >= limit:
            break
    return output


def _build_code_change_points(
    system: str,
    modules: list[str],
    providers: list[str],
    references: list[str],
    endpoints: list[str],
    limit: int = 8,
) -> list[str]:
    """构造可直接执行的代码改动点清单。"""
    points: list[str] = []
    for module in modules:
        points.append(f"{system}/{module}: 补齐核心业务逻辑与参数校验。")
    for endpoint in endpoints:
        points.append(f"{system}::{endpoint}: 对齐接口契约（字段/错误码/超时与重试）。")
    for ref in references:
        points.append(f"{system} -> {ref}: 校验上游调用兼容性与回归影响。")
    for provider in providers:
        points.append(f"{system} -> {provider}: 校验下游依赖行为与失败降级。")

    deduped: list[str] = []
    seen: set[str] = set()
    for item in points:
        text = item.strip()
        if not text or text in seen:
            continue
        seen.add(text)
        deduped.append(text)
        if len(deduped) >= limit:
            break
    return deduped or [f"{system}: 结合 FRD 与接口文档补充实现细化改动点。"]
