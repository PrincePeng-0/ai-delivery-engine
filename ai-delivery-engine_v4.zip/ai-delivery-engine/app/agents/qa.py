from __future__ import annotations

from typing import Any

from app.agents.qa_planner import QAPlanner
from app.schemas import ApiDoc, ImpactItem, RequirementInput


class QA:
    """QA 资深测试工程师。

    职责：
    - 设计 end-to-end 单元测试用例；
    - 保障核心代码片段覆盖目标达到 >=95%；
    - 输出测试执行报告与缺陷修复关注点。
    """

    def __init__(self, testing_planner: QAPlanner) -> None:
        self.testing_planner = testing_planner

    def build(
        self,
        requirement: RequirementInput,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        coding_plan: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        testing_plan = self.testing_planner.build(requirement, api_doc, impacts, coding_plan)
        unit_test_report = self._build_unit_test_report(requirement, testing_plan, coding_plan)
        return testing_plan, unit_test_report

    @staticmethod
    def _build_unit_test_report(
        requirement: RequirementInput,
        testing_plan: dict[str, Any],
        coding_plan: dict[str, Any],
    ) -> dict[str, Any]:
        case_sets = testing_plan.get("test_case_sets", [])
        total_cases = sum(len(item.get("cases", [])) for item in case_sets)
        return {
            "title": f"{requirement.title} - 单元测试报告",
            "status": "PLANNED",
            "coverage_target": coding_plan.get("coverage_target", ">=95%"),
            "estimated_coverage": ">=95%",
            "suite_count": len(case_sets),
            "case_count": total_cases,
            "execution_summary": (
                f"已为 {len(case_sets)} 个接口生成 {total_cases} 条单元测试样例，"
                "用于开发阶段联动执行与缺陷定位。"
            ),
            "quality_focus": [
                "端到端主链路执行与状态一致性覆盖",
                "参数校验与边界输入覆盖",
                "异常分支与错误码映射覆盖",
                "幂等、重试、超时场景覆盖",
            ],
        }
