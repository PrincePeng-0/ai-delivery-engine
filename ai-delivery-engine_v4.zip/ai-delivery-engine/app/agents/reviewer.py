from __future__ import annotations

from typing import Any

from app.schemas import ApiDoc, ContextSnapshot, DesignDoc, ImpactItem, RequirementInput, ValidationReport
from app.validators import validate_outputs


class Reviewer:
    """Reviewer（Teach Lead）评审角色。

    职责：
    - 严格按既有规范执行架构治理与交付评审；
    - 对需求生命周期各阶段产物进行一致性核查与纠偏；
    - 保障最终生成物可直接进入落地开发。
    """

    def review_requirement(
        self,
        requirement: RequirementInput,
        impacts: list[ImpactItem],
        context: ContextSnapshot,
    ) -> ValidationReport:
        checks: list[str] = []
        errors: list[str] = []
        warnings: list[str] = []

        checks.append("需求结构完整性")
        if not requirement.title.strip():
            errors.append("需求标题为空。")
        if not requirement.background.strip():
            errors.append("需求背景为空。")
        if not requirement.goals:
            errors.append("需求目标为空。")
        if not requirement.scope_in:
            errors.append("需求范围（scope_in）为空。")
        if not requirement.constraints:
            errors.append("需求约束为空。")
        if not requirement.acceptance_criteria:
            errors.append("需求验收标准为空。")

        checks.append("需求标题规范性")
        title_lower = requirement.title.lower()
        if any(keyword in title_lower for keyword in ["需求分析报告", "开发设计文档", "技术开发设计", "frd"]):
            warnings.append("需求标题含文档后缀语义，建议仅保留需求主题名称。")

        checks.append("影响系统有效性")
        available = {repo.name for repo in context.repos}
        if not impacts:
            errors.append("未识别到影响系统，无法进入架构设计评审。")
        for impact in impacts:
            if impact.system not in available:
                errors.append(f"影响系统 `{impact.system}` 不存在于上下文快照。")

        checks.append("影响范围合理性")
        if impacts and len(impacts) > max(6, len(available)):
            warnings.append(f"影响系统数量偏多（{len(impacts)}），建议复核是否存在过度扩散。")

        return ValidationReport(passed=not errors, errors=errors, warnings=warnings, checks=checks)

    def review_architecture(
        self,
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        context: ContextSnapshot,
    ) -> ValidationReport:
        base = validate_outputs(design_doc, api_doc, impacts, context)
        checks = list(base.checks)
        errors = list(base.errors)
        warnings = list(base.warnings)

        checks.append("架构四视图完整性")
        background_text = f"{design_doc.background}\n{design_doc.context_summary}".strip().lower()
        if not background_text:
            errors.append("架构说明缺失（背景/上下文摘要为空）。")
        if len(design_doc.data_model_notes) < 2:
            warnings.append("数据架构说明较少，建议补充实体关系与索引策略。")
        if not design_doc.architecture_diagram.strip():
            errors.append("应用/技术架构图为空。")

        return ValidationReport(passed=not errors, errors=errors, warnings=warnings, checks=checks)

    def review(
        self,
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        context: ContextSnapshot,
    ) -> ValidationReport:
        return self.review_architecture(design_doc, api_doc, impacts, context)

    def review_developer(
        self,
        coding_plan: dict[str, Any],
        impacts: list[ImpactItem],
    ) -> ValidationReport:
        checks: list[str] = []
        errors: list[str] = []
        warnings: list[str] = []

        checks.append("开发计划完整性")
        module_plans = coding_plan.get("module_plans", [])
        if not isinstance(module_plans, list) or not module_plans:
            errors.append("开发计划缺少 module_plans。")
            module_plans = []

        checks.append("改动点与影响范围")
        for plan in module_plans:
            if not isinstance(plan, dict):
                continue
            system = str(plan.get("system", "")).strip() or "unknown-system"
            change_points = plan.get("code_change_points", [])
            impact_scope = plan.get("impact_scope", {})
            if not isinstance(change_points, list) or not change_points:
                errors.append(f"[{system}] 缺少代码改动点（code_change_points）。")
            if not isinstance(impact_scope, dict) or not impact_scope:
                errors.append(f"[{system}] 缺少影响范围（impact_scope）。")

        checks.append("覆盖率目标")
        coverage_target = str(coding_plan.get("coverage_target", "")).strip()
        if not coverage_target:
            errors.append("开发计划缺少 coverage_target。")
        elif "95" not in coverage_target and ">=" not in coverage_target:
            warnings.append(f"当前覆盖率目标为 `{coverage_target}`，未显式达到 >=95%。")

        checks.append("影响系统对齐")
        if impacts and module_plans and len(module_plans) < len(impacts):
            warnings.append("开发计划模块数量小于影响系统数量，可能存在漏项。")

        return ValidationReport(passed=not errors, errors=errors, warnings=warnings, checks=checks)

    def review_qa(
        self,
        testing_plan: dict[str, Any],
        unit_test_report: dict[str, Any],
        coding_plan: dict[str, Any],
    ) -> ValidationReport:
        checks: list[str] = []
        errors: list[str] = []
        warnings: list[str] = []

        checks.append("测试计划完整性")
        case_sets = testing_plan.get("test_case_sets", [])
        if not isinstance(case_sets, list) or not case_sets:
            errors.append("测试计划缺少 test_case_sets。")
            case_sets = []

        checks.append("端到端单测覆盖")
        e2e_templates = testing_plan.get("e2e_unit_case_templates", [])
        if not isinstance(e2e_templates, list) or not e2e_templates:
            errors.append("缺少 end-to-end 单元测试模板。")
        elif len(e2e_templates) < 2:
            warnings.append("end-to-end 单元测试模板数量较少，建议补充关键链路场景。")

        checks.append("正反用例覆盖")
        for suite in case_sets:
            if not isinstance(suite, dict):
                continue
            endpoint = str(suite.get("endpoint", "")).strip() or "unknown-endpoint"
            cases = suite.get("cases", [])
            if not isinstance(cases, list) or not cases:
                errors.append(f"[{endpoint}] 缺少测试用例。")
                continue
            case_types = {str(item.get('type', '')).strip() for item in cases if isinstance(item, dict)}
            if "正向用例" not in case_types or "反向用例" not in case_types:
                warnings.append(f"[{endpoint}] 正/反向用例覆盖不完整。")

        checks.append("覆盖率目标一致性")
        coding_target = str(coding_plan.get("coverage_target", "")).strip()
        testing_target = str(unit_test_report.get("coverage_target", "")).strip()
        if coding_target and testing_target and coding_target != testing_target:
            warnings.append(f"开发与测试覆盖目标不一致（dev={coding_target}, test={testing_target}）。")
        if testing_target and "95" not in testing_target and ">=" not in testing_target:
            warnings.append(f"测试覆盖目标 `{testing_target}` 未显式达到 >=95%。")

        return ValidationReport(passed=not errors, errors=errors, warnings=warnings, checks=checks)

    def review_lifecycle(
        self,
        requirement: RequirementInput,
        design_doc: DesignDoc,
        api_doc: ApiDoc,
        impacts: list[ImpactItem],
        context: ContextSnapshot,
        coding_plan: dict[str, Any],
        testing_plan: dict[str, Any],
        unit_test_report: dict[str, Any],
    ) -> tuple[ValidationReport, dict[str, Any]]:
        stage_reports = {
            "ba": self.review_requirement(requirement, impacts, context),
            "architecture": self.review_architecture(design_doc, api_doc, impacts, context),
            "developer": self.review_developer(coding_plan, impacts),
            "qa": self.review_qa(testing_plan, unit_test_report, coding_plan),
        }

        merged = _merge_stage_reports(stage_reports)
        detail = {
            "stages": {name: report.to_dict() for name, report in stage_reports.items()},
            "passed": merged.passed,
            "error_count": len(merged.errors),
            "warning_count": len(merged.warnings),
            "blocking_issues": list(merged.errors),
            "warning_issues": list(merged.warnings),
            "auto_fix_actions": _build_auto_fix_actions(stage_reports),
        }
        return merged, detail


def _merge_stage_reports(stage_reports: dict[str, ValidationReport]) -> ValidationReport:
    checks: list[str] = []
    errors: list[str] = []
    warnings: list[str] = []
    for stage, report in stage_reports.items():
        stage_label = stage.replace("_", "-")
        checks.extend([f"[{stage_label}] {item}" for item in report.checks])
        errors.extend([f"[{stage_label}] {item}" for item in report.errors])
        warnings.extend([f"[{stage_label}] {item}" for item in report.warnings])
    return ValidationReport(passed=not errors, errors=errors, warnings=warnings, checks=checks)


def _build_auto_fix_actions(stage_reports: dict[str, ValidationReport]) -> list[str]:
    actions: list[str] = []
    for stage, report in stage_reports.items():
        if report.passed:
            continue
        if stage == "ba":
            actions.append("补齐需求背景/目标/范围/约束/验收标准并重新评审需求分析。")
        elif stage == "architecture":
            actions.append("补齐架构图、时序图、数据设计与接口归属映射后重新评审架构。")
        elif stage == "developer":
            actions.append("补齐代码改动点与影响范围，统一覆盖率目标到 >=95%。")
        elif stage == "qa":
            actions.append("补齐 end-to-end 单元测试集与正反向用例覆盖，确保覆盖目标一致。")
    if not actions:
        actions.append("生命周期评审通过，可进入开发落地。")
    return actions
