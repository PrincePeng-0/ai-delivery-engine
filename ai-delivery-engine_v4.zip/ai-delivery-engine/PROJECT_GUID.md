# PROJECT_GUID

`PROJECT_GUID` 是项目实施入口文档。  
完整技术说明请阅读：

- `docs/PROJECT_GUIDE.md`

建议阅读顺序：
1. `README.md`（快速上手与运行方式）
2. `PROJECT_GUID.md`（导航入口）
3. `docs/PROJECT_GUIDE.md`（完整架构、流程、数据模型、规则门禁、排障）

核心速览：
- 默认编排器：`langgraph`
- 评审机制：每阶段内置 Reviewer 评审与纠偏重试，末尾再做生命周期汇总评审
- 最新角色：`KB / BA / Architecture / Developer / QA / Reviewer`
- 极简命令：`generate-simple`（固定 6 参数）
- 主要产物：需求分析报告、FRD、接口文档、质量评估、Postman JSON、Apifox JSON、执行追踪 JSON
- 知识模式：`local` / `remote` / `hybrid`
- 规则库：使用方维护，执行时严格读取
