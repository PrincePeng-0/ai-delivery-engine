# AI Delivery Engine Project Guide

本文档面向实施、维护和二次开发。  
目标是让你可以基于“当前代码”快速理解系统能力边界、运行方式、扩展点和排障路径。

## 1. 项目目标与边界

`AI Delivery Engine` 的目标是把需求输入转化为结构化交付物，并在流程中执行知识增强与质量门禁。

当前边界：
- 会生成文档、接口 JSON、质量报告和执行追踪。
- 会沉淀本地知识库和 skills。
- 不会直接修改目标业务代码仓。
- 不会直接执行 pytest/CI，仅输出测试计划与报告草案。

## 2. 技术栈

来源：`pyproject.toml`

| 类别 | 组件 | 版本要求 |
| --- | --- | --- |
| 语言 | Python | `>=3.10` |
| LLM SDK | OpenAI Python SDK | `>=1.40.0` |
| API 框架 | FastAPI | `>=0.115.0` |
| 服务运行 | Uvicorn | `>=0.30.0` |
| 工作流编排 | LangGraph | `>=0.2.0` |

可执行入口：
- `ai-delivery-engine` -> `app.cli:main`
- `ai-delivery-engine-api` -> `app.api.main:run`

## 3. 关键目录与模块

```text
ai-delivery-engine/
  app/
    agents/                         # 角色实现（BA/Architecture/Developer/QA/Reviewer）
    api/main.py                     # FastAPI 服务入口与异步任务管理
    cli.py                          # CLI 入口与参数编排
    services/engine_service.py      # 主执行服务（扫描、生成、审批）
    workflow/engine.py              # Classic 编排器 + 质量评估/门禁核心逻辑
    workflow/langgraph_engine.py    # LangGraph 编排器（默认）
    kb/provider.py                  # 公共知识库 provider（local/remote/hybrid）
    rules/public_rulebook.py        # 公共规则库加载
    rules/quality_gate_policy.py    # 质量门禁策略加载与默认策略
    render/markdown.py              # 产物渲染（模板占位符、图表修复、表格输出）
    exporters/spec_exporter.py      # Postman/OpenAPI(Apifox) 导出
    validators/                     # 校验器（质量/文档语义边界）
    schemas/models.py               # 核心数据模型
  templates/                        # 文档模板
  knowledge_base/                   # 本地知识库（累计）
  public_knowledge_base/            # 公共知识快照与草稿审计
  docs/PROJECT_GUIDE.md
```

## 4. 系统架构

```mermaid
flowchart LR
    USER[UserOrCI] --> ENTRY[CLIOrFastAPI]
    ENTRY --> WM[WorkflowManager]

    WM --> KB[KB KnowledgeExpert]
    KB --> BA[BA RequirementAnalysis]
    BA --> RBA[Reviewer StageGate BA]
    RBA --> GBA{BA Pass}
    GBA -- Yes --> ARCH[Architecture Design]
    GBA -- No Retry<=N --> BA

    ARCH --> RARCH[Reviewer StageGate Architecture]
    RARCH --> GARCH{Architecture Pass}
    GARCH -- Yes --> DEV[Developer Plan]
    GARCH -- No Retry<=N --> ARCH

    DEV --> RDEV[Reviewer StageGate Developer]
    RDEV --> GDEV{Developer Pass}
    GDEV -- Yes --> QA[QA TestPlanning]
    GDEV -- No Retry<=N --> DEV

    QA --> RQA[Reviewer StageGate QA]
    RQA --> GQA{QA Pass}
    GQA -- Yes --> RLIFE[Reviewer LifecycleReview]
    GQA -- No Retry<=N --> QA

    RLIFE --> QUAL[QualityReportAndGate]
    QUAL --> OUT[MarkdownAndJSONArtifacts]

    KB <--> PKB[PublicKnowledgeProvider]
    KB <--> LKB[LocalKnowledgeAndSkills]
    WM --> RULE[PublicRulebook]
```

## 5. 角色定义（5 核心 + 2 平台能力）

| 角色 | 类型 | 输入 | 输出 | 代码位置 |
| --- | --- | --- | --- | --- |
| `BA` | 核心 | 需求文档、业务背景、知识输入 | 严格按模板输出需求分析结构（背景/目标/范围/约束/验收）与影响范围 | `app/agents/ba.py` |
| `Architecture` | 核心 | BA 阶段输出、架构基线、上下文 | 业务架构、应用架构、技术架构、数据架构设计（`DesignDoc` + `ApiDoc`） | `app/agents/architecture.py` |
| `Developer` | 核心 | 需求/设计/接口/上下文 | 从代码视角输出开发计划，明确具体改动点与影响范围 | `app/agents/developer.py` |
| `QA` | 核心 | 需求/接口/开发计划 | 设计 end-to-end 单元测试用例与覆盖计划（覆盖目标 >=95%） | `app/agents/qa.py` |
| `Reviewer` | 核心 | 各阶段产物、规则库、上下文 | Teach Lead 治理评审；每阶段产出后立刻评审并纠偏，不通过则当场重试至上限 | `app/agents/reviewer.py` |
| `KB`（Knowledge Expert） | 平台能力 | 上下文、需求、设计、接口、用户规则库 | 严控知识输入与更新，维护高质量体系化知识库，提供统一规则库前置约束，持续沉淀 skills | `app/agents/knowledge_base_administrator.py` |
| `WorkflowManager` | 平台能力 | 全量阶段输入 | 编排执行、质量评估、门禁判定、最终产物汇总 | `app/workflow/engine.py` / `app/workflow/langgraph_engine.py` |

## 6. 端到端时序

```mermaid
sequenceDiagram
    autonumber
    participant USER as UserOrCI
    participant WM as WorkflowManager
    participant KB as KB
    participant BA as BA
    participant ARCH as Architecture
    participant DEV as Developer
    participant QA as QA
    participant RVW as Reviewer
    participant OUT as Artifacts

    USER->>WM: 输入需求与上下文
    WM->>KB: 加载公共知识与本地知识
    KB-->>WM: 返回知识输入与规则上下文

    loop BA阶段纠偏 最多N轮
        WM->>BA: 执行需求分析
        BA-->>WM: 返回需求分析与影响范围
        WM->>RVW: 阶段评审 BA
        alt 评审通过
            RVW-->>WM: pass
        else 评审不通过
            RVW-->>WM: feedback
            WM->>BA: 按反馈纠偏重试
        end
    end

    loop Architecture阶段纠偏 最多N轮
        WM->>ARCH: 执行架构与接口设计
        ARCH-->>WM: 返回设计文档与接口文档
        WM->>RVW: 阶段评审 Architecture
        alt 评审通过
            RVW-->>WM: pass
        else 评审不通过
            RVW-->>WM: feedback
            WM->>ARCH: 按反馈纠偏重试
        end
    end

    loop Developer阶段纠偏 最多N轮
        WM->>DEV: 生成开发计划与改动点
        DEV-->>WM: 返回开发计划
        WM->>RVW: 阶段评审 Developer
        alt 评审通过
            RVW-->>WM: pass
        else 评审不通过
            RVW-->>WM: feedback
            WM->>DEV: 按反馈纠偏重试
        end
    end

    loop QA阶段纠偏 最多N轮
        WM->>QA: 生成端到端测试计划与报告
        QA-->>WM: 返回测试计划与单测报告
        WM->>RVW: 阶段评审 QA
        alt 评审通过
            RVW-->>WM: pass
        else 评审不通过
            RVW-->>WM: feedback
            WM->>QA: 按反馈纠偏重试
        end
    end

    WM->>RVW: 生命周期汇总评审
    RVW-->>WM: 返回汇总结论与纠偏建议
    WM->>KB: 沉淀知识库与skills并提交草稿
    WM->>WM: 执行质量评估与质量门禁
    WM->>OUT: 渲染文档并导出JSON
    OUT-->>USER: 交付最终产物
```

## 7. 编排器与节点执行

### 7.1 编排器选择

| 编排器 | 参数 | 实现 | 说明 |
| --- | --- | --- | --- |
| LangGraph（默认） | `--orchestrator langgraph` | `app/workflow/langgraph_engine.py` | 显式节点图、节点级重试、节点 trace |
| Classic | `--orchestrator classic` | `app/workflow/engine.py` | 串行执行，逻辑更直观 |

### 7.2 LangGraph 节点顺序

`knowledge_bootstrap -> ba_analysis -> solution_design -> coding_planning -> qa_planning -> review -> knowledge_persist -> public_kb_submit -> public_kb_audit -> quality_gate -> finalize`

补充说明：
- `ba_analysis / solution_design / coding_planning / qa_planning` 节点内部已内置对应阶段（BA/Architecture/Developer/QA）的 Reviewer 评审与纠偏。
- 当阶段评审未通过时，节点会根据 `node_retry_max_attempts` 和 `node_retry_backoff_ms` 进行同阶段重试。
- `review` 节点用于生命周期汇总评审（不是唯一评审点）。

### 7.3 节点重试

重试参数：
- `node_retry_max_attempts`：总尝试次数（最小 1，包含首次）。
- `node_retry_backoff_ms`：线性退避（`backoff_ms * attempt`）。

执行追踪字段：
- `runtime_stats.node_trace`
- `runtime_stats.node_retry_summary`

## 8. CLI 使用规范

### 8.1 子命令

| 子命令 | 作用 |
| --- | --- |
| `scan-context` | 扫描项目代码上下文并输出快照 |
| `generate` | 全参数生成 |
| `generate-simple` | 极简 6 参数生成 |
| `kb-review` | 公共知识草稿审批状态更新 |

### 8.2 `generate-simple`（固定 6 参数）

| 参数 | 必填 | 说明 |
| --- | --- | --- |
| `--public-kb-dir` | 是 | 公共知识库路径 |
| `--local-kb-dir` | 是 | 本地知识库路径 |
| `--requirement-file` | 是 | 需求文档路径 |
| `--project-root` | 是 | 目标项目根目录 |
| `--out-dir` | 是 | 产物输出目录 |
| `--model` | 是 | 模型名 |

固定默认行为：
- `kb_mode=local`
- `orchestrator=langgraph`
- `strict_kb=False`
- `strict_llm=False`
- `node_retry_max_attempts=2`
- `node_retry_backoff_ms=200`
- `enforce_quality_gate=False`

### 8.3 `generate`（全参数）

必填：
- `--requirement-file`
- `--project-root` 或 `--context-file` 至少其一

关键参数：

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `--out-dir` | `outputs/latest` | 输出目录 |
| `--templates-dir` | `templates` | 模板目录 |
| `--knowledge-dir` | `knowledge_base` | 本地知识与 skills 累计目录 |
| `--rules-dir` | `knowledge_base/public_rules` | 公共规则目录 |
| `--kb-mode` | `local` | 公共知识模式（`local/remote/hybrid`） |
| `--kb-dir` | `public_knowledge_base` | 本地公共知识目录 |
| `--kb-url` | `""` | 远程知识服务地址 |
| `--kb-token` | `""` | 访问令牌（可回退 `PUBLIC_KB_TOKEN`） |
| `--kb-namespace` | `default` | 知识命名空间 |
| `--kb-cache-dir` | `outputs/kb_cache` | 混合模式缓存目录 |
| `--disable-llm` | `False` | 禁用 LLM |
| `--model` | `OPENAI_MODEL` 或 `gpt-5` | 指定模型 |
| `--strict-llm` | `False` | LLM 不可用时是否失败 |
| `--strict-kb` | `False` | 公共知识不可用时是否失败 |
| `--orchestrator` | `langgraph` | 编排器选择 |
| `--node-retry-max-attempts` | `2` | 节点最大尝试次数 |
| `--node-retry-backoff-ms` | `200` | 节点重试退避毫秒 |
| `--quality-gate-policy-file` | `""` | 自定义门禁策略 JSON |
| `--enforce-quality-gate` | `False` | 门禁 BLOCK 时返回失败 |

## 9. API 服务说明

### 9.1 启动方式

```bash
ai-delivery-engine-api
```

### 9.2 环境变量

| 变量 | 默认值 | 作用 |
| --- | --- | --- |
| `API_BEARER_TOKEN` | `""` | 单 token 鉴权 |
| `API_BEARER_TOKENS` | `""` | 多 token（逗号分隔） |
| `API_TASK_WORKERS` | `2` | 异步任务线程池大小 |
| `API_TASK_STORE_FILE` | `outputs/api_tasks/tasks.json` | 任务持久化文件 |
| `API_HOST` | `0.0.0.0` | 服务监听地址 |
| `API_PORT` | `8000` | 服务端口 |

### 9.3 接口清单

| Method | Path | 说明 |
| --- | --- | --- |
| `GET` | `/health` | 健康检查 |
| `POST` | `/scan-context` | 扫描上下文 |
| `POST` | `/generate` | 同步生成 |
| `POST` | `/generate-async` | 异步提交 |
| `GET` | `/tasks` | 查询任务列表（`status`、`limit`） |
| `GET` | `/tasks/{task_id}` | 查询任务详情 |
| `POST` | `/tasks/{task_id}/cancel` | 取消任务 |
| `POST` | `/kb-review` | 审批公共知识草稿 |

### 9.4 异步任务状态机

- 主路径：`PENDING -> RUNNING -> SUCCEEDED / FAILED`
- 取消路径：`PENDING / RUNNING -> CANCELLING -> CANCELLED`
- 服务重启恢复：重启前未完成任务会被标记为 `FAILED`

## 10. 数据模型

| 模型 | 代码位置 | 关键字段 |
| --- | --- | --- |
| `RequirementInput` | `app/schemas/models.py` | `title/background/goals/scope_in/scope_out/constraints/acceptance_criteria` |
| `ContextSnapshot` | `app/schemas/models.py` | `project_root/repos/shared_tables` |
| `ImpactItem` | `app/schemas/models.py` | `system/reason/changes` |
| `DesignDoc` | `app/schemas/models.py` | `architecture_diagram/sequence_diagrams/data_model_notes/risks` |
| `ApiDoc` | `app/schemas/models.py` | `endpoints/common_errors/common_policy` |
| `ValidationReport` | `app/schemas/models.py` | `passed/errors/warnings/checks` |
| `WorkflowResult` | `app/workflow/engine.py` | 聚合需求、设计、测试、质量、知识资产与审计信息 |

## 11. 模板与文档语义边界

模板文件：
- 需求分析报告：`templates/Requirement Analysis Report Template.md`
- FRD：`templates/Funditional Requirement Document.md`
- 接口文档：`templates/api_doc.md.j2`

语义边界校验：
- 入口：`app/validators/document_scope.py`
- 校验对象：`analysis`、`frd`、`interfaces`、`quality`
- 校验内容：标题规则、必需章节、越界语义清理
- 严格模式：默认开启，违规时直接失败

## 12. 公共规则库与质量门禁策略

### 12.1 规则库必需文件

目录下必须存在：
- `Requirement_Analysis_Report_Standard.md`
- `Technical_Design_Document_Standard.md`
- `Interface_Document_Standard.md`
- `Code_Development_Standard.md`

可选：
- `Quality_Gate_Policy.json`

### 12.2 质量门禁策略结构

支持 4 个顶层块：
- `block`：阻断条件
- `warn`：告警条件
- `score`：评分扣减权重
- `lifecycle`：分阶段门禁策略

生命周期阶段默认关注：
- `ba`
- `architecture`
- `developer`
- `qa`

阶段级规则支持：
- `block_if_failed`
- `warn_if_failed`
- `block_error_count_gt`
- `warn_warning_count_gt`

门禁输出关键字段：
- `decision`（`PASS/WARN/BLOCK`）
- `score`
- `blocking_issues`
- `warning_issues`
- `auto_fix_actions`
- `lifecycle_review.stage_policy_checks`

## 13. 公共知识库接入

### 13.1 模式

| 模式 | 说明 |
| --- | --- |
| `local` | 读取本地快照 |
| `remote` | 通过 HTTP 拉取 |
| `hybrid` | 远端读取 + 本地缓存 |

### 13.2 `local` 模式快照识别顺序

1. `public_knowledge_snapshot.json`
2. `knowledge_snapshot.json`
3. `knowledge.json`
4. `MANIFEST.json`

`MANIFEST.json` 会在 provider 层转换为标准快照结构再参与语义检索。

## 14. 产物与追踪文件

需求文件 `payment_upgrade.md` 对应产物：

| 文件 | 说明 |
| --- | --- |
| `payment_upgrade_Analysis_Report.md` | 需求分析报告 |
| `payment_upgrade_FRD.md` | 开发设计文档 |
| `payment_upgrade_Interfaces.md` | 接口文档 |
| `payment_upgrade_Quality_Assessment.md` | 质量评估报告 |
| `payment_upgrade_Interfaces_Postman.json` | Postman 导入文件 |
| `payment_upgrade_Interfaces_Apifox.json` | Apifox/OpenAPI 导入文件 |
| `payment_upgrade_Execution_Trace.json` | 执行追踪文件 |

`Execution_Trace.json` 核心字段：
- `orchestrator`
- `node_retry_policy.max_attempts`
- `node_retry_policy.backoff_ms`
- `runtime_stats.stage_durations_ms`
- `runtime_stats.node_retry_summary`
- `runtime_stats.node_trace`
- `lifecycle_review`
- `quality_gate`

## 15. 退出码语义

| 退出码 | 说明 |
| --- | --- |
| `0` | 成功 |
| `1` | 校验不通过，或启用 `--enforce-quality-gate` 且门禁 BLOCK |
| `2` | 运行时错误（如规则库缺失、模板缺失、编排器不可用） |

## 16. 扩展建议

建议扩展点：
- 新增角色：在 `app/agents/` 定义角色并在 workflow 注入。
- 新增门禁指标：在 `AIDeliveryEngineWorkflow._build_quality_report/_build_quality_gate` 扩展。
- 新增导出格式：在 `app/exporters/` 增加转换器并在 `engine_service.py` 接入输出。
- 新增 API 能力：在 `app/api/main.py` 新增请求模型与路由。

## 17. 常见问题排查

| 问题 | 典型原因 | 建议处理 |
| --- | --- | --- |
| `公共规则库不可用` | `rules_dir` 缺失或文件不全 | 补齐 4 个必需规则文件 |
| `文档语义边界校验失败` | 标题或章节不符合模板约束 | 对齐模板与 `document_scope` 规则 |
| `公共知识库命中摘要 source=unavailable:FileNotFoundError` | 公共知识快照不存在 | 在 `kb_dir` 下补齐快照或提供 `MANIFEST.json` |
| 接口归属系统告警 | `owner_system` 与 impacts 不一致 | 修正影响系统识别或接口归属配置 |
| LLM 不可用 | key/base_url/model 配置异常 | 检查 `OPENAI_*`，必要时先 `--disable-llm` |
| LangGraph 不可用 | 缺少依赖 | 安装 `langgraph` 或改用 `--orchestrator classic` |

---

若只想快速上手，先看根目录 `README.md`。  
若要做二次开发，请优先阅读以下文件：
- `app/cli.py`
- `app/api/main.py`
- `app/services/engine_service.py`
- `app/workflow/engine.py`
- `app/workflow/langgraph_engine.py`
