# Domain Skills Catalog

- Domain Skill: `Domain_Context_Skill.md`
- Latest Requirement Skill: `card-center-refactor_Skill.md`
- Requirement Entries: 1

## 最近需求沉淀
1. card-center-refactor | 卡产品中心独立能力建设 | vcc-cardcenter, vcc-common, vcc-oms
