# card-center-refactor Skill

## 适用场景
- 需求：卡产品中心独立能力建设
- 影响系统：vcc-cardcenter, vcc-common, vcc-oms

## 关键目标
- 从vcc-oms里拆分剥离出卡产品中心功能
- 在vcc-cardcenter 完成卡产品中心能力建设
- 保证架构的合理性、稳定性和业务可拓展性
- 提供分阶段、可回滚的发布方案

## 核心约束
- 必须保持现有上游调用兼容
- 严格遵守规则
- 不变更账号权限模型

## 接口关注点
- VccCardcenterService.execute
- VccCommonService.execute
- VccOmsService.execute

## 验收标准
- 交付需求分析文档、FRD、接口文档
- 接口文档包含请求字段、响应字段、错误码、幂等与重试策略
- 完成测试验证并具备回滚方案
- 提供分阶段、可回滚的发布方案
